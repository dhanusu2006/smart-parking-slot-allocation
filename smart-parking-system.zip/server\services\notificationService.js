import Notification from '../models/Notification.js';
import Subscription from '../models/Subscription.js';
import ParkingSlot from '../models/ParkingSlot.js';
import { SLOT_STATUSES, USER_ROLES } from '../config/constants.js';

export const sendNotification = async ({
  userId = null,
  role = null,
  title,
  message,
  type = 'INFO',
  referenceId = null
}) => {
  try {
    return await Notification.create({
      user: userId,
      role,
      title,
      message,
      type,
      referenceId,
      isRead: false
    });
  } catch (err) {
    console.error('[Notification] Error creating notification:', err.message);
  }
};

/**
 * Checks for upcoming pass expiries (e.g. within 3 days)
 */
export const checkSubscriptionExpiries = async () => {
  try {
    const now = new Date();
    const threeDaysFromNow = new Date(Date.now() + 3 * 24 * 60 * 60 * 1000);

    const expiringPasses = await Subscription.find({
      status: 'ACTIVE',
      endDate: { $gte: now, $lte: threeDaysFromNow }
    });

    for (const pass of expiringPasses) {
      await sendNotification({
        userId: pass.user,
        role: USER_ROLES.PARKING_STAFF,
        title: `Pass Expiring Soon: ${pass.passNumber}`,
        message: `Pass for vehicle ${pass.vehicleNumber} (${pass.customerName}) expires on ${new Date(pass.endDate).toLocaleDateString()}.`,
        type: 'WARNING',
        referenceId: pass._id
      });
    }
  } catch (err) {
    console.error('Error checking subscription expiries:', err.message);
  }
};

/**
 * Checks if any vehicle category has 0 available slots and triggers slot-full alert
 */
export const checkCapacityAlerts = async (category) => {
  try {
    const availableCount = await ParkingSlot.countDocuments({
      category,
      status: SLOT_STATUSES.AVAILABLE
    });

    if (availableCount === 0) {
      await sendNotification({
        role: USER_ROLES.PARKING_MANAGER,
        title: `Capacity Alert: ${category} Full`,
        message: `All parking slots for vehicle category ${category} are currently occupied or reserved.`,
        type: 'ALERT'
      });
    }
  } catch (err) {
    console.error('Error checking capacity alerts:', err.message);
  }
};
