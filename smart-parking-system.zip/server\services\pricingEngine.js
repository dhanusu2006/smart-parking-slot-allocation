import PricingRule from '../models/PricingRule.js';
import { BILLING_PLANS } from '../config/constants.js';

/**
 * Creates an immutable snapshot of current pricing rules for a category
 */
export const capturePricingSnapshot = async (category) => {
  const rule = await PricingRule.findOne({ category, isActive: true });
  if (!rule) {
    throw new Error(`Pricing rule not found for vehicle category: ${category}`);
  }

  return {
    hourlyRate: rule.hourlyRate,
    dailyRate: rule.dailyRate,
    monthlyRate: rule.monthlyRate,
    yearlyRate: rule.yearlyRate,
    gracePeriodMinutes: rule.gracePeriodMinutes || 15,
    overtimeRatePerHour: rule.overtimeRatePerHour || rule.hourlyRate * 1.5,
    taxPercent: rule.taxPercent || 18,
    discountPercent: rule.discountPercent || 0,
    capturedAt: new Date()
  };
};

/**
 * Calculates fee breakdown for a session based on duration and snapshot rules
 */
export const calculateParkingFee = ({
  entryTime,
  exitTime = new Date(),
  billingPlan = BILLING_PLANS.HOURLY,
  priceSnapshot,
  customDiscountPercent = 0
}) => {
  const entry = new Date(entryTime);
  const exit = new Date(exitTime);
  const diffMs = Math.max(0, exit - entry);
  const durationMinutes = Math.floor(diffMs / (1000 * 60));
  const durationHours = durationMinutes / 60;

  const {
    hourlyRate,
    dailyRate,
    gracePeriodMinutes = 15,
    overtimeRatePerHour = hourlyRate * 1.5,
    taxPercent = 18,
    discountPercent = 0
  } = priceSnapshot;

  let baseAmount = 0;
  let penaltyAmount = 0;

  if (billingPlan === BILLING_PLANS.HOURLY) {
    if (durationMinutes <= gracePeriodMinutes) {
      // Grace period: within 15 minutes is free
      baseAmount = 0;
    } else {
      // Ceil to next full hour
      const billedHours = Math.ceil(durationMinutes / 60);
      baseAmount = billedHours * hourlyRate;
    }
  } else if (billingPlan === BILLING_PLANS.DAILY) {
    // 24-hour blocks
    const billedDays = Math.max(1, Math.ceil(durationHours / 24));
    baseAmount = billedDays * dailyRate;

    // If session stayed beyond paid daily blocks with grace allowance
    const totalAllowedHours = billedDays * 24;
    if (durationHours > totalAllowedHours + (gracePeriodMinutes / 60)) {
      const extraHours = Math.ceil(durationHours - totalAllowedHours);
      penaltyAmount = extraHours * overtimeRatePerHour;
    }
  } else if (billingPlan === BILLING_PLANS.MONTHLY || billingPlan === BILLING_PLANS.YEARLY) {
    // Passes cover parking base fee; only extra overtime or penalties if expired
    baseAmount = 0;
  }

  // Combined discount calculation
  const totalDiscountRate = Math.min(100, Math.max(0, (discountPercent || 0) + (customDiscountPercent || 0)));
  const discountAmount = Math.round(((baseAmount * totalDiscountRate) / 100) * 100) / 100;
  const taxableAmount = Math.max(0, baseAmount - discountAmount + penaltyAmount);

  // Tax calculation (GST 18%)
  const taxAmount = Math.round(((taxableAmount * taxPercent) / 100) * 100) / 100;
  const totalAmount = Math.round((taxableAmount + taxAmount) * 100) / 100;

  return {
    durationMinutes,
    durationFormatted: formatDuration(durationMinutes),
    baseAmount,
    discountAmount,
    penaltyAmount,
    taxAmount,
    totalAmount
  };
};

export const formatDuration = (minutes) => {
  const days = Math.floor(minutes / (24 * 60));
  const remainingMinutesAfterDays = minutes % (24 * 60);
  const hours = Math.floor(remainingMinutesAfterDays / 60);
  const mins = remainingMinutesAfterDays % 60;

  const parts = [];
  if (days > 0) parts.push(`${days}d`);
  if (hours > 0) parts.push(`${hours}h`);
  parts.push(`${mins}m`);
  return parts.join(' ');
};
