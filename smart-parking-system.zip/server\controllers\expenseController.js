import Expense from '../models/Expense.js';
import Payment from '../models/Payment.js';
import { EXPENSE_CATEGORIES, PAYMENT_STATUSES } from '../config/constants.js';
import { logAuditEvent } from '../services/auditService.js';

export const getAllExpenses = async (req, res, next) => {
  try {
    const { category, startDate, endDate, search } = req.query;
    const filter = {};

    if (category) filter.category = category;

    if (startDate || endDate) {
      filter.date = {};
      if (startDate) filter.date.$gte = new Date(startDate);
      if (endDate) filter.date.$lte = new Date(endDate);
    }

    if (search) {
      filter.$or = [
        { title: { $regex: search, $options: 'i' } },
        { description: { $regex: search, $options: 'i' } },
        { referenceNumber: { $regex: search, $options: 'i' } }
      ];
    }

    const expenses = await Expense.find(filter)
      .populate('createdBy', 'name email role')
      .sort({ date: -1 });

    const totalExpenseAmount = expenses.reduce((sum, item) => sum + item.amount, 0);

    // Calculate gross revenue to derive Net Profit
    const paidPayments = await Payment.find({ status: PAYMENT_STATUSES.PAID });
    const grossRevenue = paidPayments.reduce((sum, item) => sum + item.totalAmount, 0);
    const netProfit = grossRevenue - totalExpenseAmount;

    res.json({
      success: true,
      count: expenses.length,
      categories: EXPENSE_CATEGORIES,
      summary: {
        totalExpenses: Math.round(totalExpenseAmount * 100) / 100,
        grossRevenue: Math.round(grossRevenue * 100) / 100,
        netProfit: Math.round(netProfit * 100) / 100
      },
      expenses
    });
  } catch (err) {
    next(err);
  }
};

export const createExpense = async (req, res, next) => {
  try {
    const { title, category, amount, date, description, paymentMethod, referenceNumber } = req.body;

    if (!title || !category || !amount) {
      return res.status(400).json({ success: false, message: 'Title, category, and amount are required' });
    }

    const expense = await Expense.create({
      title: title.trim(),
      category,
      amount: Number(amount),
      date: date ? new Date(date) : new Date(),
      description: description || '',
      paymentMethod: paymentMethod || 'BANK_TRANSFER',
      createdBy: req.user._id,
      referenceNumber: referenceNumber || `EXP-${Date.now().toString().slice(-6)}`
    });

    await logAuditEvent({
      req,
      action: 'EXPENSE_RECORDED',
      resourceType: 'EXPENSE',
      resourceId: expense._id,
      newValues: {
        title: expense.title,
        category: expense.category,
        amount: expense.amount
      },
      reason: 'Operational expense logged'
    });

    res.status(201).json({
      success: true,
      message: 'Expense record created successfully',
      expense
    });
  } catch (err) {
    next(err);
  }
};

export const deleteExpense = async (req, res, next) => {
  try {
    const expense = await Expense.findByIdAndDelete(req.params.id);
    if (!expense) {
      return res.status(404).json({ success: false, message: 'Expense record not found' });
    }

    await logAuditEvent({
      req,
      action: 'EXPENSE_DELETED',
      resourceType: 'EXPENSE',
      resourceId: expense._id,
      oldValues: { title: expense.title, amount: expense.amount },
      reason: 'Authorized expense removal'
    });

    res.json({ success: true, message: 'Expense record removed successfully' });
  } catch (err) {
    next(err);
  }
};
