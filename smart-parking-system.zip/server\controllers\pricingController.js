import PricingRule from '../models/PricingRule.js';
import AuditLog from '../models/AuditLog.js';
import { VEHICLE_CATEGORIES, DEFAULT_PRICING } from '../config/constants.js';
import { logAuditEvent } from '../services/auditService.js';

export const getAllPricingRules = async (req, res, next) => {
  try {
    const rules = await PricingRule.find().sort({ category: 1 });
    res.json({ success: true, count: rules.length, rules });
  } catch (err) {
    next(err);
  }
};

export const updatePricingRule = async (req, res, next) => {
  try {
    const { category } = req.params;
    const {
      hourlyRate,
      dailyRate,
      monthlyRate,
      yearlyRate,
      gracePeriodMinutes,
      overtimeRatePerHour,
      taxPercent,
      discountPercent,
      effectiveDate,
      reason
    } = req.body;

    if (!reason || reason.trim() === '') {
      return res.status(400).json({
        success: false,
        message: 'A detailed reason is required to record this tariff modification in the audit log'
      });
    }

    let rule = await PricingRule.findOne({ category });
    if (!rule) {
      return res.status(404).json({ success: false, message: `Pricing rule not found for category ${category}` });
    }

    const oldValues = {
      hourlyRate: rule.hourlyRate,
      dailyRate: rule.dailyRate,
      monthlyRate: rule.monthlyRate,
      yearlyRate: rule.yearlyRate,
      gracePeriodMinutes: rule.gracePeriodMinutes,
      overtimeRatePerHour: rule.overtimeRatePerHour,
      taxPercent: rule.taxPercent,
      discountPercent: rule.discountPercent,
      effectiveDate: rule.effectiveDate
    };

    if (hourlyRate !== undefined) rule.hourlyRate = Number(hourlyRate);
    if (dailyRate !== undefined) rule.dailyRate = Number(dailyRate);
    if (monthlyRate !== undefined) rule.monthlyRate = Number(monthlyRate);
    if (yearlyRate !== undefined) rule.yearlyRate = Number(yearlyRate);
    if (gracePeriodMinutes !== undefined) rule.gracePeriodMinutes = Number(gracePeriodMinutes);
    if (overtimeRatePerHour !== undefined) rule.overtimeRatePerHour = Number(overtimeRatePerHour);
    if (taxPercent !== undefined) rule.taxPercent = Number(taxPercent);
    if (discountPercent !== undefined) rule.discountPercent = Number(discountPercent);
    if (effectiveDate) rule.effectiveDate = new Date(effectiveDate);

    rule.lastUpdatedBy = req.user._id;
    rule.lastUpdateReason = reason;
    await rule.save();

    const newValues = {
      hourlyRate: rule.hourlyRate,
      dailyRate: rule.dailyRate,
      monthlyRate: rule.monthlyRate,
      yearlyRate: rule.yearlyRate,
      gracePeriodMinutes: rule.gracePeriodMinutes,
      overtimeRatePerHour: rule.overtimeRatePerHour,
      taxPercent: rule.taxPercent,
      discountPercent: rule.discountPercent,
      effectiveDate: rule.effectiveDate
    };

    await logAuditEvent({
      req,
      action: 'PRICING_UPDATED',
      resourceType: 'PRICING_RULE',
      resourceId: category,
      oldValues,
      newValues,
      reason
    });

    res.json({
      success: true,
      message: `Tariff configuration for ${category} updated successfully`,
      comparison: {
        category,
        oldValues,
        newValues,
        modifiedBy: req.user.name,
        modifiedAt: new Date(),
        reason
      },
      rule
    });
  } catch (err) {
    next(err);
  }
};

export const getPricingAuditHistory = async (req, res, next) => {
  try {
    const history = await AuditLog.find({ resourceType: 'PRICING_RULE' })
      .populate('user', 'name email role')
      .sort({ createdAt: -1 })
      .limit(50);

    res.json({ success: true, count: history.length, history });
  } catch (err) {
    next(err);
  }
};
