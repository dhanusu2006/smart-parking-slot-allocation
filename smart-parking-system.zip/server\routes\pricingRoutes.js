import express from 'express';
import {
  getAllPricingRules,
  updatePricingRule,
  getPricingAuditHistory
} from '../controllers/pricingController.js';
import { protect, restrictTo } from '../middleware/auth.js';
import { USER_ROLES } from '../config/constants.js';

const router = express.Router();

router.get('/', getAllPricingRules);
router.get('/audit', protect, restrictTo(USER_ROLES.SUPER_ADMIN, USER_ROLES.ACCOUNTANT), getPricingAuditHistory);

router.put(
  '/:category',
  protect,
  restrictTo(USER_ROLES.SUPER_ADMIN),
  updatePricingRule
);

export default router;
