import express from 'express';
import {
  getAllPayments,
  getPaymentById,
  processRefund,
  createOnlineOrder
} from '../controllers/paymentController.js';
import { protect, restrictTo } from '../middleware/auth.js';
import { USER_ROLES } from '../config/constants.js';

const router = express.Router();

router.get('/', protect, getAllPayments);
router.get('/:id', protect, getPaymentById);
router.post('/order', protect, createOnlineOrder);

// Only Super Admin & Accountant can authorize refunds
router.post(
  '/:id/refund',
  protect,
  restrictTo(USER_ROLES.SUPER_ADMIN, USER_ROLES.ACCOUNTANT),
  processRefund
);

export default router;
