import ParkingSlot from '../models/ParkingSlot.js';
import ParkingSession from '../models/ParkingSession.js';
import Payment from '../models/Payment.js';
import Expense from '../models/Expense.js';
import AuditLog from '../models/AuditLog.js';
import { SLOT_STATUSES, VEHICLE_CATEGORIES, PAYMENT_STATUSES } from '../config/constants.js';

export const getDashboardMetrics = async (req, res, next) => {
  try {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const startOfYear = new Date(now.getFullYear(), 0, 1);

    // 1. Slot counts
    const totalSlots = await ParkingSlot.countDocuments();
    const availableSlots = await ParkingSlot.countDocuments({ status: SLOT_STATUSES.AVAILABLE });
    const occupiedSlots = await ParkingSlot.countDocuments({ status: SLOT_STATUSES.OCCUPIED });
    const reservedSlots = await ParkingSlot.countDocuments({ status: SLOT_STATUSES.RESERVED });
    const maintenanceSlots = await ParkingSlot.countDocuments({ status: SLOT_STATUSES.MAINTENANCE });
    const disabledSlots = await ParkingSlot.countDocuments({ status: SLOT_STATUSES.DISABLED });

    // 2. Active Sessions
    const activeSessionsCount = await ParkingSession.countDocuments({ status: 'ACTIVE' });
    const vehiclesParkedCount = occupiedSlots; // Synced with occupied slots

    // 3. Revenue calculations from real payments
    const todayPayments = await Payment.find({
      status: PAYMENT_STATUSES.PAID,
      createdAt: { $gte: startOfToday }
    });
    const todayCollections = todayPayments.reduce((acc, p) => acc + p.totalAmount, 0);

    const monthPayments = await Payment.find({
      status: PAYMENT_STATUSES.PAID,
      createdAt: { $gte: startOfMonth }
    });
    const monthlyRevenue = monthPayments.reduce((acc, p) => acc + p.totalAmount, 0);

    const yearPayments = await Payment.find({
      status: PAYMENT_STATUSES.PAID,
      createdAt: { $gte: startOfYear }
    });
    const yearlyRevenue = yearPayments.reduce((acc, p) => acc + p.totalAmount, 0);

    const allPaidPayments = await Payment.find({ status: PAYMENT_STATUSES.PAID });
    const grossLifetimeRevenue = allPaidPayments.reduce((acc, p) => acc + p.totalAmount, 0);

    // Outstanding unpaid sessions
    const unpaidSessions = await ParkingSession.find({ status: 'ACTIVE', paymentStatus: 'UNPAID' });
    const outstandingCount = unpaidSessions.length;

    // 4. Operating Expenses & Net Profit
    const expenses = await Expense.find();
    const totalExpenses = expenses.reduce((acc, e) => acc + e.amount, 0);
    const netProfit = grossLifetimeRevenue - totalExpenses;

    // 5. Category-wise occupancy
    const categoryOccupancy = [];
    for (const cat of Object.values(VEHICLE_CATEGORIES)) {
      const catTotal = await ParkingSlot.countDocuments({ category: cat });
      const catOccupied = await ParkingSlot.countDocuments({ category: cat, status: SLOT_STATUSES.OCCUPIED });
      const catAvailable = await ParkingSlot.countDocuments({ category: cat, status: SLOT_STATUSES.AVAILABLE });
      const catReserved = await ParkingSlot.countDocuments({ category: cat, status: SLOT_STATUSES.RESERVED });

      categoryOccupancy.push({
        category: cat,
        total: catTotal,
        occupied: catOccupied,
        available: catAvailable,
        reserved: catReserved,
        percentage: catTotal > 0 ? Math.round((catOccupied / catTotal) * 100) : 0
      });
    }

    // 6. Traffic & Activity: Sessions over the past 7 days
    const sevenDaysAgo = new Date(Date.now() - 7 * 24 * 60 * 60 * 1000);
    const recentSessions = await ParkingSession.find({ entryTime: { $gte: sevenDaysAgo } });

    const dailyTrafficMap = {};
    for (let i = 6; i >= 0; i--) {
      const d = new Date(Date.now() - i * 24 * 60 * 60 * 1000);
      const label = d.toLocaleDateString('en-US', { weekday: 'short', month: 'numeric', day: 'numeric' });
      dailyTrafficMap[label] = { date: label, entries: 0, revenue: 0 };
    }

    recentSessions.forEach((s) => {
      const label = new Date(s.entryTime).toLocaleDateString('en-US', { weekday: 'short', month: 'numeric', day: 'numeric' });
      if (dailyTrafficMap[label]) {
        dailyTrafficMap[label].entries += 1;
      }
    });

    const recentPaidPayments = await Payment.find({ createdAt: { $gte: sevenDaysAgo }, status: PAYMENT_STATUSES.PAID });
    recentPaidPayments.forEach((p) => {
      const label = new Date(p.createdAt).toLocaleDateString('en-US', { weekday: 'short', month: 'numeric', day: 'numeric' });
      if (dailyTrafficMap[label]) {
        dailyTrafficMap[label].revenue += p.totalAmount;
      }
    });

    const trafficTrends = Object.values(dailyTrafficMap);

    // 7. Recent Transactions (last 6)
    const recentTransactions = await Payment.find()
      .sort({ createdAt: -1 })
      .limit(6);

    // 8. Recent Activities (from AuditLog)
    const recentActivities = await AuditLog.find()
      .sort({ createdAt: -1 })
      .limit(6);

    res.json({
      success: true,
      metrics: {
        totalSlots,
        availableSlots,
        occupiedSlots,
        reservedSlots,
        maintenanceSlots,
        disabledSlots,
        activeParkingSessions: activeSessionsCount,
        vehiclesCurrentlyParked: vehiclesParkedCount,
        todayCollections: Math.round(todayCollections * 100) / 100,
        monthlyRevenue: Math.round(monthlyRevenue * 100) / 100,
        yearlyRevenue: Math.round(yearlyRevenue * 100) / 100,
        grossLifetimeRevenue: Math.round(grossLifetimeRevenue * 100) / 100,
        outstandingCount,
        totalExpenses: Math.round(totalExpenses * 100) / 100,
        netProfit: Math.round(netProfit * 100) / 100
      },
      categoryOccupancy,
      trafficTrends,
      recentTransactions,
      recentActivities
    });
  } catch (err) {
    next(err);
  }
};
