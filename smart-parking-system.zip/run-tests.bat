@echo off
echo ======================================================================
echo   SMART PARKING SYSTEM - AUTOMATED TEST SUITE (VITEST)
echo ======================================================================
echo.

cd /d "%~dp0\server"
call npx vitest run

echo.
pause
