import mongoose from 'mongoose';
import { VEHICLE_CATEGORIES, BILLING_PLANS } from '../config/constants.js';

const correctionEntrySchema = new mongoose.Schema(
  {
    correctedAt: { type: Date, default: Date.now },
    correctedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User' },
    previousValues: { type: Object },
    newValues: { type: Object },
    reason: { type: String, required: true }
  },
  { _id: false }
);

const parkingSessionSchema = new mongoose.Schema(
  {
    ticketNumber: {
      type: String,
      required: true,
      unique: true,
      index: true,
      uppercase: true
    },
    vehicleNumber: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
      index: true
    },
    category: {
      type: String,
      enum: Object.values(VEHICLE_CATEGORIES),
      required: true,
      index: true
    },
    customerName: {
      type: String,
      required: true,
      trim: true
    },
    customerPhone: {
      type: String,
      required: true,
      trim: true
    },
    slot: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'ParkingSlot',
      required: true
    },
    slotNumber: {
      type: String,
      required: true,
      uppercase: true
    },
    billingPlan: {
      type: String,
      enum: Object.values(BILLING_PLANS),
      default: BILLING_PLANS.HOURLY
    },
    entryTime: {
      type: Date,
      default: Date.now,
      index: true
    },
    exitTime: {
      type: Date,
      default: null,
      index: true
    },
    durationMinutes: {
      type: Number,
      default: 0
    },
    // IMMUTABLE price snapshot captured at the exact moment session was initialized
    priceSnapshot: {
      hourlyRate: { type: Number, required: true },
      dailyRate: { type: Number, required: true },
      monthlyRate: { type: Number, required: true },
      yearlyRate: { type: Number, required: true },
      gracePeriodMinutes: { type: Number, required: true },
      overtimeRatePerHour: { type: Number, required: true },
      taxPercent: { type: Number, required: true },
      discountPercent: { type: Number, default: 0 },
      capturedAt: { type: Date, default: Date.now }
    },
    baseAmount: {
      type: Number,
      default: 0
    },
    discountAmount: {
      type: Number,
      default: 0
    },
    taxAmount: {
      type: Number,
      default: 0
    },
    penaltyAmount: {
      type: Number,
      default: 0
    },
    totalAmount: {
      type: Number,
      default: 0
    },
    status: {
      type: String,
      enum: ['ACTIVE', 'COMPLETED', 'CANCELLED'],
      default: 'ACTIVE',
      index: true
    },
    paymentStatus: {
      type: String,
      enum: ['UNPAID', 'PAID', 'WAIVED'],
      default: 'UNPAID'
    },
    payment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Payment',
      default: null
    },
    qrCodeData: {
      type: String // Encoded string or Base64 data URL
    },
    entryOperator: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    exitOperator: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    subscriptionId: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subscription',
      default: null
    },
    correctionHistory: [correctionEntrySchema]
  },
  {
    timestamps: true
  }
);

export default mongoose.model('ParkingSession', parkingSessionSchema);
