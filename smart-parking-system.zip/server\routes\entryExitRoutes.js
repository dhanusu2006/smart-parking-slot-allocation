import express from 'express';
import {
  registerVehicleEntry,
  getActiveSessionDetails,
  processVehicleExit,
  correctEntryDetails
} from '../controllers/entryExitController.js';
import { protect, restrictTo } from '../middleware/auth.js';
import { USER_ROLES } from '../config/constants.js';

const router = express.Router();

// Entry registration
router.post(
  '/entry',
  protect,
  restrictTo(USER_ROLES.SUPER_ADMIN, USER_ROLES.PARKING_MANAGER, USER_ROLES.PARKING_STAFF),
  registerVehicleEntry
);

// Preview active session and calculate live fees
router.get('/session/:identifier', getActiveSessionDetails);

// Process checkout and release slot
router.post(
  '/exit',
  protect,
  restrictTo(USER_ROLES.SUPER_ADMIN, USER_ROLES.PARKING_MANAGER, USER_ROLES.PARKING_STAFF),
  processVehicleExit
);

// Authorized entry correction
router.patch(
  '/session/:sessionId/correct',
  protect,
  restrictTo(USER_ROLES.SUPER_ADMIN, USER_ROLES.PARKING_MANAGER),
  correctEntryDetails
);

export default router;
