import React, { useState, useEffect } from 'react';
import {
  DollarSign,
  Plus,
  Trash2,
  Receipt,
  TrendingDown,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  X
} from 'lucide-react';
import api from '../services/api';

export const ExpensesPage = () => {
  const [expenses, setExpenses] = useState([]);
  const [summary, setSummary] = useState({ totalExpenses: 0, grossRevenue: 0, netProfit: 0 });
  const [categories, setCategories] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Add Expense Modal
  const [addModalOpen, setAddModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    category: 'MAINTENANCE',
    amount: '',
    description: '',
    paymentMethod: 'BANK_TRANSFER',
    referenceNumber: ''
  });

  const fetchExpenses = async () => {
    setLoading(true);
    try {
      const res = await api.get('/expenses');
      if (res.success) {
        setExpenses(res.expenses || []);
        setSummary(res.summary || { totalExpenses: 0, grossRevenue: 0, netProfit: 0 });
        setCategories(res.categories || {});
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchExpenses();
  }, []);

  const handleAddExpense = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    try {
      const res = await api.post('/expenses', formData);
      if (res.success) {
        setSuccessMsg('Operating expense logged successfully.');
        setAddModalOpen(false);
        setFormData({
          title: '',
          category: 'MAINTENANCE',
          amount: '',
          description: '',
          paymentMethod: 'BANK_TRANSFER',
          referenceNumber: ''
        });
        fetchExpenses();
      }
    } catch (err) {
      setError(err.message);
    }
  };

  const handleDeleteExpense = async (id, title) => {
    if (!window.confirm(`Delete expense record "${title}"?`)) return;
    try {
      const res = await api.delete(`/expenses/${id}`);
      if (res.success) {
        setSuccessMsg('Expense record removed.');
        fetchExpenses();
      }
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            Facility Operating Expenses & Profit Ledger
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Log overheads, utilities, salaries, and compute real net operating profit.
          </p>
        </div>

        <button
          onClick={() => setAddModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-lg glow-cyan transition self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" /> Record New Expense
        </button>
      </div>

      {successMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-500/50 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{successMsg}</span>
        </div>
      )}

      {error && (
        <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* Financial Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block mb-1">
            Gross Recognized Revenue
          </span>
          <span className="font-mono text-2xl font-extrabold text-emerald-400 flex items-center gap-1.5">
            <TrendingUp className="w-5 h-5" />
            ₹{summary.grossRevenue?.toLocaleString()}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">Total revenue collected</span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block mb-1">
            Total Facility Overheads
          </span>
          <span className="font-mono text-2xl font-extrabold text-rose-400 flex items-center gap-1.5">
            <TrendingDown className="w-5 h-5" />
            ₹{summary.totalExpenses?.toLocaleString()}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">Salaries, power, repairs, equipment</span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block mb-1">
            Net Operating Profit
          </span>
          <span className={`font-mono text-2xl font-extrabold flex items-center gap-1.5 ${
            summary.netProfit >= 0 ? 'text-cyan-400' : 'text-rose-400'
          }`}>
            ₹{summary.netProfit?.toLocaleString()}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">Gross revenue minus expenses</span>
        </div>
      </div>

      {/* Expenses Table */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-800/60 text-slate-400 uppercase text-[10px] font-bold">
              <tr>
                <th className="py-3 px-4 rounded-l-lg">Expense Item</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Amount</th>
                <th className="py-3 px-4">Payment Method</th>
                <th className="py-3 px-4">Recorded By</th>
                <th className="py-3 px-4">Reference No</th>
                <th className="py-3 px-4">Date</th>
                <th className="py-3 px-4 rounded-r-lg text-right">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {expenses.length === 0 ? (
                <tr>
                  <td colSpan="8" className="text-center py-8 text-slate-400">
                    No operating expenses logged yet.
                  </td>
                </tr>
              ) : (
                expenses.map((e) => (
                  <tr key={e._id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3 px-4 font-semibold text-white">
                      <div>{e.title}</div>
                      {e.description && <div className="text-[10px] text-slate-400 font-normal">{e.description}</div>}
                    </td>
                    <td className="py-3 px-4">
                      <span className="px-2 py-0.5 rounded-full text-[10px] font-bold uppercase bg-slate-800 text-cyan-300 border border-slate-700">
                        {categories[e.category] || e.category}
                      </span>
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-rose-400 text-sm">
                      ₹{e.amount?.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 text-slate-300">
                      {e.paymentMethod}
                    </td>
                    <td className="py-3 px-4 text-slate-400">
                      {e.createdBy?.name || 'Accountant'}
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-400">
                      {e.referenceNumber || 'N/A'}
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-400">
                      {new Date(e.date).toLocaleDateString()}
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => handleDeleteExpense(e._id, e.title)}
                        className="p-1 rounded-lg text-rose-400 hover:bg-rose-950/60 hover:text-white transition"
                        title="Delete Entry"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Expense Modal */}
      {addModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl p-6 shadow-2xl relative text-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="font-extrabold text-base text-white">Record Operating Expense</h2>
              <button
                onClick={() => setAddModalOpen(false)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddExpense} className="space-y-4 my-4 text-xs">
              <div>
                <label className="text-slate-400 block mb-1">Expense Title *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. BESCOM Power Bill or Barrier Arm Replacement"
                  value={formData.title}
                  onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Category *</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="SALARY">Staff Salary</option>
                    <option value="ELECTRICITY">Electricity & Utilities</option>
                    <option value="MAINTENANCE">Facility Maintenance</option>
                    <option value="CLEANING">Cleaning & Janitorial</option>
                    <option value="EQUIPMENT">Hardware & Barriers</option>
                    <option value="OTHER">Other Operating Expenses</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Amount (₹) *</label>
                  <input
                    type="number"
                    required
                    min="1"
                    placeholder="e.g. 4500"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Payment Method</label>
                  <select
                    value={formData.paymentMethod}
                    onChange={(e) => setFormData({ ...formData, paymentMethod: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="BANK_TRANSFER">Bank Wire / NEFT</option>
                    <option value="CARD">Credit / Debit Card</option>
                    <option value="UPI">UPI Transfer</option>
                    <option value="CASH">Petty Cash</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Invoice / Reference No</label>
                  <input
                    type="text"
                    placeholder="e.g. INV-2026-90"
                    value={formData.referenceNumber}
                    onChange={(e) => setFormData({ ...formData, referenceNumber: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-400 block mb-1">Description / Notes</label>
                <textarea
                  rows="2"
                  placeholder="Additional context or supplier details"
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-white"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setAddModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold shadow-lg glow-cyan"
                >
                  Save Expense Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default ExpensesPage;
