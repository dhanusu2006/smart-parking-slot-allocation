import mongoose from 'mongoose';
import { VEHICLE_CATEGORIES } from '../config/constants.js';

const parkingZoneSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: true,
      trim: true
    },
    code: {
      type: String,
      required: true,
      unique: true,
      uppercase: true,
      trim: true
    },
    floorLevel: {
      type: String,
      default: 'Ground Floor'
    },
    allowedCategories: [
      {
        type: String,
        enum: Object.values(VEHICLE_CATEGORIES),
        required: true
      }
    ],
    description: {
      type: String,
      default: ''
    },
    totalSlots: {
      type: Number,
      default: 0
    }
  },
  {
    timestamps: true
  }
);

export default mongoose.model('ParkingZone', parkingZoneSchema);
