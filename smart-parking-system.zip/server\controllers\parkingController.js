import ParkingSlot from '../models/ParkingSlot.js';
import ParkingZone from '../models/ParkingZone.js';
import ParkingSession from '../models/ParkingSession.js';
import { SLOT_STATUSES, VEHICLE_CATEGORIES } from '../config/constants.js';
import { logAuditEvent } from '../services/auditService.js';

export const getVisualParkingLayout = async (req, res, next) => {
  try {
    const { category, zoneId, status } = req.query;

    const filter = {};
    if (category) filter.category = category;
    if (zoneId) filter.zone = zoneId;
    if (status) filter.status = status;

    const slots = await ParkingSlot.find(filter)
      .populate('zone', 'name code floorLevel')
      .populate({
        path: 'currentSession',
        select: 'ticketNumber vehicleNumber customerName entryTime billingPlan'
      })
      .sort({ slotNumber: 1 });

    const zones = await ParkingZone.find().sort({ code: 1 });

    // Calculate live category statistics
    const stats = {};
    for (const cat of Object.values(VEHICLE_CATEGORIES)) {
      const total = await ParkingSlot.countDocuments({ category: cat });
      const available = await ParkingSlot.countDocuments({ category: cat, status: SLOT_STATUSES.AVAILABLE });
      const occupied = await ParkingSlot.countDocuments({ category: cat, status: SLOT_STATUSES.OCCUPIED });
      const reserved = await ParkingSlot.countDocuments({ category: cat, status: SLOT_STATUSES.RESERVED });
      const maintenance = await ParkingSlot.countDocuments({ category: cat, status: SLOT_STATUSES.MAINTENANCE });
      const disabled = await ParkingSlot.countDocuments({ category: cat, status: SLOT_STATUSES.DISABLED });

      stats[cat] = {
        total,
        available,
        occupied,
        reserved,
        maintenance,
        disabled,
        occupancyRate: total > 0 ? Math.round((occupied / total) * 100) : 0
      };
    }

    res.json({
      success: true,
      zones,
      stats,
      totalSlots: slots.length,
      slots
    });
  } catch (err) {
    next(err);
  }
};

export const getSlotById = async (req, res, next) => {
  try {
    const slot = await ParkingSlot.findById(req.params.id)
      .populate('zone')
      .populate('currentSession');

    if (!slot) {
      return res.status(404).json({ success: false, message: 'Parking slot not found' });
    }

    res.json({ success: true, slot });
  } catch (err) {
    next(err);
  }
};

export const updateSlotStatus = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { status, reason, notes } = req.body;

    if (!Object.values(SLOT_STATUSES).includes(status)) {
      return res.status(400).json({ success: false, message: 'Invalid slot status' });
    }

    const slot = await ParkingSlot.findById(id);
    if (!slot) {
      return res.status(404).json({ success: false, message: 'Slot not found' });
    }

    if (slot.status === SLOT_STATUSES.OCCUPIED && status !== SLOT_STATUSES.OCCUPIED) {
      return res.status(400).json({
        success: false,
        message: 'Cannot manually change status of an OCCUPIED slot. Vehicle must exit through Checkout.'
      });
    }

    const oldValues = { status: slot.status, notes: slot.notes };
    slot.status = status;
    if (notes !== undefined) slot.notes = notes;
    slot.version += 1;
    await slot.save();

    await logAuditEvent({
      req,
      action: 'SLOT_STATUS_UPDATED',
      resourceType: 'PARKING_SLOT',
      resourceId: slot.slotNumber,
      oldValues,
      newValues: { status: slot.status, notes: slot.notes },
      reason: reason || 'Manual status change by staff/manager'
    });

    res.json({ success: true, message: `Slot ${slot.slotNumber} updated to ${status}`, slot });
  } catch (err) {
    next(err);
  }
};

export const updateSlotDimensions = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { dimensions, isEvCharging, notes, reason } = req.body;

    const slot = await ParkingSlot.findById(id);
    if (!slot) {
      return res.status(404).json({ success: false, message: 'Slot not found' });
    }

    const oldValues = {
      dimensions: slot.dimensions,
      isEvCharging: slot.isEvCharging
    };

    if (dimensions) slot.dimensions = dimensions;
    if (isEvCharging !== undefined) slot.isEvCharging = isEvCharging;
    if (notes !== undefined) slot.notes = notes;
    slot.version += 1;
    await slot.save();

    await logAuditEvent({
      req,
      action: 'SLOT_CONFIG_UPDATED',
      resourceType: 'PARKING_SLOT',
      resourceId: slot.slotNumber,
      oldValues,
      newValues: { dimensions: slot.dimensions, isEvCharging: slot.isEvCharging },
      reason: reason || 'Administrator dimension/feature reconfiguration'
    });

    res.json({ success: true, message: `Slot ${slot.slotNumber} configuration updated`, slot });
  } catch (err) {
    next(err);
  }
};

export const reallocateVehicleSlot = async (req, res, next) => {
  try {
    const { sessionId, newSlotId, reason } = req.body;

    const session = await ParkingSession.findById(sessionId);
    if (!session || session.status !== 'ACTIVE') {
      return res.status(400).json({ success: false, message: 'Active parking session not found' });
    }

    const currentSlot = await ParkingSlot.findById(session.slot);
    const targetSlot = await ParkingSlot.findById(newSlotId);

    if (!targetSlot) {
      return res.status(404).json({ success: false, message: 'Target parking slot not found' });
    }

    if (targetSlot.status !== SLOT_STATUSES.AVAILABLE) {
      return res.status(400).json({ success: false, message: `Target slot ${targetSlot.slotNumber} is not available (${targetSlot.status})` });
    }

    if (targetSlot.category !== session.category) {
      return res.status(400).json({
        success: false,
        message: `Incompatible slot category. Session is ${session.category}, but target slot is ${targetSlot.category}`
      });
    }

    // Atomic switch
    targetSlot.status = SLOT_STATUSES.OCCUPIED;
    targetSlot.assignedVehiclePlate = session.vehicleNumber;
    targetSlot.currentSession = session._id;
    targetSlot.version += 1;
    await targetSlot.save();

    if (currentSlot) {
      currentSlot.status = SLOT_STATUSES.AVAILABLE;
      currentSlot.assignedVehiclePlate = null;
      currentSlot.currentSession = null;
      currentSlot.version += 1;
      await currentSlot.save();
    }

    const oldSlotNumber = session.slotNumber;
    session.slot = targetSlot._id;
    session.slotNumber = targetSlot.slotNumber;
    session.correctionHistory.push({
      correctedAt: new Date(),
      correctedBy: req.user._id,
      previousValues: { slotNumber: oldSlotNumber },
      newValues: { slotNumber: targetSlot.slotNumber },
      reason: reason || 'Authorized slot reallocation'
    });
    await session.save();

    await logAuditEvent({
      req,
      action: 'SLOT_REALLOCATED',
      resourceType: 'PARKING_SESSION',
      resourceId: session.ticketNumber,
      oldValues: { slotNumber: oldSlotNumber },
      newValues: { slotNumber: targetSlot.slotNumber },
      reason: reason || 'Vehicle moved to another compatible slot'
    });

    res.json({
      success: true,
      message: `Vehicle ${session.vehicleNumber} reallocated from ${oldSlotNumber} to ${targetSlot.slotNumber}`,
      session
    });
  } catch (err) {
    next(err);
  }
};
