import ParkingSlot from '../models/ParkingSlot.js';
import WaitingList from '../models/WaitingList.js';
import { SLOT_STATUSES } from '../config/constants.js';

/**
 * Validates slot compatibility with vehicle category and dimensions
 */
export const checkSlotCompatibility = (slot, vehicleCategory, dimensions = {}) => {
  if (slot.category !== vehicleCategory) {
    return {
      compatible: false,
      reason: `Slot ${slot.slotNumber} is designated for ${slot.category}, but vehicle is ${vehicleCategory}`
    };
  }

  if (slot.status !== SLOT_STATUSES.AVAILABLE) {
    return {
      compatible: false,
      reason: `Slot ${slot.slotNumber} is currently ${slot.status}`
    };
  }

  if (dimensions.length && slot.dimensions?.length && dimensions.length > slot.dimensions.length) {
    return {
      compatible: false,
      reason: `Vehicle length (${dimensions.length}m) exceeds slot capacity (${slot.dimensions.length}m)`
    };
  }

  return { compatible: true };
};

/**
 * Atomically allocates the nearest compatible available slot for a vehicle
 */
export const allocateOptimalSlot = async ({
  category,
  vehiclePlate,
  dimensions = {},
  preferEv = false,
  maxRetries = 3
}) => {
  for (let attempt = 0; attempt < maxRetries; attempt++) {
    const query = {
      category,
      status: SLOT_STATUSES.AVAILABLE
    };

    if (preferEv) {
      query.isEvCharging = true;
    }

    // Find available slots sorted by proximity (nearest to entrance gate first)
    const availableSlots = await ParkingSlot.find(query).sort({ walkDistanceUnits: 1, slotNumber: 1 });

    if (!availableSlots || availableSlots.length === 0) {
      // If preferEv had no slots, fall back to non-EV
      if (preferEv) {
        return allocateOptimalSlot({ category, vehiclePlate, dimensions, preferEv: false, maxRetries });
      }
      return null; // All compatible slots full
    }

    for (const slot of availableSlots) {
      // Check dimension compatibility if specified
      const comp = checkSlotCompatibility(slot, category, dimensions);
      if (!comp.compatible) continue;

      // ATOMIC UPDATE: Check that status is STILL 'AVAILABLE' and version matches
      const updatedSlot = await ParkingSlot.findOneAndUpdate(
        {
          _id: slot._id,
          status: SLOT_STATUSES.AVAILABLE,
          version: slot.version
        },
        {
          $set: {
            status: SLOT_STATUSES.OCCUPIED,
            assignedVehiclePlate: vehiclePlate.toUpperCase()
          },
          $inc: { version: 1 }
        },
        { new: true }
      );

      if (updatedSlot) {
        return updatedSlot;
      }
      // If null, another concurrent transaction locked this slot; continue to next slot or retry
    }
  }

  return null;
};

/**
 * Atomically allocates a specific slot chosen by operator
 */
export const allocateSpecificSlot = async ({
  slotId,
  category,
  vehiclePlate,
  dimensions = {}
}) => {
  const slot = await ParkingSlot.findById(slotId);
  if (!slot) {
    throw new Error('Selected parking slot does not exist');
  }

  const comp = checkSlotCompatibility(slot, category, dimensions);
  if (!comp.compatible) {
    throw new Error(comp.reason);
  }

  const updatedSlot = await ParkingSlot.findOneAndUpdate(
    {
      _id: slot._id,
      status: SLOT_STATUSES.AVAILABLE,
      version: slot.version
    },
    {
      $set: {
        status: SLOT_STATUSES.OCCUPIED,
        assignedVehiclePlate: vehiclePlate.toUpperCase()
      },
      $inc: { version: 1 }
    },
    { new: true }
  );

  if (!updatedSlot) {
    throw new Error(`Slot ${slot.slotNumber} was just claimed by another session. Please select another slot.`);
  }

  return updatedSlot;
};

/**
 * Atomically releases a slot back to AVAILABLE state
 */
export const releaseSlot = async (slotId) => {
  const released = await ParkingSlot.findByIdAndUpdate(
    slotId,
    {
      $set: {
        status: SLOT_STATUSES.AVAILABLE,
        assignedVehiclePlate: null,
        currentSession: null,
        currentBooking: null
      },
      $inc: { version: 1 }
    },
    { new: true }
  );

  // If there are vehicles waiting in the waiting list for this category, notify or flag them
  if (released) {
    checkAndNotifyWaitingList(released.category, released._id);
  }

  return released;
};

/**
 * Background hook to notify next person in waiting list when a slot opens up
 */
export const checkAndNotifyWaitingList = async (category, slotId) => {
  try {
    const nextWaiting = await WaitingList.findOne({
      category,
      status: 'WAITING'
    }).sort({ requestedTime: 1 });

    if (nextWaiting) {
      nextWaiting.status = 'NOTIFIED';
      nextWaiting.notifiedAt = new Date();
      nextWaiting.allocatedSlot = slotId;
      await nextWaiting.save();
    }
  } catch (err) {
    console.error('Error in waiting list check:', err.message);
  }
};
