# Smart Parking Slot Allocation and Management System

A production-ready, full-stack **MERN** (MongoDB, Express.js, React.js, Node.js) enterprise application for commercial, municipal, and residential parking facilities. Designed with a dark navy futuristic interface, atomic concurrency control, dynamic pricing snapshots, multi-role RBAC, QR code passes, and comprehensive automated test coverage.

---

## 🌟 Key Capabilities & Architectural Highlights

1. **4 Separate Vehicle Categories**:
   - **Two-Wheeler** (`TWO_WHEELER`): Bikes, scooters (B01–B10)
   - **Four-Wheeler** (`FOUR_WHEELER`): Sedans, hatchbacks, SUVs with EV charging points (C01–C20)
   - **Commercial Vehicle** (`COMMERCIAL`): Delivery vans, tempos, mini trucks (CM01–CM10)
   - **Heavy Vehicle** (`HEAVY`): Tour buses, lorries, multi-axle trucks (HV01–HV05)
   - Category-isolated capacity limits, dimensions, tariffs, and revenue metrics.

2. **Atomic Concurrency & Race Condition Elimination**:
   - Uses MongoDB atomic updates (`findOneAndUpdate`) with optimistic version checking (`versionKey` + status precondition `AVAILABLE`).
   - Prevents double-booking even under concurrent simultaneous check-ins.
   - Nearest-slot allocation based on entrance proximity score.
   - Automated overflow **Waiting List** when bays are full.

3. **Flexible Dynamic Pricing Engine**:
   - 4 Billing Plans: **Hourly**, **Daily (24-Hour Blocks)**, **Monthly Subscriptions**, and **Yearly Subscriptions**.
   - Configurable grace periods (e.g. 15 minutes free), ceiling hour rounding, overtime penalties, and GST calculation.
   - **Price Snapshot Immutability**: Confirmed parking sessions capture an immutable pricing snapshot upon entry. Modifying tariffs never silently reprices active sessions.
   - Complete audit trail tracking every rate change with old vs. new values, timestamp, and justification reason.

4. **Multi-Role Role-Based Access Control (RBAC)**:
   - **Super Admin**: Complete system control, pricing tariffs, user management, financial reports, refunds, and audit logs.
   - **Parking Manager**: Bay allocation, reallocations, maintenance modes, operational reports, waiting queue.
   - **Parking Staff**: Barrier entry registration, checkout payment collection, QR ticket & receipt printing.
   - **Accountant**: Authorized transaction ledger, operating expense tracking, refunds, and net profit analysis.
   - **Customer**: Pass self-service, parking availability viewing, receipt downloads.

5. **Financial Ledger & Net Operating Profit**:
   - Detailed revenue tracking across Cash, UPI, Card, and Sandbox Online Gateway.
   - Operating expense management (Salaries, Electricity, Maintenance, Cleaning, Equipment).
   - Real calculation: `Net Operating Profit = Gross Parking Revenue - Operating Expenses`.

6. **Futuristic Animated UI**:
   - Dark navy theme (`#0b1120`, `#0f172a`, `#1e293b`) with neon glow accents.
   - Animated highway road lane with moving vehicles (Bikes, Sedans, Vans, Trucks).
   - Light/Dark theme toggle.
   - Interactive SVG parking bay grid with real-time state transitions.

---

## 🏗️ Technology Stack

| Layer | Technologies |
|---|---|
| **Frontend** | React 18 / 19, Vite, Tailwind CSS, Lucide React, Recharts, Framer Motion, Axios |
| **Backend** | Node.js (ES Modules), Express.js, Helmet, Morgan, Express-Rate-Limit, QRCode |
| **Database** | MongoDB with Mongoose ODM (Plus built-in zero-config In-Memory fallback) |
| **Security** | JWT (JSON Web Tokens), Bcrypt.js, HMAC-SHA256 Sandbox Gateway Signatures |
| **Testing** | Vitest test runner (11 automated unit & integration test suites) |

---

## 📂 Project Directory Layout

```
smart-parking-system/
├── client/
│   ├── src/
│   │   ├── components/      # SlotCard, RoadLaneAnimation, StatCard, Modals, Navbar, Sidebar
│   │   ├── context/         # AuthContext, ThemeContext
│   │   ├── hooks/           # useParking hook
│   │   ├── layouts/         # MainLayout shell
│   │   ├── pages/           # Dashboard, Layout, Entry, Exit, Pricing, Passes, Payments, Expenses, Reports, Login
│   │   ├── services/        # Axios API client with auth interceptors
│   │   ├── utils/           # Formatters & currency helpers
│   │   ├── App.jsx          # Protected routing matrix
│   │   ├── main.jsx         # React DOM root
│   │   └── index.css        # Tailwind directives & glow utilities
│   ├── tailwind.config.js   # Custom dark navy theme & keyframe animations
│   ├── vite.config.js       # Vite configuration
│   └── package.json
├── server/
│   ├── config/              # Constants, MongoDB connection, demo seed script
│   ├── controllers/         # Auth, Parking, Entry/Exit, Pricing, Passes, Payments, Expenses, Reports
│   ├── middleware/          # JWT protect, restrictTo RBAC, error handler
│   ├── models/              # User, Slot, Zone, Session, PricingRule, Subscription, Payment, Expense, AuditLog
│   ├── routes/              # Express API route definitions
│   ├── services/            # Pricing engine, atomic allocator, audit service, sandbox payment gateway
│   ├── tests/               # Vitest automated test suite (parking.test.js)
│   ├── validators/          # Input schema validators
│   ├── server.js            # Express app entry point
│   ├── package.json
│   └── .env.example
├── .env.example
├── start-demo.bat           # 1-click Windows startup script
├── run-tests.bat            # 1-click test runner
├── package.json             # Root helper scripts
└── README.md
```

---

## ⚡ Quick Start Guide

### Prerequisites
- **Node.js**: v18.0.0 or higher (Tested and fully compatible with Node v24)
- **MongoDB**: Local MongoDB instance, MongoDB Atlas, or use the **built-in automatic in-memory MongoDB** fallback (no installation required).

### 1. Installation

Clone or extract the project, then install dependencies:

```bash
# In server directory:
cd server
npm install

# In client directory:
cd ../client
npm install
```

### 2. Seed Database with Realistic Demo Data

The seed script initializes 45 parking bays across all 4 categories, default pricing tariffs in INR, 5 user accounts, active sessions, completed payments, and expenses:

```bash
cd server
node config/seed.js
```

### 3. Start Backend & Frontend

#### Windows 1-Click Startup:
Double-click `start-demo.bat` in the project root, or run:
```bash
./start-demo.bat
```

#### Manual Startup:
**Terminal 1 (Backend Server on Port 5000):**
```bash
cd server
npm run dev
```

**Terminal 2 (Frontend Client on Port 5173):**
```bash
cd client
npm run dev
```

Open your browser at `http://localhost:5173`.

---

## 🔑 Demo User Credentials

The application includes an instant **1-Click Quick Demo Login** dropdown on both the login screen and navbar for fast evaluation:

| Role | Email | Password | Permissions |
|---|---|---|---|
| **Super Admin** | `admin@parking.com` | `Admin@12345` | Full system control, pricing tariffs, user roles, refunds, reports, audit logs |
| **Parking Manager** | `manager@parking.com` | `Admin@12345` | Bay maintenance, slot reallocations, operational reports, waiting queue |
| **Parking Staff** | `staff@parking.com` | `Admin@12345` | Register vehicle entry, process checkout exit, print QR tickets & receipts |
| **Accountant** | `accountant@parking.com` | `Admin@12345` | View transaction history, log expenses, authorize refunds, inspect net profit |
| **Customer** | `customer@parking.com` | `Customer@12345` | View active passes, browse bay availability, view receipts |

---

## 💰 Configurable Pricing Tariffs (Sample Rates in INR)

| Vehicle Category | Hourly Rate | Daily Rate (24h) | Monthly Pass | Yearly Pass | Grace Period | Overtime Surcharge |
|---|---|---|---|---|---|---|
| **Two-Wheeler** | ₹10 / hr | ₹60 / day | ₹900 / mo | ₹9,000 / yr | 15 mins (Free) | ₹15 / hr |
| **Four-Wheeler** | ₹30 / hr | ₹180 / day | ₹3,000 / mo | ₹30,000 / yr | 15 mins (Free) | ₹45 / hr |
| **Commercial** | ₹50 / hr | ₹300 / day | ₹5,000 / mo | ₹50,000 / yr | 15 mins (Free) | ₹75 / hr |
| **Heavy Vehicle** | ₹80 / hr | ₹500 / day | ₹8,000 / mo | ₹80,000 / yr | 15 mins (Free) | ₹120 / hr |

*All rates, grace periods, discounts, and taxes (18% GST default) are fully editable in the **Pricing & Tariffs** portal.*

---

## 🧪 Automated Testing Suite

Execute the comprehensive automated test suite with Vitest:

```bash
cd server
npm test
```

### Verified Test Cases:
1. Free grace period calculation (<= 15 minutes = ₹0)
2. Ceiling hour rounding past grace period
3. Multi-day 24-hour block calculations
4. Overtime surcharge application when exceeding daily boundary
5. Promotional discount application before GST
6. Price snapshot immutability (changing global tariffs never alters existing sessions)
7. Category compatibility validation
8. Category mismatch rejection (Heavy vehicle in bike bay rejected)
9. Dimension limit enforcement (oversized vehicle rejected)
10. Occupied/Maintenance slot protection
11. Financial accounting: Gross revenue minus expenses = Net operating profit

---

## 📡 REST API Reference

| Method | Endpoint | Description | Access |
|---|---|---|---|
| `POST` | `/api/auth/login` | Authenticate user & receive JWT | Public |
| `POST` | `/api/auth/register` | Register new customer | Public |
| `GET` | `/api/auth/me` | Fetch authenticated user profile | Private |
| `GET` | `/api/parking/layout` | Retrieve visual grid & category stats | Public / Private |
| `PATCH`| `/api/parking/slots/:id/status`| Update bay status (Maintenance / Available) | Staff / Manager / Admin |
| `POST` | `/api/parking/entry` | Register vehicle entry & generate QR ticket | Staff / Manager / Admin |
| `GET` | `/api/parking/session/:id` | Preview session duration & live fee | Private |
| `POST` | `/api/parking/exit` | Process exit checkout, payment & release bay | Staff / Manager / Admin |
| `GET` | `/api/pricing` | Retrieve all 4 category tariffs | Public / Private |
| `PUT` | `/api/pricing/:category` | Update tariffs with audit rationale | Super Admin |
| `GET` | `/api/pricing/audit` | View tariff modification history | Admin / Accountant |
| `POST` | `/api/passes/purchase` | Issue monthly or yearly recurring pass | Private |
| `GET` | `/api/passes` | List active & expired passes | Private |
| `GET` | `/api/payments` | Query payments with date/method filters | Admin / Accountant |
| `POST` | `/api/payments/:id/refund` | Authorize refund & log in expense ledger | Admin / Accountant |
| `GET` | `/api/expenses` | Retrieve operating expenses & net profit | Admin / Accountant |
| `POST` | `/api/expenses` | Record operating expense item | Admin / Accountant |
| `GET` | `/api/dashboard/metrics` | Retrieve live facility KPI metrics | Private |
| `POST` | `/api/waiting-list/join` | Enqueue vehicle when bays are full | Public / Private |
| `GET` | `/api/reports/export/sessions` | Export sessions data as CSV | Staff / Manager / Admin |
| `GET` | `/api/reports/export/payments` | Export financial payments as CSV | Admin / Accountant |

---

## 🔒 Security Best Practices Implemented

- **Password Hashing**: Bcrypt with 10 salt rounds.
- **JWT Authorization**: Bearer tokens with 24-hour expiration.
- **Brute-Force Protection**: Account lock after 5 consecutive failed attempts; rate-limiting on auth endpoints.
- **Zero Card Storage**: Payment gateways use tokenized transactions; raw card numbers or CVVs are never persisted.
- **Audit Logs**: Immutable log entries for price updates, manual session corrections, refunds, and bay reconfigurations.
