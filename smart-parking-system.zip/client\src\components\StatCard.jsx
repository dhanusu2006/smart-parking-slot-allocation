import React from 'react';
import { motion } from 'framer-motion';

export const StatCard = ({ title, value, subtext, icon: Icon, trend, color = 'cyan' }) => {
  const colorMap = {
    cyan: {
      border: 'border-cyan-500/30',
      bg: 'bg-cyan-950/20',
      iconBg: 'bg-cyan-500/20 text-cyan-400',
      glow: 'glow-cyan',
      text: 'text-cyan-400'
    },
    emerald: {
      border: 'border-emerald-500/30',
      bg: 'bg-emerald-950/20',
      iconBg: 'bg-emerald-500/20 text-emerald-400',
      glow: 'glow-green',
      text: 'text-emerald-400'
    },
    amber: {
      border: 'border-amber-500/30',
      bg: 'bg-amber-950/20',
      iconBg: 'bg-amber-500/20 text-amber-400',
      glow: 'glow-yellow',
      text: 'text-amber-400'
    },
    rose: {
      border: 'border-rose-500/30',
      bg: 'bg-rose-950/20',
      iconBg: 'bg-rose-500/20 text-rose-400',
      glow: 'glow-red',
      text: 'text-rose-400'
    },
    indigo: {
      border: 'border-indigo-500/30',
      bg: 'bg-indigo-950/20',
      iconBg: 'bg-indigo-500/20 text-indigo-400',
      glow: '',
      text: 'text-indigo-400'
    }
  };

  const scheme = colorMap[color] || colorMap.cyan;

  return (
    <motion.div
      whileHover={{ y: -3 }}
      className={`p-5 rounded-2xl border ${scheme.border} ${scheme.bg} backdrop-blur-md transition-all duration-200 relative overflow-hidden`}
    >
      <div className="flex items-center justify-between">
        <span className="text-xs font-semibold tracking-wider uppercase text-slate-400">{title}</span>
        <div className={`p-2.5 rounded-xl ${scheme.iconBg}`}>
          <Icon className="w-5 h-5" />
        </div>
      </div>

      <div className="mt-3">
        <div className="font-mono text-2xl lg:text-3xl font-extrabold text-white tracking-tight">
          {value}
        </div>
        {subtext && (
          <div className="flex items-center justify-between text-xs mt-1 text-slate-400">
            <span>{subtext}</span>
            {trend && (
              <span className={`font-semibold ${trend.startsWith('+') ? 'text-emerald-400' : 'text-slate-400'}`}>
                {trend}
              </span>
            )}
          </div>
        )}
      </div>
    </motion.div>
  );
};

export default StatCard;
