import AuditLog from '../models/AuditLog.js';

export const logAuditEvent = async ({
  req,
  user,
  action,
  resourceType,
  resourceId,
  oldValues = null,
  newValues = null,
  reason = 'System event'
}) => {
  try {
    const actorUser = user || (req && req.user) || null;
    const ip = req ? (req.headers['x-forwarded-for'] || req.socket?.remoteAddress || '') : '';

    await AuditLog.create({
      user: actorUser?._id || null,
      userName: actorUser?.name || 'Automated System',
      userRole: actorUser?.role || 'SYSTEM',
      action,
      resourceType,
      resourceId: String(resourceId),
      oldValues,
      newValues,
      reason,
      ipAddress: ip
    });
  } catch (err) {
    console.error('[AuditLog] Failed to record audit log:', err.message);
  }
};
