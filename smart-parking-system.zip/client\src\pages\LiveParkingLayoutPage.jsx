import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Grid,
  Filter,
  RefreshCw,
  Bike,
  Car,
  Truck,
  Bus,
  Clock,
  Zap,
  CheckCircle,
  AlertCircle
} from 'lucide-react';
import api from '../services/api';
import SlotCard from '../components/SlotCard';
import SlotDetailsModal from '../components/SlotDetailsModal';

export const LiveParkingLayoutPage = () => {
  const navigate = useNavigate();
  const [slots, setSlots] = useState([]);
  const [stats, setStats] = useState({});
  const [zones, setZones] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  // Filters
  const [selectedCategory, setSelectedCategory] = useState('');
  const [selectedStatus, setSelectedStatus] = useState('');

  // Selected slot for modal inspector
  const [selectedSlot, setSelectedSlot] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);

  const fetchLayout = async () => {
    setLoading(true);
    try {
      const queryParams = new URLSearchParams();
      if (selectedCategory) queryParams.append('category', selectedCategory);
      if (selectedStatus) queryParams.append('status', selectedStatus);

      const res = await api.get(`/parking/layout?${queryParams.toString()}`);
      if (res.success) {
        setSlots(res.slots);
        setStats(res.stats || {});
        setZones(res.zones || []);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchLayout();
    const interval = setInterval(fetchLayout, 10000); // Poll layout every 10s
    return () => clearInterval(interval);
  }, [selectedCategory, selectedStatus]);

  const handleSlotSelect = (slot) => {
    setSelectedSlot(slot);
    setModalOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            Visual Parking Grid & Bays
            <span className="text-xs bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 px-2.5 py-0.5 rounded-full font-bold">
              {slots.length} Bays Active
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Click any bay to inspect dimensions, manage maintenance mode, or process immediate exit.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => navigate('/entry')}
            className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-lg glow-cyan transition"
          >
            + Register Vehicle Entry
          </button>
          <button
            onClick={fetchLayout}
            className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 border border-slate-700 transition"
            title="Refresh Grid"
          >
            <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Category Capacity Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <button
          onClick={() => setSelectedCategory(selectedCategory === 'TWO_WHEELER' ? '' : 'TWO_WHEELER')}
          className={`p-3.5 rounded-2xl border text-left transition ${
            selectedCategory === 'TWO_WHEELER'
              ? 'bg-emerald-950/40 border-emerald-500 text-emerald-300 glow-green'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold">Two-Wheeler</span>
            <Bike className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="font-mono text-xl font-bold text-white">
            {stats.TWO_WHEELER?.available || 0} / {stats.TWO_WHEELER?.total || 10}
          </div>
          <div className="text-[10px] text-slate-400">Available bays (B01-B10)</div>
        </button>

        <button
          onClick={() => setSelectedCategory(selectedCategory === 'FOUR_WHEELER' ? '' : 'FOUR_WHEELER')}
          className={`p-3.5 rounded-2xl border text-left transition ${
            selectedCategory === 'FOUR_WHEELER'
              ? 'bg-cyan-950/40 border-cyan-500 text-cyan-300 glow-cyan'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold">Four-Wheeler</span>
            <Car className="w-4 h-4 text-cyan-400" />
          </div>
          <div className="font-mono text-xl font-bold text-white">
            {stats.FOUR_WHEELER?.available || 0} / {stats.FOUR_WHEELER?.total || 20}
          </div>
          <div className="text-[10px] text-slate-400">Available bays (C01-C20)</div>
        </button>

        <button
          onClick={() => setSelectedCategory(selectedCategory === 'COMMERCIAL' ? '' : 'COMMERCIAL')}
          className={`p-3.5 rounded-2xl border text-left transition ${
            selectedCategory === 'COMMERCIAL'
              ? 'bg-indigo-950/40 border-indigo-500 text-indigo-300'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold">Commercial</span>
            <Truck className="w-4 h-4 text-indigo-400" />
          </div>
          <div className="font-mono text-xl font-bold text-white">
            {stats.COMMERCIAL?.available || 0} / {stats.COMMERCIAL?.total || 10}
          </div>
          <div className="text-[10px] text-slate-400">Available bays (CM01-CM10)</div>
        </button>

        <button
          onClick={() => setSelectedCategory(selectedCategory === 'HEAVY' ? '' : 'HEAVY')}
          className={`p-3.5 rounded-2xl border text-left transition ${
            selectedCategory === 'HEAVY'
              ? 'bg-purple-950/40 border-purple-500 text-purple-300'
              : 'bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700'
          }`}
        >
          <div className="flex items-center justify-between mb-1">
            <span className="text-xs font-bold">Heavy Vehicle</span>
            <Bus className="w-4 h-4 text-purple-400" />
          </div>
          <div className="font-mono text-xl font-bold text-white">
            {stats.HEAVY?.available || 0} / {stats.HEAVY?.total || 5}
          </div>
          <div className="text-[10px] text-slate-400">Available bays (HV01-HV05)</div>
        </button>
      </div>

      {/* Filter Toolbar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 rounded-2xl bg-slate-900 border border-slate-800 text-xs">
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-slate-400" />
          <span className="text-slate-400 font-medium">Status Filter:</span>
          {['', 'AVAILABLE', 'OCCUPIED', 'RESERVED', 'MAINTENANCE', 'DISABLED'].map((st) => (
            <button
              key={st}
              onClick={() => setSelectedStatus(st)}
              className={`px-3 py-1 rounded-lg font-semibold transition ${
                selectedStatus === st
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                  : 'bg-slate-800 text-slate-400 hover:text-white'
              }`}
            >
              {st || 'All States'}
            </button>
          ))}
        </div>

        {selectedCategory && (
          <button
            onClick={() => setSelectedCategory('')}
            className="text-xs text-cyan-400 hover:underline"
          >
            Clear category filter
          </button>
        )}
      </div>

      {/* Visual Slot Grid */}
      {slots.length === 0 ? (
        <div className="p-12 text-center bg-slate-900/50 rounded-2xl border border-slate-800 text-slate-400">
          <AlertCircle className="w-10 h-10 mx-auto text-amber-400 mb-2" />
          <h3 className="text-base font-bold text-white">No parking bays match filter</h3>
          <p className="text-xs mt-1">Try resetting the status or category filter.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3.5">
          {slots.map((slot) => (
            <SlotCard key={slot._id} slot={slot} onSelect={handleSlotSelect} />
          ))}
        </div>
      )}

      {/* Slot Details & Actions Modal */}
      <SlotDetailsModal
        slot={selectedSlot}
        isOpen={modalOpen}
        onClose={() => setModalOpen(false)}
        onRefresh={fetchLayout}
        navigateToExit={(ticketNumber) => navigate(`/exit?ticket=${ticketNumber}`)}
      />
    </div>
  );
};

export default LiveParkingLayoutPage;
