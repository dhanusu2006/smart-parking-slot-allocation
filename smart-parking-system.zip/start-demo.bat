@echo off
echo ======================================================================
echo   SMART PARKING SLOT ALLOCATION AND MANAGEMENT SYSTEM (MERN)
echo ======================================================================
echo.

cd /d "%~dp0\server"
echo [1/3] Seeding database with initial roles, slots, and tariffs...
call node config/seed.js

echo.
echo [2/3] Starting Backend API Server (Port 5000)...
start "Smart Parking Server (API)" cmd /k "cd /d %~dp0\server && npm run dev"

echo.
echo [3/3] Starting Frontend Client (Vite)...
start "Smart Parking Client (Vite)" cmd /k "cd /d %~dp0\client && npm run dev"

timeout /t 3 /nobreak >nul
start http://localhost:5173

echo.
echo Application launched!
echo - Frontend: http://localhost:5173
echo - Backend:  http://localhost:5000/api/health
echo.
echo Demo Credentials:
echo   Super Admin:     admin@parking.com      / Admin@12345
echo   Parking Manager: manager@parking.com    / Admin@12345
echo   Parking Staff:   staff@parking.com      / Admin@12345
echo   Accountant:      accountant@parking.com / Admin@12345
echo   Customer:        customer@parking.com   / Customer@12345
echo ======================================================================
pause
