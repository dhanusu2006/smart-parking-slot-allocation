import mongoose from 'mongoose';
import { VEHICLE_CATEGORIES } from '../config/constants.js';

const pricingRuleSchema = new mongoose.Schema(
  {
    category: {
      type: String,
      enum: Object.values(VEHICLE_CATEGORIES),
      required: true,
      unique: true,
      index: true
    },
    hourlyRate: {
      type: Number,
      required: true,
      min: [0, 'Hourly rate cannot be negative']
    },
    dailyRate: {
      type: Number,
      required: true,
      min: [0, 'Daily rate cannot be negative']
    },
    monthlyRate: {
      type: Number,
      required: true,
      min: [0, 'Monthly rate cannot be negative']
    },
    yearlyRate: {
      type: Number,
      required: true,
      min: [0, 'Yearly rate cannot be negative']
    },
    gracePeriodMinutes: {
      type: Number,
      default: 15,
      min: [0, 'Grace period cannot be negative']
    },
    overtimeRatePerHour: {
      type: Number,
      required: true,
      min: [0, 'Overtime rate cannot be negative']
    },
    taxPercent: {
      type: Number,
      default: 18,
      min: [0, 'Tax percentage cannot be negative'],
      max: [100, 'Tax percentage cannot exceed 100']
    },
    discountPercent: {
      type: Number,
      default: 0,
      min: [0, 'Discount percentage cannot be negative'],
      max: [100, 'Discount percentage cannot exceed 100']
    },
    effectiveDate: {
      type: Date,
      default: Date.now
    },
    isActive: {
      type: Boolean,
      default: true
    },
    lastUpdatedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User'
    },
    lastUpdateReason: {
      type: String,
      default: ''
    }
  },
  {
    timestamps: true
  }
);

export default mongoose.model('PricingRule', pricingRuleSchema);
