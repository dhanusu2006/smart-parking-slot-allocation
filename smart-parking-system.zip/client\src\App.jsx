import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { ThemeProvider } from './context/ThemeContext';

import MainLayout from './layouts/MainLayout';
import LoginPage from './pages/LoginPage';
import DashboardPage from './pages/DashboardPage';
import LiveParkingLayoutPage from './pages/LiveParkingLayoutPage';
import VehicleEntryPage from './pages/VehicleEntryPage';
import VehicleExitCheckoutPage from './pages/VehicleExitCheckoutPage';
import PricingManagementPage from './pages/PricingManagementPage';
import PassesSubscriptionsPage from './pages/PassesSubscriptionsPage';
import PaymentsFinancialsPage from './pages/PaymentsFinancialsPage';
import ExpensesPage from './pages/ExpensesPage';
import WaitingListPage from './pages/WaitingListPage';
import AuditLogsReportsPage from './pages/AuditLogsReportsPage';

const ProtectedRoute = ({ children }) => {
  const { isAuthenticated, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center text-slate-400 text-xs">
        Initializing Smart Parking System...
      </div>
    );
  }

  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }

  return children;
};

export default function App() {
  return (
    <ThemeProvider>
      <AuthProvider>
        <BrowserRouter>
          <Routes>
            {/* Public Login Route */}
            <Route path="/login" element={<LoginPage />} />

            {/* Protected Core Portal Routes */}
            <Route
              path="/"
              element={
                <ProtectedRoute>
                  <MainLayout />
                </ProtectedRoute>
              }
            >
              <Route index element={<DashboardPage />} />
              <Route path="layout" element={<LiveParkingLayoutPage />} />
              <Route path="entry" element={<VehicleEntryPage />} />
              <Route path="exit" element={<VehicleExitCheckoutPage />} />
              <Route path="pricing" element={<PricingManagementPage />} />
              <Route path="passes" element={<PassesSubscriptionsPage />} />
              <Route path="payments" element={<PaymentsFinancialsPage />} />
              <Route path="expenses" element={<ExpensesPage />} />
              <Route path="waiting-list" element={<WaitingListPage />} />
              <Route path="reports" element={<AuditLogsReportsPage />} />
            </Route>

            {/* Fallback */}
            <Route path="*" element={<Navigate to="/" replace />} />
          </Routes>
        </BrowserRouter>
      </AuthProvider>
    </ThemeProvider>
  );
}
