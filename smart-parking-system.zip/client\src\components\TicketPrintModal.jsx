import React from 'react';
import { X, Printer, QrCode, CheckCircle2 } from 'lucide-react';

export const TicketPrintModal = ({ ticket, isOpen, onClose }) => {
  if (!isOpen || !ticket) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-2xl p-6 shadow-2xl relative text-slate-100">
        {/* Actions bar (hidden in print) */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 no-print">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4" /> Entry Pass Issued
          </span>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Ticket Receipt Card */}
        <div className="bg-white text-slate-900 rounded-xl p-5 my-4 border border-slate-300 shadow-md">
          <div className="text-center pb-3 border-b border-dashed border-slate-300">
            <h2 className="font-extrabold text-lg tracking-wider text-slate-900 uppercase">
              Smart Parking Facility
            </h2>
            <p className="text-[11px] text-slate-500">Automated Vehicle Entry Token</p>
          </div>

          {/* QR Code */}
          <div className="flex flex-col items-center justify-center my-4">
            {ticket.qrCodeData ? (
              <img src={ticket.qrCodeData} alt="Ticket QR Code" className="w-36 h-36 border p-1 rounded-lg" />
            ) : (
              <div className="w-36 h-36 bg-slate-100 flex items-center justify-center rounded-lg border">
                <QrCode className="w-16 h-16 text-slate-400" />
              </div>
            )}
            <span className="font-mono font-extrabold text-sm text-slate-900 tracking-wider mt-2">
              {ticket.ticketNumber}
            </span>
          </div>

          {/* Details Table */}
          <div className="space-y-1.5 text-xs border-t border-dashed border-slate-300 pt-3">
            <div className="flex justify-between">
              <span className="text-slate-500">Vehicle No:</span>
              <span className="font-mono font-bold text-slate-900">{ticket.vehicleNumber}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Vehicle Category:</span>
              <span className="font-semibold text-slate-900">{ticket.category?.replace('_', ' ')}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Assigned Bay:</span>
              <span className="font-mono font-extrabold text-emerald-700 text-sm bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
                {ticket.slotNumber}
              </span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Customer Name:</span>
              <span className="font-medium text-slate-900">{ticket.customerName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Entry Time:</span>
              <span className="font-medium text-slate-900">{new Date(ticket.entryTime).toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Billing Plan:</span>
              <span className="font-semibold text-cyan-800">{ticket.billingPlan}</span>
            </div>
            {ticket.hasPass && (
              <div className="bg-emerald-100 border border-emerald-300 text-emerald-800 text-[10px] font-bold text-center py-1 rounded mt-1">
                ACTIVE SUBSCRIPTION PASS ATTACHED
              </div>
            )}
          </div>

          <div className="text-center text-[10px] text-slate-400 border-t border-dashed border-slate-300 mt-4 pt-2">
            Please retain this ticket. Scan QR at exit barrier for automated checkout.
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2 no-print">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
          >
            Close
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-lg glow-cyan transition"
          >
            <Printer className="w-4 h-4" /> Print Ticket
          </button>
        </div>
      </div>
    </div>
  );
};

export default TicketPrintModal;
