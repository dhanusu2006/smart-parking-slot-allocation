import React, { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api';

const AuthContext = createContext();

export const DEMO_CREDENTIALS = {
  SUPER_ADMIN: { email: 'admin@parking.com', password: 'Admin@12345', label: 'Super Admin' },
  PARKING_MANAGER: { email: 'manager@parking.com', password: 'Admin@12345', label: 'Parking Manager' },
  PARKING_STAFF: { email: 'staff@parking.com', password: 'Admin@12345', label: 'Parking Staff' },
  ACCOUNTANT: { email: 'accountant@parking.com', password: 'Admin@12345', label: 'Accountant' },
  CUSTOMER: { email: 'customer@parking.com', password: 'Customer@12345', label: 'Customer' }
};

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null);
  const [token, setToken] = useState(localStorage.getItem('parking_token'));
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      const storedToken = localStorage.getItem('parking_token');
      if (storedToken) {
        try {
          const res = await api.get('/auth/me');
          if (res.success) {
            setUser(res.user);
          }
        } catch (err) {
          console.warn('Session expired or invalid:', err.message);
          localStorage.removeItem('parking_token');
          localStorage.removeItem('parking_user');
          setUser(null);
          setToken(null);
        }
      }
      setLoading(false);
    };

    checkAuth();
  }, []);

  const login = async (email, password) => {
    const res = await api.post('/auth/login', { email, password });
    if (res.success) {
      localStorage.setItem('parking_token', res.token);
      localStorage.setItem('parking_user', JSON.stringify(res.user));
      setToken(res.token);
      setUser(res.user);
      return res.user;
    }
  };

  const quickLogin = async (roleKey) => {
    const creds = DEMO_CREDENTIALS[roleKey];
    if (creds) {
      return await login(creds.email, creds.password);
    }
  };

  const logout = () => {
    localStorage.removeItem('parking_token');
    localStorage.removeItem('parking_user');
    setUser(null);
    setToken(null);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        token,
        loading,
        role: user?.role,
        isAuthenticated: !!user,
        login,
        quickLogin,
        logout
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
