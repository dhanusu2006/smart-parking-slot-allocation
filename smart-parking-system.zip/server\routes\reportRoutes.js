import express from 'express';
import { globalSearch, exportSessionsCSV, exportPaymentsCSV } from '../controllers/reportController.js';
import { protect, restrictTo } from '../middleware/auth.js';
import { USER_ROLES } from '../config/constants.js';

const router = express.Router();

router.get('/search', protect, globalSearch);
router.get('/export/sessions', protect, restrictTo(USER_ROLES.SUPER_ADMIN, USER_ROLES.PARKING_MANAGER, USER_ROLES.ACCOUNTANT), exportSessionsCSV);
router.get('/export/payments', protect, restrictTo(USER_ROLES.SUPER_ADMIN, USER_ROLES.ACCOUNTANT), exportPaymentsCSV);

export default router;
