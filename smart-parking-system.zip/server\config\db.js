import mongoose from 'mongoose';

let memoryServer = null;

export const connectDB = async () => {
  const uri = process.env.MONGO_URI;

  try {
    if (uri && uri.trim() !== '') {
      await mongoose.connect(uri, {
        serverSelectionTimeoutMS: 4000
      });
      console.log(`[Database] Connected successfully to MongoDB: ${mongoose.connection.host}/${mongoose.connection.name}`);
      return;
    }
  } catch (err) {
    console.warn(`[Database] Could not connect to configured MONGO_URI (${err.message}). Starting MongoMemoryServer fallback...`);
  }

  // Fallback to in-memory MongoDB for local testing / zero-config demo
  try {
    const { MongoMemoryServer } = await import('mongodb-memory-server');
    memoryServer = await MongoMemoryServer.create({
      instance: {
        dbName: 'smart_parking'
      }
    });
    const memUri = memoryServer.getUri();
    await mongoose.connect(memUri);
    console.log(`[Database] In-Memory MongoDB running at: ${memUri}`);
  } catch (memErr) {
    console.error('[Database] Failed to initialize in-memory database:', memErr.message);
    throw memErr;
  }
};

export const closeDB = async () => {
  await mongoose.disconnect();
  if (memoryServer) {
    await memoryServer.stop();
  }
};
