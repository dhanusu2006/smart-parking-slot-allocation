import QRCode from 'qrcode';
import ParkingSession from '../models/ParkingSession.js';
import ParkingSlot from '../models/ParkingSlot.js';
import Subscription from '../models/Subscription.js';
import Payment from '../models/Payment.js';
import { SLOT_STATUSES, BILLING_PLANS, PAYMENT_METHODS, PAYMENT_STATUSES } from '../config/constants.js';
import { capturePricingSnapshot, calculateParkingFee } from '../services/pricingEngine.js';
import { allocateOptimalSlot, allocateSpecificSlot, releaseSlot } from '../services/slotAllocationService.js';
import { checkCapacityAlerts } from '../services/notificationService.js';
import { logAuditEvent } from '../services/auditService.js';
import { createGatewayOrder, verifyGatewaySignature } from '../services/paymentGatewayService.js';

export const registerVehicleEntry = async (req, res, next) => {
  try {
    const {
      vehicleNumber,
      category,
      customerName,
      customerPhone,
      billingPlan = BILLING_PLANS.HOURLY,
      slotId, // Optional manual slot allocation
      preferEv = false,
      dimensions
    } = req.body;

    const cleanPlate = vehicleNumber.trim().toUpperCase();

    // Check if vehicle already has an active inside session
    const existingActive = await ParkingSession.findOne({
      vehicleNumber: cleanPlate,
      status: 'ACTIVE'
    });
    if (existingActive) {
      return res.status(400).json({
        success: false,
        message: `Vehicle ${cleanPlate} already has an active entry in slot ${existingActive.slotNumber} (Ticket: ${existingActive.ticketNumber})`
      });
    }

    // Check if vehicle has an active monthly/yearly pass
    const activePass = await Subscription.findOne({
      vehicleNumber: cleanPlate,
      category,
      status: 'ACTIVE',
      endDate: { $gte: new Date() }
    });

    let assignedPlan = billingPlan;
    let subscriptionRef = null;
    if (activePass) {
      assignedPlan = activePass.planType === 'YEARLY' ? BILLING_PLANS.YEARLY : BILLING_PLANS.MONTHLY;
      subscriptionRef = activePass._id;
      // Increment pass usage
      activePass.usageCount = (activePass.usageCount || 0) + 1;
      activePass.lastUsedAt = new Date();
      await activePass.save();
    }

    // Capture pricing snapshot
    const priceSnapshot = await capturePricingSnapshot(category);

    // Slot Allocation: Manual or Automatic
    let allocatedSlot = null;
    if (slotId) {
      allocatedSlot = await allocateSpecificSlot({
        slotId,
        category,
        vehiclePlate: cleanPlate,
        dimensions
      });
    } else {
      allocatedSlot = await allocateOptimalSlot({
        category,
        vehiclePlate: cleanPlate,
        dimensions,
        preferEv
      });
    }

    if (!allocatedSlot) {
      return res.status(409).json({
        success: false,
        isFull: true,
        message: `No compatible ${category} parking slots are currently available. You may join the waiting list.`
      });
    }

    // Generate unique Ticket ID
    const todayStr = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randSuffix = Math.floor(1000 + Math.random() * 9000);
    const ticketNumber = `TKT-${todayStr}-${randSuffix}`;

    // Generate QR Code data URL containing ticket verification payload
    const qrPayload = JSON.stringify({
      ticketNumber,
      plate: cleanPlate,
      slot: allocatedSlot.slotNumber,
      category,
      entry: new Date().toISOString()
    });
    const qrCodeData = await QRCode.toDataURL(qrPayload);

    // Create session record
    const session = await ParkingSession.create({
      ticketNumber,
      vehicleNumber: cleanPlate,
      category,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      slot: allocatedSlot._id,
      slotNumber: allocatedSlot.slotNumber,
      billingPlan: assignedPlan,
      entryTime: new Date(),
      priceSnapshot,
      status: 'ACTIVE',
      paymentStatus: activePass ? 'PAID' : 'UNPAID',
      qrCodeData,
      entryOperator: req.user?._id || null,
      subscriptionId: subscriptionRef
    });

    // Link session to slot
    allocatedSlot.currentSession = session._id;
    await allocatedSlot.save();

    // Check if slots are now full for this category
    checkCapacityAlerts(category);

    await logAuditEvent({
      req,
      action: 'VEHICLE_ENTRY',
      resourceType: 'PARKING_SESSION',
      resourceId: session.ticketNumber,
      newValues: {
        ticketNumber: session.ticketNumber,
        plate: session.vehicleNumber,
        slotNumber: session.slotNumber,
        category: session.category,
        hasPass: !!activePass
      },
      reason: 'Vehicle entry recorded'
    });

    res.status(201).json({
      success: true,
      message: `Entry recorded successfully for vehicle ${cleanPlate} at slot ${allocatedSlot.slotNumber}`,
      session,
      ticket: {
        ticketNumber: session.ticketNumber,
        vehicleNumber: session.vehicleNumber,
        category: session.category,
        customerName: session.customerName,
        customerPhone: session.customerPhone,
        slotNumber: session.slotNumber,
        entryTime: session.entryTime,
        billingPlan: session.billingPlan,
        hasPass: !!activePass,
        qrCodeData
      }
    });
  } catch (err) {
    next(err);
  }
};

export const getActiveSessionDetails = async (req, res, next) => {
  try {
    const { identifier } = req.params; // ticketNumber, vehicleNumber, or slotNumber
    const cleanId = identifier.trim().toUpperCase();

    const session = await ParkingSession.findOne({
      $or: [
        { ticketNumber: cleanId },
        { vehicleNumber: cleanId },
        { slotNumber: cleanId }
      ],
      status: 'ACTIVE'
    }).populate('slot');

    if (!session) {
      return res.status(404).json({
        success: false,
        message: `No active parking session found for '${cleanId}'`
      });
    }

    const feeBreakdown = calculateParkingFee({
      entryTime: session.entryTime,
      exitTime: new Date(),
      billingPlan: session.billingPlan,
      priceSnapshot: session.priceSnapshot
    });

    res.json({
      success: true,
      session,
      feeBreakdown
    });
  } catch (err) {
    next(err);
  }
};

export const processVehicleExit = async (req, res, next) => {
  try {
    const {
      ticketNumber,
      paymentMethod = PAYMENT_METHODS.CASH,
      customDiscountPercent = 0,
      gatewayDetails = {},
      notes = ''
    } = req.body;

    const session = await ParkingSession.findOne({
      ticketNumber: ticketNumber.trim().toUpperCase(),
      status: 'ACTIVE'
    });

    if (!session) {
      return res.status(404).json({
        success: false,
        message: `Active parking session not found for ticket ${ticketNumber}`
      });
    }

    const exitTime = new Date();
    const feeCalculation = calculateParkingFee({
      entryTime: session.entryTime,
      exitTime,
      billingPlan: session.billingPlan,
      priceSnapshot: session.priceSnapshot,
      customDiscountPercent
    });

    // If online payment method, verify gateway signature / simulation
    if (paymentMethod === PAYMENT_METHODS.ONLINE_GATEWAY) {
      const verification = verifyGatewaySignature({
        orderId: gatewayDetails.gatewayOrderId,
        paymentId: gatewayDetails.gatewayPaymentId,
        signature: gatewayDetails.gatewaySignature
      });

      if (!verification.valid && !gatewayDetails.isSandbox) {
        return res.status(400).json({
          success: false,
          message: `Payment gateway verification failed: ${verification.reason}`
        });
      }
    }

    // Generate unique transaction ID
    const txnDate = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const randTxn = Math.floor(100000 + Math.random() * 900000);
    const transactionId = `TXN-${txnDate}-${randTxn}`;

    // Create Payment record
    const payment = await Payment.create({
      transactionId,
      session: session._id,
      customerName: session.customerName,
      customerPhone: session.customerPhone,
      vehicleNumber: session.vehicleNumber,
      baseAmount: feeCalculation.baseAmount,
      discountAmount: feeCalculation.discountAmount,
      taxAmount: feeCalculation.taxAmount,
      penaltyAmount: feeCalculation.penaltyAmount,
      totalAmount: feeCalculation.totalAmount,
      paymentMethod,
      status: PAYMENT_STATUSES.PAID,
      gatewayDetails: {
        gatewayName: paymentMethod === PAYMENT_METHODS.ONLINE_GATEWAY ? (gatewayDetails.gatewayName || 'Sandbox Gateway') : paymentMethod,
        gatewayPaymentId: gatewayDetails.gatewayPaymentId || `MOCK-${Date.now()}`,
        gatewayOrderId: gatewayDetails.gatewayOrderId || null,
        isSandbox: gatewayDetails.isSandbox !== false
      },
      notes
    });

    // Update Session
    session.exitTime = exitTime;
    session.durationMinutes = feeCalculation.durationMinutes;
    session.baseAmount = feeCalculation.baseAmount;
    session.discountAmount = feeCalculation.discountAmount;
    session.taxAmount = feeCalculation.taxAmount;
    session.penaltyAmount = feeCalculation.penaltyAmount;
    session.totalAmount = feeCalculation.totalAmount;
    session.status = 'COMPLETED';
    session.paymentStatus = 'PAID';
    session.payment = payment._id;
    session.exitOperator = req.user?._id || null;
    await session.save();

    // Release parking slot atomically back to AVAILABLE
    await releaseSlot(session.slot);

    await logAuditEvent({
      req,
      action: 'VEHICLE_EXIT_COMPLETED',
      resourceType: 'PARKING_SESSION',
      resourceId: session.ticketNumber,
      newValues: {
        totalAmount: session.totalAmount,
        paymentMethod,
        transactionId: payment.transactionId,
        releasedSlot: session.slotNumber
      },
      reason: 'Vehicle exit processed and slot cleared'
    });

    res.json({
      success: true,
      message: `Exit checkout complete for ${session.vehicleNumber}. Slot ${session.slotNumber} is now released.`,
      session,
      payment,
      receipt: {
        receiptNumber: transactionId,
        ticketNumber: session.ticketNumber,
        vehicleNumber: session.vehicleNumber,
        category: session.category,
        customerName: session.customerName,
        customerPhone: session.customerPhone,
        slotNumber: session.slotNumber,
        billingPlan: session.billingPlan,
        entryTime: session.entryTime,
        exitTime: session.exitTime,
        durationFormatted: feeCalculation.durationFormatted,
        baseAmount: feeCalculation.baseAmount,
        discountAmount: feeCalculation.discountAmount,
        taxAmount: feeCalculation.taxAmount,
        penaltyAmount: feeCalculation.penaltyAmount,
        totalAmount: feeCalculation.totalAmount,
        paymentMethod,
        paidAt: payment.createdAt
      }
    });
  } catch (err) {
    next(err);
  }
};

export const correctEntryDetails = async (req, res, next) => {
  try {
    const { sessionId } = req.params;
    const { vehicleNumber, customerName, customerPhone, reason } = req.body;

    if (!reason) {
      return res.status(400).json({ success: false, message: 'A valid reason is required for correction audit' });
    }

    const session = await ParkingSession.findById(sessionId);
    if (!session) {
      return res.status(404).json({ success: false, message: 'Parking session not found' });
    }

    const previousValues = {
      vehicleNumber: session.vehicleNumber,
      customerName: session.customerName,
      customerPhone: session.customerPhone
    };

    if (vehicleNumber) session.vehicleNumber = vehicleNumber.trim().toUpperCase();
    if (customerName) session.customerName = customerName.trim();
    if (customerPhone) session.customerPhone = customerPhone.trim();

    session.correctionHistory.push({
      correctedAt: new Date(),
      correctedBy: req.user._id,
      previousValues,
      newValues: {
        vehicleNumber: session.vehicleNumber,
        customerName: session.customerName,
        customerPhone: session.customerPhone
      },
      reason
    });

    await session.save();

    await logAuditEvent({
      req,
      action: 'ENTRY_DETAILS_CORRECTED',
      resourceType: 'PARKING_SESSION',
      resourceId: session.ticketNumber,
      oldValues: previousValues,
      newValues: {
        vehicleNumber: session.vehicleNumber,
        customerName: session.customerName,
        customerPhone: session.customerPhone
      },
      reason
    });

    res.json({
      success: true,
      message: 'Entry details corrected and recorded in audit log',
      session
    });
  } catch (err) {
    next(err);
  }
};
