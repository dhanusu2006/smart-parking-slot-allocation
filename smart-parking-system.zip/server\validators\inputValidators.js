import { VEHICLE_CATEGORIES, BILLING_PLANS, PAYMENT_METHODS } from '../config/constants.js';

export const validateVehicleEntry = (body) => {
  const errors = [];
  if (!body.vehicleNumber || typeof body.vehicleNumber !== 'string' || body.vehicleNumber.trim().length < 3) {
    errors.push('A valid vehicle license plate number is required (min 3 characters)');
  }
  if (!body.category || !Object.values(VEHICLE_CATEGORIES).includes(body.category)) {
    errors.push(`Category must be one of: ${Object.values(VEHICLE_CATEGORIES).join(', ')}`);
  }
  if (!body.customerName || typeof body.customerName !== 'string' || body.customerName.trim().length === 0) {
    errors.push('Customer name is required');
  }
  if (!body.customerPhone || typeof body.customerPhone !== 'string' || body.customerPhone.trim().length < 6) {
    errors.push('Customer phone number is required (min 6 digits)');
  }
  if (body.billingPlan && !Object.values(BILLING_PLANS).includes(body.billingPlan)) {
    errors.push(`Billing plan must be one of: ${Object.values(BILLING_PLANS).join(', ')}`);
  }
  return {
    isValid: errors.length === 0,
    errors
  };
};

export const validateExitPayment = (body) => {
  const errors = [];
  if (!body.ticketNumber || typeof body.ticketNumber !== 'string') {
    errors.push('Ticket number is required for checkout');
  }
  if (body.paymentMethod && !Object.values(PAYMENT_METHODS).includes(body.paymentMethod)) {
    errors.push(`Payment method must be one of: ${Object.values(PAYMENT_METHODS).join(', ')}`);
  }
  return {
    isValid: errors.length === 0,
    errors
  };
};
