import Payment from '../models/Payment.js';
import Expense from '../models/Expense.js';
import { PAYMENT_STATUSES, USER_ROLES } from '../config/constants.js';
import { logAuditEvent } from '../services/auditService.js';
import { createGatewayOrder } from '../services/paymentGatewayService.js';

export const getAllPayments = async (req, res, next) => {
  try {
    const { status, paymentMethod, startDate, endDate, search } = req.query;
    const filter = {};

    if (status) filter.status = status;
    if (paymentMethod) filter.paymentMethod = paymentMethod;

    if (startDate || endDate) {
      filter.createdAt = {};
      if (startDate) filter.createdAt.$gte = new Date(startDate);
      if (endDate) filter.createdAt.$lte = new Date(endDate);
    }

    if (search) {
      const cleanSearch = search.trim();
      filter.$or = [
        { transactionId: { $regex: cleanSearch, $options: 'i' } },
        { vehicleNumber: { $regex: cleanSearch, $options: 'i' } },
        { customerName: { $regex: cleanSearch, $options: 'i' } },
        { customerPhone: { $regex: cleanSearch, $options: 'i' } }
      ];
    }

    const payments = await Payment.find(filter)
      .populate('session', 'ticketNumber slotNumber billingPlan entryTime exitTime')
      .populate('subscription', 'passNumber planType')
      .populate('refundAuthorizedBy', 'name email role')
      .sort({ createdAt: -1 });

    // Aggregate summary statistics
    let totalRevenue = 0;
    let totalRefunds = 0;
    payments.forEach((p) => {
      if (p.status === PAYMENT_STATUSES.PAID) totalRevenue += p.totalAmount;
      if (p.status === PAYMENT_STATUSES.REFUNDED) totalRefunds += p.totalAmount;
    });

    res.json({
      success: true,
      count: payments.length,
      summary: {
        totalRevenue: Math.round(totalRevenue * 100) / 100,
        totalRefunds: Math.round(totalRefunds * 100) / 100,
        netCollected: Math.round((totalRevenue - totalRefunds) * 100) / 100
      },
      payments
    });
  } catch (err) {
    next(err);
  }
};

export const getPaymentById = async (req, res, next) => {
  try {
    const payment = await Payment.findById(req.params.id)
      .populate('session')
      .populate('subscription')
      .populate('refundAuthorizedBy', 'name email role');

    if (!payment) {
      return res.status(404).json({ success: false, message: 'Payment record not found' });
    }

    res.json({ success: true, payment });
  } catch (err) {
    next(err);
  }
};

export const processRefund = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;

    if (!reason || reason.trim() === '') {
      return res.status(400).json({ success: false, message: 'A justification reason is required to process a refund' });
    }

    const payment = await Payment.findById(id);
    if (!payment) {
      return res.status(404).json({ success: false, message: 'Payment not found' });
    }

    if (payment.status === PAYMENT_STATUSES.REFUNDED) {
      return res.status(400).json({ success: false, message: 'This transaction has already been refunded' });
    }

    payment.status = PAYMENT_STATUSES.REFUNDED;
    payment.refundReason = reason;
    payment.refundAuthorizedBy = req.user._id;
    payment.refundDate = new Date();
    await payment.save();

    // Automatically record an Expense entry under REFUND category to maintain financial ledger accuracy!
    await Expense.create({
      title: `Refund for Txn ${payment.transactionId}`,
      category: 'REFUND',
      amount: payment.totalAmount,
      date: new Date(),
      description: `Authorized refund for vehicle ${payment.vehicleNumber}. Reason: ${reason}`,
      paymentMethod: payment.paymentMethod,
      createdBy: req.user._id,
      referenceNumber: payment.transactionId
    });

    await logAuditEvent({
      req,
      action: 'PAYMENT_REFUNDED',
      resourceType: 'PAYMENT',
      resourceId: payment.transactionId,
      newValues: {
        refundedAmount: payment.totalAmount,
        reason,
        authorizedBy: req.user.name
      },
      reason
    });

    res.json({
      success: true,
      message: `Refund of ₹${payment.totalAmount} approved and processed successfully`,
      payment
    });
  } catch (err) {
    next(err);
  }
};

export const createOnlineOrder = async (req, res, next) => {
  try {
    const { amount, receipt } = req.body;
    const order = createGatewayOrder({ amount, receipt });
    res.json({ success: true, order });
  } catch (err) {
    next(err);
  }
};
