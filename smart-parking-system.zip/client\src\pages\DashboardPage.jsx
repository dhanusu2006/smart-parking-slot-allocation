import React, { useState, useEffect } from 'react';
import {
  Car,
  CheckCircle,
  Clock,
  AlertTriangle,
  IndianRupee,
  TrendingUp,
  Receipt,
  ShieldCheck,
  RefreshCw,
  ArrowUpRight
} from 'lucide-react';
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell
} from 'recharts';
import api from '../services/api';
import StatCard from '../components/StatCard';
import RoadLaneAnimation from '../components/RoadLaneAnimation';

const CATEGORY_COLORS = {
  TWO_WHEELER: '#10b981', // emerald
  FOUR_WHEELER: '#06b6d4', // cyan
  COMMERCIAL: '#6366f1',  // indigo
  HEAVY: '#a855f7'        // purple
};

export const DashboardPage = () => {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      const res = await api.get('/dashboard/metrics');
      if (res.success) {
        setData(res);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
    const interval = setInterval(fetchDashboardData, 20000); // 20s auto refresh
    return () => clearInterval(interval);
  }, []);

  if (loading && !data) {
    return (
      <div className="flex flex-col items-center justify-center min-h-[60vh] text-slate-400 gap-3">
        <RefreshCw className="w-8 h-8 animate-spin text-cyan-400" />
        <p className="text-sm font-medium">Loading real-time facility metrics from MongoDB...</p>
      </div>
    );
  }

  const { metrics, categoryOccupancy, trafficTrends, recentTransactions, recentActivities } = data || {};

  return (
    <div className="space-y-6">
      {/* Top Banner with Title & Refresh */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            Facility Command Center
            <span className="text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2.5 py-0.5 rounded-full font-bold">
              LIVE
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Real-time occupancy tracking, dynamic revenue analytics, and automated slot allocations.
          </p>
        </div>
        <button
          onClick={fetchDashboardData}
          className="flex items-center gap-2 px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition self-start sm:self-auto"
        >
          <RefreshCw className="w-3.5 h-3.5" /> Refresh Data
        </button>
      </div>

      {/* Animated Futuristic Expressway Lane */}
      <RoadLaneAnimation />

      {/* Metrics Row 1: Occupancy & Slots */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard
          title="Total Parking Bays"
          value={metrics?.totalSlots || 0}
          subtext={`${metrics?.availableSlots || 0} Ready to Park`}
          icon={Car}
          color="cyan"
        />
        <StatCard
          title="Vehicles Parked"
          value={metrics?.vehiclesCurrentlyParked || 0}
          subtext={`${metrics?.activeParkingSessions || 0} Active Sessions`}
          icon={Clock}
          color="rose"
        />
        <StatCard
          title="Available Slots"
          value={metrics?.availableSlots || 0}
          subtext={`${metrics?.reservedSlots || 0} Reserved Bays`}
          icon={CheckCircle}
          color="emerald"
        />
        <StatCard
          title="Maintenance Bays"
          value={metrics?.maintenanceSlots || 0}
          subtext={`${metrics?.disabledSlots || 0} Disabled Bays`}
          icon={AlertTriangle}
          color="amber"
        />
      </div>

      {/* Metrics Row 2: Financials & Profitability */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Today's Collections"
          value={`₹${(metrics?.todayCollections || 0).toLocaleString()}`}
          subtext="Processed payments"
          icon={IndianRupee}
          trend="+14% today"
          color="emerald"
        />
        <StatCard
          title="Monthly Revenue"
          value={`₹${(metrics?.monthlyRevenue || 0).toLocaleString()}`}
          subtext="Current calendar month"
          icon={TrendingUp}
          color="cyan"
        />
        <StatCard
          title="Operating Expenses"
          value={`₹${(metrics?.totalExpenses || 0).toLocaleString()}`}
          subtext="Utilities, repairs, staff"
          icon={Receipt}
          color="amber"
        />
        <StatCard
          title="Net Operating Profit"
          value={`₹${(metrics?.netProfit || 0).toLocaleString()}`}
          subtext="Revenue minus expenses"
          icon={ShieldCheck}
          trend="+Net margin"
          color="indigo"
        />
      </div>

      {/* Analytics Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Daily Traffic & Revenue Trends */}
        <div className="lg:col-span-2 p-5 rounded-2xl bg-slate-900 border border-slate-800 backdrop-blur-md shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                Traffic & Revenue Trend (Past 7 Days)
              </h2>
              <p className="text-xs text-slate-400">Daily entry volume and completed collections</p>
            </div>
            <div className="flex items-center gap-3 text-xs">
              <span className="flex items-center gap-1.5 text-cyan-400">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span> Entries
              </span>
              <span className="flex items-center gap-1.5 text-emerald-400">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span> Revenue (₹)
              </span>
            </div>
          </div>

          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={trafficTrends || []}>
                <defs>
                  <linearGradient id="colorRevenue" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                  </linearGradient>
                  <linearGradient id="colorEntries" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#06b6d4" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#06b6d4" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                <XAxis dataKey="date" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis yAxisId="left" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis yAxisId="right" orientation="right" stroke="#64748b" tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '12px', fontSize: '12px' }}
                />
                <Area yAxisId="left" type="monotone" dataKey="entries" stroke="#06b6d4" fillOpacity={1} fill="url(#colorEntries)" name="Vehicle Entries" />
                <Area yAxisId="right" type="monotone" dataKey="revenue" stroke="#10b981" fillOpacity={1} fill="url(#colorRevenue)" name="Revenue (₹)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Vehicle Category Breakdown */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 backdrop-blur-md shadow-xl flex flex-col justify-between">
          <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-wider mb-1">
              Category-Wise Capacity
            </h2>
            <p className="text-xs text-slate-400 mb-4">Occupancy distribution across 4 classes</p>

            <div className="space-y-3">
              {(categoryOccupancy || []).map((cat) => (
                <div key={cat.category} className="space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-white">{cat.category.replace('_', ' ')}</span>
                    <span className="text-slate-400">
                      {cat.occupied} / {cat.total} ({cat.percentage}%)
                    </span>
                  </div>
                  <div className="w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-500"
                      style={{
                        width: `${cat.percentage}%`,
                        backgroundColor: CATEGORY_COLORS[cat.category] || '#06b6d4'
                      }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="mt-6 pt-4 border-t border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
            <span>Slot Allocations Enforced</span>
            <span className="text-emerald-400 font-bold">100% Atomic</span>
          </div>
        </div>
      </div>

      {/* Recent Transactions & Audit Feed */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Transactions */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              Recent Transactions
            </h2>
            <span className="text-xs text-cyan-400 font-medium">Real-time</span>
          </div>
          <div className="divide-y divide-slate-800/80">
            {(recentTransactions || []).slice(0, 5).map((t) => (
              <div key={t._id} className="py-2.5 flex items-center justify-between text-xs">
                <div>
                  <div className="font-mono font-bold text-white">{t.vehicleNumber}</div>
                  <div className="text-[10px] text-slate-400">{t.transactionId} • {t.paymentMethod}</div>
                </div>
                <div className="text-right">
                  <div className="font-mono font-bold text-emerald-400">₹{t.totalAmount?.toFixed(2)}</div>
                  <div className="text-[10px] text-slate-400">{new Date(t.createdAt).toLocaleTimeString()}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Live Audit Activity Log */}
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-white uppercase tracking-wider">
              System Audit Stream
            </h2>
            <span className="text-xs text-slate-400">Security & Operational Logs</span>
          </div>
          <div className="divide-y divide-slate-800/80">
            {(recentActivities || []).slice(0, 5).map((a) => (
              <div key={a._id} className="py-2.5 flex items-center justify-between text-xs">
                <div>
                  <div className="font-semibold text-slate-200">{a.action}</div>
                  <div className="text-[10px] text-slate-400">{a.reason || 'Authorized operation'} • By {a.userName}</div>
                </div>
                <div className="text-right text-[10px] text-slate-400 font-mono">
                  {new Date(a.createdAt).toLocaleTimeString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DashboardPage;
