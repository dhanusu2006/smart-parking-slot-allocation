import React, { useState, useEffect } from 'react';
import {
  Receipt,
  Search,
  Filter,
  CheckCircle,
  RotateCcw,
  AlertTriangle,
  Download,
  Printer,
  X
} from 'lucide-react';
import api from '../services/api';
import ReceiptPrintModal from '../components/ReceiptPrintModal';

export const PaymentsFinancialsPage = () => {
  const [payments, setPayments] = useState([]);
  const [summary, setSummary] = useState({ totalRevenue: 0, totalRefunds: 0, netCollected: 0 });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Filters
  const [search, setSearch] = useState('');
  const [paymentMethod, setPaymentMethod] = useState('');
  const [status, setStatus] = useState('');

  // Refund Modal State
  const [refundModalPayment, setRefundModalPayment] = useState(null);
  const [refundReason, setRefundReason] = useState('');
  const [refundLoading, setRefundLoading] = useState(false);

  // Receipt Modal State
  const [viewReceipt, setViewReceipt] = useState(null);

  const fetchPayments = async () => {
    setLoading(true);
    try {
      const q = new URLSearchParams();
      if (search) q.append('search', search);
      if (paymentMethod) q.append('paymentMethod', paymentMethod);
      if (status) q.append('status', status);

      const res = await api.get(`/payments?${q.toString()}`);
      if (res.success) {
        setPayments(res.payments || []);
        setSummary(res.summary || { totalRevenue: 0, totalRefunds: 0, netCollected: 0 });
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPayments();
  }, [paymentMethod, status]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    fetchPayments();
  };

  const handleProcessRefund = async (e) => {
    e.preventDefault();
    if (!refundModalPayment || !refundReason.trim()) return;

    setRefundLoading(true);
    setError('');
    try {
      const res = await api.post(`/payments/${refundModalPayment._id}/refund`, {
        reason: refundReason.trim()
      });
      if (res.success) {
        setSuccessMsg(`Refund of ₹${refundModalPayment.totalAmount} approved and logged in financial ledger.`);
        setRefundModalPayment(null);
        setRefundReason('');
        fetchPayments();
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setRefundLoading(false);
    }
  };

  const handleExportCSV = async () => {
    try {
      const res = await api.get('/reports/export/payments', { responseType: 'blob' });
      const blob = new Blob([res], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `payments-ledger-${new Date().toISOString().slice(0, 10)}.csv`;
      a.click();
    } catch (err) {
      setError('Failed to export CSV: ' + err.message);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            Payment Records & Reconciliation
            <span className="text-xs bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 px-2.5 py-0.5 rounded-full font-bold">
              Ledger Accurate
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Audit-grade payment tracking, authorized refunds, and multi-gateway settlements.
          </p>
        </div>

        <button
          onClick={handleExportCSV}
          className="flex items-center gap-2 px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold border border-slate-700 transition self-start sm:self-auto"
        >
          <Download className="w-4 h-4 text-cyan-400" /> Export Payments CSV
        </button>
      </div>

      {successMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-500/50 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{successMsg}</span>
        </div>
      )}

      {error && (
        <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block mb-1">
            Total Recognized Revenue
          </span>
          <span className="font-mono text-2xl font-extrabold text-emerald-400">
            ₹{summary.totalRevenue?.toLocaleString()}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">From all completed sessions</span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block mb-1">
            Total Authorized Refunds
          </span>
          <span className="font-mono text-2xl font-extrabold text-rose-400">
            ₹{summary.totalRefunds?.toLocaleString()}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">Deducted from operating ledger</span>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800">
          <span className="text-xs text-slate-400 font-bold uppercase tracking-wider block mb-1">
            Net Cashflow Collected
          </span>
          <span className="font-mono text-2xl font-extrabold text-cyan-400">
            ₹{summary.netCollected?.toLocaleString()}
          </span>
          <span className="text-[11px] text-slate-400 block mt-1">Gross income less refunds</span>
        </div>
      </div>

      {/* Filters Bar */}
      <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
        <form onSubmit={handleSearchSubmit} className="relative w-full sm:w-80">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search Txn ID, Plate, Customer..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-3 py-2 text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500"
          />
        </form>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto">
          <select
            value={paymentMethod}
            onChange={(e) => setPaymentMethod(e.target.value)}
            className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
          >
            <option value="">All Payment Methods</option>
            <option value="CASH">Cash</option>
            <option value="UPI">UPI</option>
            <option value="CARD">Card</option>
            <option value="ONLINE_GATEWAY">Online Gateway</option>
          </select>

          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
          >
            <option value="">All Statuses</option>
            <option value="PAID">PAID</option>
            <option value="REFUNDED">REFUNDED</option>
            <option value="FAILED">FAILED</option>
          </select>
        </div>
      </div>

      {/* Payments Table */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-800/60 text-slate-400 uppercase text-[10px] font-bold">
              <tr>
                <th className="py-3 px-4 rounded-l-lg">Transaction ID</th>
                <th className="py-3 px-4">Vehicle Number</th>
                <th className="py-3 px-4">Customer</th>
                <th className="py-3 px-4">Method</th>
                <th className="py-3 px-4">Base / Tax</th>
                <th className="py-3 px-4">Total Amount</th>
                <th className="py-3 px-4">Timestamp</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 rounded-r-lg text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {payments.length === 0 ? (
                <tr>
                  <td colSpan="9" className="text-center py-8 text-slate-400">
                    No matching payment records found.
                  </td>
                </tr>
              ) : (
                payments.map((p) => (
                  <tr key={p._id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3 px-4 font-mono font-bold text-cyan-300">
                      {p.transactionId}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-white">
                      {p.vehicleNumber}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-200">{p.customerName}</div>
                      <div className="text-[10px] text-slate-400">{p.customerPhone}</div>
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-300">
                      {p.paymentMethod}
                    </td>
                    <td className="py-3 px-4 font-mono text-slate-400 text-[11px]">
                      ₹{p.baseAmount?.toFixed(2)} + ₹{p.taxAmount?.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-emerald-400 text-sm">
                      ₹{p.totalAmount?.toFixed(2)}
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-400">
                      {new Date(p.createdAt).toLocaleString()}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                          p.status === 'PAID'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                            : p.status === 'REFUNDED'
                            ? 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                            : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        }`}
                      >
                        {p.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <div className="flex items-center justify-end gap-1.5">
                        <button
                          onClick={() => setViewReceipt({
                            receiptNumber: p.transactionId,
                            ticketNumber: p.session?.ticketNumber || 'PASS-TOKEN',
                            vehicleNumber: p.vehicleNumber,
                            customerName: p.customerName,
                            category: 'PARKING',
                            slotNumber: p.session?.slotNumber || 'BAY',
                            entryTime: p.session?.entryTime || p.createdAt,
                            exitTime: p.session?.exitTime || p.createdAt,
                            durationFormatted: 'Paid',
                            baseAmount: p.baseAmount,
                            taxAmount: p.taxAmount,
                            penaltyAmount: p.penaltyAmount,
                            discountAmount: p.discountAmount,
                            totalAmount: p.totalAmount,
                            paymentMethod: p.paymentMethod
                          })}
                          className="p-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 transition"
                          title="Print Receipt"
                        >
                          <Printer className="w-3.5 h-3.5" />
                        </button>

                        {p.status === 'PAID' && (
                          <button
                            onClick={() => setRefundModalPayment(p)}
                            className="p-1 rounded-lg bg-rose-950/40 hover:bg-rose-900/60 text-rose-400 transition"
                            title="Authorize Refund"
                          >
                            <RotateCcw className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Refund Authorization Modal */}
      {refundModalPayment && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-2xl p-6 shadow-2xl relative text-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="font-extrabold text-base text-white">Authorize Payment Refund</h2>
              <button
                onClick={() => setRefundModalPayment(null)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleProcessRefund} className="space-y-4 my-4 text-xs">
              <div className="p-3 bg-slate-800/80 rounded-xl space-y-1">
                <div className="flex justify-between">
                  <span className="text-slate-400">Transaction Ref:</span>
                  <span className="font-mono font-bold text-white">{refundModalPayment.transactionId}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Vehicle:</span>
                  <span className="font-mono font-bold text-white">{refundModalPayment.vehicleNumber}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Refund Amount:</span>
                  <span className="font-mono font-extrabold text-rose-400 text-sm">
                    ₹{refundModalPayment.totalAmount?.toFixed(2)}
                  </span>
                </div>
              </div>

              <div>
                <label className="text-slate-300 font-bold block mb-1">
                  Justification Reason * (Mandatory for ledger audit)
                </label>
                <textarea
                  required
                  rows="3"
                  placeholder="e.g. Overcharge correction or barrier error refund"
                  value={refundReason}
                  onChange={(e) => setRefundReason(e.target.value)}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg p-2.5 text-white text-xs focus:outline-none focus:border-rose-500"
                />
              </div>

              <div className="pt-3 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setRefundModalPayment(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={refundLoading}
                  className="px-5 py-2 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold shadow-lg glow-red disabled:opacity-50"
                >
                  {refundLoading ? 'Processing...' : 'Authorize & Process Refund'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Receipt Modal */}
      <ReceiptPrintModal
        receipt={viewReceipt}
        isOpen={!!viewReceipt}
        onClose={() => setViewReceipt(null)}
      />
    </div>
  );
};

export default PaymentsFinancialsPage;
