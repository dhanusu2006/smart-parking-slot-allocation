import ParkingSession from '../models/ParkingSession.js';
import Payment from '../models/Payment.js';
import Expense from '../models/Expense.js';
import AuditLog from '../models/AuditLog.js';
import ParkingSlot from '../models/ParkingSlot.js';

export const globalSearch = async (req, res, next) => {
  try {
    const { q } = req.query;
    if (!q || q.trim() === '') {
      return res.json({ success: true, results: { sessions: [], slots: [], payments: [] } });
    }

    const term = q.trim();
    const regex = new RegExp(term, 'i');

    const [sessions, slots, payments] = await Promise.all([
      ParkingSession.find({
        $or: [
          { ticketNumber: regex },
          { vehicleNumber: regex },
          { customerName: regex },
          { customerPhone: regex },
          { slotNumber: regex }
        ]
      })
        .limit(10)
        .sort({ entryTime: -1 }),

      ParkingSlot.find({
        $or: [
          { slotNumber: regex },
          { assignedVehiclePlate: regex }
        ]
      }).limit(10),

      Payment.find({
        $or: [
          { transactionId: regex },
          { vehicleNumber: regex },
          { customerName: regex }
        ]
      }).limit(10)
    ]);

    res.json({
      success: true,
      query: term,
      results: {
        sessions,
        slots,
        payments
      }
    });
  } catch (err) {
    next(err);
  }
};

export const exportSessionsCSV = async (req, res, next) => {
  try {
    const { startDate, endDate, category, status } = req.query;
    const filter = {};
    if (category) filter.category = category;
    if (status) filter.status = status;
    if (startDate || endDate) {
      filter.entryTime = {};
      if (startDate) filter.entryTime.$gte = new Date(startDate);
      if (endDate) filter.entryTime.$lte = new Date(endDate);
    }

    const sessions = await ParkingSession.find(filter).sort({ entryTime: -1 });

    const headers = [
      'Ticket Number',
      'Vehicle Number',
      'Category',
      'Slot',
      'Customer Name',
      'Customer Phone',
      'Billing Plan',
      'Entry Time',
      'Exit Time',
      'Duration (Mins)',
      'Base Fee (INR)',
      'Discount (INR)',
      'Tax (INR)',
      'Penalty (INR)',
      'Total Paid (INR)',
      'Status'
    ];

    const rows = sessions.map((s) => [
      s.ticketNumber,
      s.vehicleNumber,
      s.category,
      s.slotNumber,
      `"${s.customerName}"`,
      s.customerPhone,
      s.billingPlan,
      s.entryTime ? new Date(s.entryTime).toISOString() : '',
      s.exitTime ? new Date(s.exitTime).toISOString() : '',
      s.durationMinutes || 0,
      s.baseAmount || 0,
      s.discountAmount || 0,
      s.taxAmount || 0,
      s.penaltyAmount || 0,
      s.totalAmount || 0,
      s.status
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="parking-sessions-report.csv"');
    res.send(csvContent);
  } catch (err) {
    next(err);
  }
};

export const exportPaymentsCSV = async (req, res, next) => {
  try {
    const { startDate, endDate, paymentMethod, status } = req.query;
    const filter = {};
    if (paymentMethod) filter.paymentMethod = paymentMethod;
    if (status) filter.status = status;
    if (startDate || endDate) {
      filter.createdAt = {};
      if (startDate) filter.createdAt.$gte = new Date(startDate);
      if (endDate) filter.createdAt.$lte = new Date(endDate);
    }

    const payments = await Payment.find(filter).sort({ createdAt: -1 });

    const headers = [
      'Transaction ID',
      'Vehicle Number',
      'Customer Name',
      'Customer Phone',
      'Payment Method',
      'Base Amount',
      'Tax Amount',
      'Penalty Amount',
      'Total Amount',
      'Status',
      'Date',
      'Refund Reason'
    ];

    const rows = payments.map((p) => [
      p.transactionId,
      p.vehicleNumber,
      `"${p.customerName}"`,
      p.customerPhone,
      p.paymentMethod,
      p.baseAmount || 0,
      p.taxAmount || 0,
      p.penaltyAmount || 0,
      p.totalAmount || 0,
      p.status,
      new Date(p.createdAt).toISOString(),
      `"${p.refundReason || ''}"`
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', 'attachment; filename="parking-payments-report.csv"');
    res.send(csvContent);
  } catch (err) {
    next(err);
  }
};
