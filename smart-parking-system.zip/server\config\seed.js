import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';
import dotenv from 'dotenv';
import { connectDB, closeDB } from './db.js';

import User from '../models/User.js';
import ParkingZone from '../models/ParkingZone.js';
import ParkingSlot from '../models/ParkingSlot.js';
import PricingRule from '../models/PricingRule.js';
import ParkingSession from '../models/ParkingSession.js';
import Subscription from '../models/Subscription.js';
import Payment from '../models/Payment.js';
import Expense from '../models/Expense.js';
import AuditLog from '../models/AuditLog.js';
import {
  USER_ROLES,
  VEHICLE_CATEGORIES,
  SLOT_STATUSES,
  BILLING_PLANS,
  PAYMENT_METHODS,
  PAYMENT_STATUSES,
  DEFAULT_PRICING
} from './constants.js';

dotenv.config();

export const seedDatabase = async () => {
  console.log('[Seed] Starting database seeding process...');

  await connectDB();

  // Clean existing collections
  await Promise.all([
    User.deleteMany({}),
    ParkingZone.deleteMany({}),
    ParkingSlot.deleteMany({}),
    PricingRule.deleteMany({}),
    ParkingSession.deleteMany({}),
    Subscription.deleteMany({}),
    Payment.deleteMany({}),
    Expense.deleteMany({}),
    AuditLog.deleteMany({})
  ]);
  console.log('[Seed] Existing collections cleared.');

  // 1. Create Users for all 5 roles
  const salt = await bcrypt.genSalt(10);
  const commonPassword = await bcrypt.hash('Admin@12345', salt);
  const customerPassword = await bcrypt.hash('Customer@12345', salt);

  const users = await User.create([
    {
      name: 'Super Administrator',
      email: 'admin@parking.com',
      passwordHash: commonPassword,
      role: USER_ROLES.SUPER_ADMIN,
      phone: '+91 9876543210'
    },
    {
      name: 'Operations Manager',
      email: 'manager@parking.com',
      passwordHash: commonPassword,
      role: USER_ROLES.PARKING_MANAGER,
      phone: '+91 9876543211'
    },
    {
      name: 'Gate Booth Staff',
      email: 'staff@parking.com',
      passwordHash: commonPassword,
      role: USER_ROLES.PARKING_STAFF,
      phone: '+91 9876543212'
    },
    {
      name: 'Senior Accountant',
      email: 'accountant@parking.com',
      passwordHash: commonPassword,
      role: USER_ROLES.ACCOUNTANT,
      phone: '+91 9876543213'
    },
    {
      name: 'Rajesh Sharma',
      email: 'customer@parking.com',
      passwordHash: customerPassword,
      role: USER_ROLES.CUSTOMER,
      phone: '+91 9876543214'
    }
  ]);
  const [adminUser, managerUser, staffUser, accountantUser, customerUser] = users;
  console.log('[Seed] 5 Role accounts created successfully.');

  // 2. Create Pricing Rules for all 4 vehicle categories matching project requirements
  const pricingRules = await PricingRule.create([
    {
      category: VEHICLE_CATEGORIES.TWO_WHEELER,
      hourlyRate: 10,
      dailyRate: 60,
      monthlyRate: 900,
      yearlyRate: 9000,
      gracePeriodMinutes: 15,
      overtimeRatePerHour: 15,
      taxPercent: 18,
      discountPercent: 0,
      lastUpdatedBy: adminUser._id,
      lastUpdateReason: 'Initial tariff setup'
    },
    {
      category: VEHICLE_CATEGORIES.FOUR_WHEELER,
      hourlyRate: 30,
      dailyRate: 180,
      monthlyRate: 3000,
      yearlyRate: 30000,
      gracePeriodMinutes: 15,
      overtimeRatePerHour: 45,
      taxPercent: 18,
      discountPercent: 0,
      lastUpdatedBy: adminUser._id,
      lastUpdateReason: 'Initial tariff setup'
    },
    {
      category: VEHICLE_CATEGORIES.COMMERCIAL,
      hourlyRate: 50,
      dailyRate: 300,
      monthlyRate: 5000,
      yearlyRate: 50000,
      gracePeriodMinutes: 15,
      overtimeRatePerHour: 75,
      taxPercent: 18,
      discountPercent: 0,
      lastUpdatedBy: adminUser._id,
      lastUpdateReason: 'Initial tariff setup'
    },
    {
      category: VEHICLE_CATEGORIES.HEAVY,
      hourlyRate: 80,
      dailyRate: 500,
      monthlyRate: 8000,
      yearlyRate: 80000,
      gracePeriodMinutes: 15,
      overtimeRatePerHour: 120,
      taxPercent: 18,
      discountPercent: 0,
      lastUpdatedBy: adminUser._id,
      lastUpdateReason: 'Initial tariff setup'
    }
  ]);
  console.log('[Seed] Pricing tariffs seeded for 4 vehicle categories.');

  // 3. Create Parking Zones
  const zones = await ParkingZone.create([
    {
      name: 'Zone A - Two-Wheeler Bay',
      code: 'ZONE_A',
      floorLevel: 'Basement 1',
      allowedCategories: [VEHICLE_CATEGORIES.TWO_WHEELER],
      description: 'Dedicated bays for scooters and motorbikes with helmet lockers',
      totalSlots: 10
    },
    {
      name: 'Zone B - Four-Wheeler Standard & EV',
      code: 'ZONE_B',
      floorLevel: 'Ground Floor',
      allowedCategories: [VEHICLE_CATEGORIES.FOUR_WHEELER],
      description: 'Wide bays for sedans, hatchbacks, and SUVs with fast EV charging points',
      totalSlots: 20
    },
    {
      name: 'Zone C - Commercial Logistics Bay',
      code: 'ZONE_C',
      floorLevel: 'Ground Level - East Wing',
      allowedCategories: [VEHICLE_CATEGORIES.COMMERCIAL],
      description: 'High clearance bays for delivery vans, tempos, and pickup trucks',
      totalSlots: 10
    },
    {
      name: 'Zone D - Heavy Vehicle Terminus',
      code: 'ZONE_D',
      floorLevel: 'Surface Yard - North Perimeter',
      allowedCategories: [VEHICLE_CATEGORIES.HEAVY],
      description: 'Reinforced bays for tour buses, lorries, and multi-axle trucks',
      totalSlots: 5
    }
  ]);
  const [zoneA, zoneB, zoneC, zoneD] = zones;

  // 4. Create Parking Slots with coordinates, dimensions, status
  const slotsData = [];

  // Two-wheelers: B01 to B10
  for (let i = 1; i <= 10; i++) {
    const slotNumber = `B${i.toString().padStart(2, '0')}`;
    slotsData.push({
      slotNumber,
      zone: zoneA._id,
      category: VEHICLE_CATEGORIES.TWO_WHEELER,
      status: i === 1 ? SLOT_STATUSES.OCCUPIED : (i === 2 ? SLOT_STATUSES.RESERVED : (i === 10 ? SLOT_STATUSES.MAINTENANCE : SLOT_STATUSES.AVAILABLE)),
      dimensions: { length: 2.5, width: 1.2, height: 1.6 },
      assignedVehiclePlate: i === 1 ? 'MH12AB1234' : (i === 2 ? 'MH12XY9999' : null),
      isEvCharging: i <= 2,
      walkDistanceUnits: i * 3
    });
  }

  // Four-wheelers: C01 to C20
  for (let i = 1; i <= 20; i++) {
    const slotNumber = `C${i.toString().padStart(2, '0')}`;
    let status = SLOT_STATUSES.AVAILABLE;
    let plate = null;

    if (i === 1) { status = SLOT_STATUSES.OCCUPIED; plate = 'DL01CA2024'; }
    else if (i === 2) { status = SLOT_STATUSES.OCCUPIED; plate = 'KA05MG8800'; }
    else if (i === 3) { status = SLOT_STATUSES.RESERVED; plate = 'MH14EV5555'; }
    else if (i === 19) { status = SLOT_STATUSES.MAINTENANCE; }
    else if (i === 20) { status = SLOT_STATUSES.DISABLED; }

    slotsData.push({
      slotNumber,
      zone: zoneB._id,
      category: VEHICLE_CATEGORIES.FOUR_WHEELER,
      status,
      dimensions: { length: 5.0, width: 2.4, height: 2.2 },
      assignedVehiclePlate: plate,
      isEvCharging: i <= 4,
      walkDistanceUnits: i * 2
    });
  }

  // Commercial: CM01 to CM10
  for (let i = 1; i <= 10; i++) {
    const slotNumber = `CM${i.toString().padStart(2, '0')}`;
    slotsData.push({
      slotNumber,
      zone: zoneC._id,
      category: VEHICLE_CATEGORIES.COMMERCIAL,
      status: i === 1 ? SLOT_STATUSES.OCCUPIED : (i === 9 ? SLOT_STATUSES.MAINTENANCE : SLOT_STATUSES.AVAILABLE),
      dimensions: { length: 6.5, width: 2.8, height: 3.2 },
      assignedVehiclePlate: i === 1 ? 'MH04CM7001' : null,
      isEvCharging: false,
      walkDistanceUnits: i * 4
    });
  }

  // Heavy: HV01 to HV05
  for (let i = 1; i <= 5; i++) {
    const slotNumber = `HV${i.toString().padStart(2, '0')}`;
    slotsData.push({
      slotNumber,
      zone: zoneD._id,
      category: VEHICLE_CATEGORIES.HEAVY,
      status: i === 1 ? SLOT_STATUSES.OCCUPIED : SLOT_STATUSES.AVAILABLE,
      dimensions: { length: 12.0, width: 3.2, height: 4.5 },
      assignedVehiclePlate: i === 1 ? 'KA01HV9000' : null,
      isEvCharging: false,
      walkDistanceUnits: i * 5
    });
  }

  const createdSlots = await ParkingSlot.insertMany(slotsData);
  console.log(`[Seed] ${createdSlots.length} Parking bays created across 4 categories.`);

  // 5. Create Active and Completed Sessions
  const b01 = createdSlots.find((s) => s.slotNumber === 'B01');
  const c01 = createdSlots.find((s) => s.slotNumber === 'C01');
  const c02 = createdSlots.find((s) => s.slotNumber === 'C02');
  const cm01 = createdSlots.find((s) => s.slotNumber === 'CM01');
  const hv01 = createdSlots.find((s) => s.slotNumber === 'HV01');

  // Active sessions
  const activeSessions = await ParkingSession.create([
    {
      ticketNumber: 'TKT-20261020-1001',
      vehicleNumber: 'MH12AB1234',
      category: VEHICLE_CATEGORIES.TWO_WHEELER,
      customerName: 'Amit Verma',
      customerPhone: '+91 9822012345',
      slot: b01._id,
      slotNumber: 'B01',
      billingPlan: BILLING_PLANS.HOURLY,
      entryTime: new Date(Date.now() - 2.5 * 60 * 60 * 1000), // 2.5 hours ago
      priceSnapshot: DEFAULT_PRICING.TWO_WHEELER,
      status: 'ACTIVE',
      paymentStatus: 'UNPAID',
      entryOperator: staffUser._id
    },
    {
      ticketNumber: 'TKT-20261020-1002',
      vehicleNumber: 'DL01CA2024',
      category: VEHICLE_CATEGORIES.FOUR_WHEELER,
      customerName: 'Priya Sundaram',
      customerPhone: '+91 9911022334',
      slot: c01._id,
      slotNumber: 'C01',
      billingPlan: BILLING_PLANS.HOURLY,
      entryTime: new Date(Date.now() - 4.5 * 60 * 60 * 1000), // 4.5 hours ago
      priceSnapshot: DEFAULT_PRICING.FOUR_WHEELER,
      status: 'ACTIVE',
      paymentStatus: 'UNPAID',
      entryOperator: staffUser._id
    },
    {
      ticketNumber: 'TKT-20261020-1003',
      vehicleNumber: 'KA05MG8800',
      category: VEHICLE_CATEGORIES.FOUR_WHEELER,
      customerName: 'Karthik Rao',
      customerPhone: '+91 9845012345',
      slot: c02._id,
      slotNumber: 'C02',
      billingPlan: BILLING_PLANS.DAILY,
      entryTime: new Date(Date.now() - 14 * 60 * 60 * 1000), // 14 hours ago
      priceSnapshot: DEFAULT_PRICING.FOUR_WHEELER,
      status: 'ACTIVE',
      paymentStatus: 'UNPAID',
      entryOperator: staffUser._id
    },
    {
      ticketNumber: 'TKT-20261020-1004',
      vehicleNumber: 'MH04CM7001',
      category: VEHICLE_CATEGORIES.COMMERCIAL,
      customerName: 'QuickLogistics Ltd',
      customerPhone: '+91 9867055443',
      slot: cm01._id,
      slotNumber: 'CM01',
      billingPlan: BILLING_PLANS.HOURLY,
      entryTime: new Date(Date.now() - 1.2 * 60 * 60 * 1000),
      priceSnapshot: DEFAULT_PRICING.COMMERCIAL,
      status: 'ACTIVE',
      paymentStatus: 'UNPAID',
      entryOperator: staffUser._id
    },
    {
      ticketNumber: 'TKT-20261020-1005',
      vehicleNumber: 'KA01HV9000',
      category: VEHICLE_CATEGORIES.HEAVY,
      customerName: 'National Travels Bus Service',
      customerPhone: '+91 9741009988',
      slot: hv01._id,
      slotNumber: 'HV01',
      billingPlan: BILLING_PLANS.DAILY,
      entryTime: new Date(Date.now() - 8 * 60 * 60 * 1000),
      priceSnapshot: DEFAULT_PRICING.HEAVY,
      status: 'ACTIVE',
      paymentStatus: 'UNPAID',
      entryOperator: staffUser._id
    }
  ]);

  // Link active sessions to slot documents
  await ParkingSlot.findByIdAndUpdate(b01._id, { currentSession: activeSessions[0]._id });
  await ParkingSlot.findByIdAndUpdate(c01._id, { currentSession: activeSessions[1]._id });
  await ParkingSlot.findByIdAndUpdate(c02._id, { currentSession: activeSessions[2]._id });
  await ParkingSlot.findByIdAndUpdate(cm01._id, { currentSession: activeSessions[3]._id });
  await ParkingSlot.findByIdAndUpdate(hv01._id, { currentSession: activeSessions[4]._id });

  // 6. Seed Subscriptions (Monthly and Yearly Passes)
  const c03 = createdSlots.find((s) => s.slotNumber === 'C03');
  const subs = await Subscription.create([
    {
      passNumber: 'PASS-M-2026-8801',
      user: customerUser._id,
      customerName: customerUser.name,
      customerPhone: customerUser.phone,
      vehicleNumber: 'MH14EV5555',
      category: VEHICLE_CATEGORIES.FOUR_WHEELER,
      planType: 'MONTHLY',
      startDate: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
      endDate: new Date(Date.now() + 25 * 24 * 60 * 60 * 1000),
      amount: 3540, // 3000 + 18% GST
      paymentStatus: 'PAID',
      status: 'ACTIVE',
      dedicatedSlot: c03._id,
      priceSnapshot: {
        monthlyRate: 3000,
        yearlyRate: 30000,
        taxPercent: 18
      },
      usageCount: 6
    },
    {
      passNumber: 'PASS-Y-2026-9902',
      user: customerUser._id,
      customerName: 'Suresh Menon',
      customerPhone: '+91 9886011223',
      vehicleNumber: 'KA03AB4040',
      category: VEHICLE_CATEGORIES.FOUR_WHEELER,
      planType: 'YEARLY',
      startDate: new Date(Date.now() - 60 * 24 * 60 * 60 * 1000),
      endDate: new Date(Date.now() + 305 * 24 * 60 * 60 * 1000),
      amount: 35400, // 30000 + 18% GST
      paymentStatus: 'PAID',
      status: 'ACTIVE',
      priceSnapshot: {
        monthlyRate: 3000,
        yearlyRate: 30000,
        taxPercent: 18
      },
      usageCount: 42
    }
  ]);

  // Link dedicated slot
  await ParkingSlot.findByIdAndUpdate(c03._id, { dedicatedToSubscription: subs[0]._id });

  // 7. Seed Completed Payments with Revenue
  const pastPayments = await Payment.create([
    {
      transactionId: 'TXN-20261020-00101',
      customerName: 'Anil Kapoor',
      customerPhone: '+91 9811099887',
      vehicleNumber: 'DL04BB1122',
      baseAmount: 90,
      taxAmount: 16.2,
      totalAmount: 106.2,
      paymentMethod: PAYMENT_METHODS.UPI,
      status: PAYMENT_STATUSES.PAID,
      createdAt: new Date(Date.now() - 1 * 60 * 60 * 1000)
    },
    {
      transactionId: 'TXN-20261020-00102',
      customerName: 'Sneha Patel',
      customerPhone: '+91 9723044556',
      vehicleNumber: 'GJ01CD3344',
      baseAmount: 180,
      taxAmount: 32.4,
      totalAmount: 212.4,
      paymentMethod: PAYMENT_METHODS.CARD,
      status: PAYMENT_STATUSES.PAID,
      createdAt: new Date(Date.now() - 3 * 60 * 60 * 1000)
    },
    {
      transactionId: 'TXN-20261020-00103',
      customerName: 'Rahul Dravid',
      customerPhone: '+91 9844011223',
      vehicleNumber: 'KA04MN7788',
      baseAmount: 300,
      taxAmount: 54,
      totalAmount: 354,
      paymentMethod: PAYMENT_METHODS.ONLINE_GATEWAY,
      status: PAYMENT_STATUSES.PAID,
      createdAt: new Date(Date.now() - 5 * 60 * 60 * 1000)
    },
    {
      transactionId: 'TXN-20261020-00104',
      customerName: 'Vikram Seth',
      customerPhone: '+91 9820066778',
      vehicleNumber: 'MH02JK9900',
      baseAmount: 500,
      taxAmount: 90,
      totalAmount: 590,
      paymentMethod: PAYMENT_METHODS.CASH,
      status: PAYMENT_STATUSES.PAID,
      createdAt: new Date(Date.now() - 7 * 60 * 60 * 1000)
    },
    {
      transactionId: 'TXN-20261019-00099',
      customerName: 'City Transport Corp',
      customerPhone: '+91 9821033221',
      vehicleNumber: 'MH01TC5500',
      baseAmount: 5000,
      taxAmount: 900,
      totalAmount: 5900,
      paymentMethod: PAYMENT_METHODS.ONLINE_GATEWAY,
      status: PAYMENT_STATUSES.PAID,
      createdAt: new Date(Date.now() - 26 * 60 * 60 * 1000)
    }
  ]);
  console.log(`[Seed] ${pastPayments.length} Completed payments seeded.`);

  // 8. Seed Operating Expenses
  await Expense.create([
    {
      title: 'Facility Electricity & HVAC - Oct 2026',
      category: 'ELECTRICITY',
      amount: 14500,
      date: new Date(Date.now() - 4 * 24 * 60 * 60 * 1000),
      description: 'Monthly utility electricity bill for lighting, boom barriers, and server rack',
      paymentMethod: 'BANK_TRANSFER',
      createdBy: accountantUser._id,
      referenceNumber: 'BESCOM-OCT-2026-9081'
    },
    {
      title: 'Boom Barrier Hydraulic Sensor Replacement',
      category: 'EQUIPMENT',
      amount: 6800,
      date: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
      description: 'Replaced optical vehicle presence loop sensor at Entry Lane 2',
      paymentMethod: 'CARD',
      createdBy: managerUser._id,
      referenceNumber: 'INV-HARDWARE-4421'
    },
    {
      title: 'Basement Floor Pressure Wash & Degrease',
      category: 'CLEANING',
      amount: 3200,
      date: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
      description: 'Scheduled chemical cleaning and oil stain degreasing for Zone A & Zone B',
      paymentMethod: 'CASH',
      createdBy: managerUser._id,
      referenceNumber: 'CLEAN-WK-42'
    }
  ]);
  console.log('[Seed] Operating expenses seeded.');

  // 9. Seed Audit Logs
  await AuditLog.create([
    {
      user: adminUser._id,
      userName: adminUser.name,
      userRole: adminUser.role,
      action: 'SYSTEM_INITIALIZATION',
      resourceType: 'SYSTEM',
      resourceId: 'FACILITY_01',
      newValues: { totalBays: 45, zonesCount: 4 },
      reason: 'Facility setup and initial hardware provisioning'
    },
    {
      user: adminUser._id,
      userName: adminUser.name,
      userRole: adminUser.role,
      action: 'PRICING_UPDATED',
      resourceType: 'PRICING_RULE',
      resourceId: 'FOUR_WHEELER',
      oldValues: { hourlyRate: 25 },
      newValues: { hourlyRate: 30 },
      reason: 'Annual peak festival tariff adjustment'
    }
  ]);
  console.log('[Seed] Audit log seeded.');

  console.log('[Seed] Database initialization completed successfully!');
};

// If run directly via `node config/seed.js`
if (process.argv[1].endsWith('seed.js')) {
  seedDatabase()
    .then(async () => {
      console.log('[Seed] All done. Closing database connection.');
      await closeDB();
      process.exit(0);
    })
    .catch(async (err) => {
      console.error('[Seed] Error seeding database:', err);
      await closeDB();
      process.exit(1);
    });
}
