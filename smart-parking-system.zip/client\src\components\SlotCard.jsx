import React from 'react';
import { motion } from 'framer-motion';
import { Bike, Car, Truck, Bus, Zap, Wrench, Ban, Clock, User } from 'lucide-react';

const getCategoryIcon = (category) => {
  switch (category) {
    case 'TWO_WHEELER':
      return <Bike className="w-5 h-5" />;
    case 'FOUR_WHEELER':
      return <Car className="w-5 h-5" />;
    case 'COMMERCIAL':
      return <Truck className="w-5 h-5" />;
    case 'HEAVY':
      return <Bus className="w-5 h-5" />;
    default:
      return <Car className="w-5 h-5" />;
  }
};

const getStatusStyle = (status) => {
  switch (status) {
    case 'AVAILABLE':
      return {
        border: 'border-emerald-500/70',
        bg: 'bg-emerald-950/20 hover:bg-emerald-900/30',
        badge: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
        glow: 'hover:shadow-[0_0_15px_rgba(16,185,129,0.3)]',
        indicator: 'bg-emerald-500'
      };
    case 'OCCUPIED':
      return {
        border: 'border-rose-500/70',
        bg: 'bg-rose-950/25 hover:bg-rose-900/35',
        badge: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
        glow: 'hover:shadow-[0_0_15px_rgba(239,68,68,0.3)]',
        indicator: 'bg-rose-500 animate-pulse'
      };
    case 'RESERVED':
      return {
        border: 'border-amber-500/70',
        bg: 'bg-amber-950/20 hover:bg-amber-900/30',
        badge: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
        glow: 'hover:shadow-[0_0_15px_rgba(245,158,11,0.3)]',
        indicator: 'bg-amber-500'
      };
    case 'MAINTENANCE':
      return {
        border: 'border-blue-500/70',
        bg: 'bg-blue-950/20 hover:bg-blue-900/30',
        badge: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
        glow: 'hover:shadow-[0_0_15px_rgba(59,130,246,0.3)]',
        indicator: 'bg-blue-500'
      };
    case 'DISABLED':
    default:
      return {
        border: 'border-slate-600/50',
        bg: 'bg-slate-900/40 opacity-70 hover:opacity-100',
        badge: 'bg-slate-700/40 text-slate-400 border-slate-600/30',
        glow: '',
        indicator: 'bg-slate-500'
      };
  }
};

export const SlotCard = ({ slot, onSelect }) => {
  const style = getStatusStyle(slot.status);

  // Compute duration if occupied and session is present
  const entryTime = slot.currentSession?.entryTime;
  const durationMins = entryTime
    ? Math.max(1, Math.round((Date.now() - new Date(entryTime).getTime()) / (1000 * 60)))
    : null;

  return (
    <motion.div
      whileHover={{ scale: 1.02, y: -2 }}
      whileTap={{ scale: 0.98 }}
      onClick={() => onSelect(slot)}
      className={`relative p-3.5 rounded-xl border ${style.border} ${style.bg} ${style.glow} transition-all duration-200 cursor-pointer flex flex-col justify-between min-h-[145px] backdrop-blur-sm`}
    >
      {/* Top Row: Slot ID & Status indicator */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className={`p-1.5 rounded-lg bg-slate-900/80 border border-slate-700/50 text-slate-200`}>
            {getCategoryIcon(slot.category)}
          </div>
          <div>
            <div className="font-mono font-bold text-base tracking-wide text-white flex items-center gap-1.5">
              {slot.slotNumber}
              {slot.isEvCharging && (
                <span title="EV Charging Station" className="p-0.5 rounded bg-cyan-950 border border-cyan-500/40 text-cyan-400">
                  <Zap className="w-3 h-3" />
                </span>
              )}
            </div>
            <div className="text-[10px] text-slate-400">
              {slot.dimensions?.length}m × {slot.dimensions?.width}m
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          <span className={`w-2 h-2 rounded-full ${style.indicator}`}></span>
          <span className={`text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-full border ${style.badge}`}>
            {slot.status}
          </span>
        </div>
      </div>

      {/* Middle Content: Vehicle plate or status context */}
      <div className="my-2">
        {slot.status === 'OCCUPIED' && (
          <div className="space-y-1">
            <div className="font-mono text-xs font-bold text-rose-300 bg-rose-950/60 border border-rose-500/40 px-2 py-1 rounded text-center tracking-wider shadow-inner">
              {slot.assignedVehiclePlate || slot.currentSession?.vehicleNumber || 'IN USE'}
            </div>
            {slot.currentSession?.customerName && (
              <div className="text-[10px] text-slate-300 truncate flex items-center gap-1">
                <User className="w-2.5 h-2.5 text-slate-400" />
                {slot.currentSession.customerName}
              </div>
            )}
          </div>
        )}

        {slot.status === 'AVAILABLE' && (
          <div className="text-center py-2 text-emerald-400/90 text-xs font-medium">
            Ready to park
          </div>
        )}

        {slot.status === 'RESERVED' && (
          <div className="text-center py-1">
            <div className="text-[11px] font-mono text-amber-300 bg-amber-950/40 border border-amber-500/30 px-2 py-0.5 rounded">
              {slot.assignedVehiclePlate || 'RESERVED PASS'}
            </div>
          </div>
        )}

        {slot.status === 'MAINTENANCE' && (
          <div className="flex items-center justify-center gap-1 py-2 text-blue-300 text-xs font-medium">
            <Wrench className="w-3.5 h-3.5" /> Maintenance
          </div>
        )}

        {slot.status === 'DISABLED' && (
          <div className="flex items-center justify-center gap-1 py-2 text-slate-400 text-xs font-medium">
            <Ban className="w-3.5 h-3.5" /> Out of service
          </div>
        )}
      </div>

      {/* Bottom Row: Duration / Walking distance */}
      <div className="flex items-center justify-between text-[11px] text-slate-400 border-t border-slate-800/80 pt-1.5 mt-auto">
        <span className="text-[10px] text-slate-400">
          Proximity: {slot.walkDistanceUnits}m
        </span>

        {durationMins ? (
          <span className="flex items-center gap-1 text-rose-300 font-mono text-[10px]">
            <Clock className="w-3 h-3 text-rose-400" /> {Math.floor(durationMins / 60)}h {durationMins % 60}m
          </span>
        ) : (
          <span className="text-[10px] text-slate-400">
            {slot.category.replace('_', ' ')}
          </span>
        )}
      </div>
    </motion.div>
  );
};

export default SlotCard;
