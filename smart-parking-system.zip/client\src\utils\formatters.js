export const formatCurrency = (amount = 0) => {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 2
  }).format(amount);
};

export const formatDurationFromMinutes = (minutes = 0) => {
  const days = Math.floor(minutes / (24 * 60));
  const remainingMins = minutes % (24 * 60);
  const hours = Math.floor(remainingMins / 60);
  const mins = remainingMins % 60;

  const parts = [];
  if (days > 0) parts.push(`${days}d`);
  if (hours > 0) parts.push(`${hours}h`);
  parts.push(`${mins}m`);
  return parts.join(' ');
};

export const getCategoryBadgeColor = (category) => {
  switch (category) {
    case 'TWO_WHEELER':
      return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    case 'FOUR_WHEELER':
      return 'bg-cyan-500/20 text-cyan-400 border-cyan-500/30';
    case 'COMMERCIAL':
      return 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30';
    case 'HEAVY':
      return 'bg-purple-500/20 text-purple-400 border-purple-500/30';
    default:
      return 'bg-slate-700 text-slate-300';
  }
};
