import React, { useState } from 'react';
import { X, Wrench, Ban, CheckCircle, ArrowRightLeft, LogOut, Clock, ShieldAlert } from 'lucide-react';
import api from '../services/api';

export const SlotDetailsModal = ({ slot, isOpen, onClose, onRefresh, navigateToExit }) => {
  if (!isOpen || !slot) return null;

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [reason, setReason] = useState('');

  const handleStatusChange = async (newStatus) => {
    setLoading(true);
    setError('');
    try {
      await api.patch(`/parking/slots/${slot._id}/status`, {
        status: newStatus,
        reason: reason || `Updated to ${newStatus} via layout modal`
      });
      onRefresh();
      onClose();
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl p-6 shadow-2xl relative text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="font-mono text-2xl font-extrabold text-cyan-400">{slot.slotNumber}</span>
              <span className={`text-xs px-2.5 py-0.5 rounded-full font-bold uppercase tracking-wider ${
                slot.status === 'AVAILABLE' ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30' :
                slot.status === 'OCCUPIED' ? 'bg-rose-500/20 text-rose-300 border border-rose-500/30' :
                slot.status === 'RESERVED' ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30' :
                slot.status === 'MAINTENANCE' ? 'bg-blue-500/20 text-blue-300 border border-blue-500/30' :
                'bg-slate-700 text-slate-300'
              }`}>
                {slot.status}
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">{slot.zone?.name || 'Main Parking Facility'}</p>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {error && (
          <div className="mt-4 p-3 rounded-lg bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}

        {/* Specifications */}
        <div className="grid grid-cols-2 gap-3 my-4 text-xs">
          <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/50">
            <span className="text-slate-400 block mb-1">Vehicle Category</span>
            <span className="font-semibold text-white">{slot.category.replace('_', ' ')}</span>
          </div>
          <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/50">
            <span className="text-slate-400 block mb-1">Bay Dimensions</span>
            <span className="font-semibold text-white">{slot.dimensions?.length}m (L) × {slot.dimensions?.width}m (W) × {slot.dimensions?.height || 2.2}m (H)</span>
          </div>
          <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/50">
            <span className="text-slate-400 block mb-1">EV Charging Fast Point</span>
            <span className="font-semibold text-white">{slot.isEvCharging ? 'Equipped (Active)' : 'Standard Bay'}</span>
          </div>
          <div className="bg-slate-800/60 p-3 rounded-xl border border-slate-700/50">
            <span className="text-slate-400 block mb-1">Walking Proximity Score</span>
            <span className="font-semibold text-white">{slot.walkDistanceUnits} meters from entry gate</span>
          </div>
        </div>

        {/* Occupant Session Details if OCCUPIED */}
        {slot.status === 'OCCUPIED' && slot.currentSession && (
          <div className="p-4 rounded-xl bg-slate-800/80 border border-rose-500/30 mb-4 space-y-2 text-xs">
            <div className="text-rose-400 font-semibold flex items-center gap-1.5">
              <Clock className="w-4 h-4" /> Active Parking Session
            </div>
            <div className="grid grid-cols-2 gap-2 text-slate-300">
              <div>
                <span className="text-slate-400 block">Vehicle Registration:</span>
                <span className="font-mono font-bold text-white text-sm">{slot.currentSession.vehicleNumber}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Ticket Number:</span>
                <span className="font-mono font-bold text-cyan-300">{slot.currentSession.ticketNumber}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Customer Name:</span>
                <span className="font-medium text-white">{slot.currentSession.customerName}</span>
              </div>
              <div>
                <span className="text-slate-400 block">Entry Timestamp:</span>
                <span className="font-medium text-white">{new Date(slot.currentSession.entryTime).toLocaleTimeString()}</span>
              </div>
            </div>

            <div className="pt-2 flex justify-end">
              <button
                onClick={() => {
                  onClose();
                  navigateToExit(slot.currentSession.ticketNumber);
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-rose-600 hover:bg-rose-500 text-white font-medium transition"
              >
                <LogOut className="w-4 h-4" /> Proceed to Exit Checkout
              </button>
            </div>
          </div>
        )}

        {/* Action Controls for Staff/Admin */}
        <div className="border-t border-slate-800 pt-4 space-y-3">
          <div>
            <label className="text-xs text-slate-400 block mb-1">Reason / Notes for audit log:</label>
            <input
              type="text"
              placeholder="e.g. Surface repainting or sensor check"
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none focus:border-cyan-500"
            />
          </div>

          <div className="flex flex-wrap items-center justify-end gap-2 pt-1">
            {slot.status !== 'AVAILABLE' && slot.status !== 'OCCUPIED' && (
              <button
                disabled={loading}
                onClick={() => handleStatusChange('AVAILABLE')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-600/80 hover:bg-emerald-600 text-white text-xs font-semibold transition"
              >
                <CheckCircle className="w-4 h-4" /> Mark as Available
              </button>
            )}

            {slot.status !== 'MAINTENANCE' && slot.status !== 'OCCUPIED' && (
              <button
                disabled={loading}
                onClick={() => handleStatusChange('MAINTENANCE')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-blue-600/80 hover:bg-blue-600 text-white text-xs font-semibold transition"
              >
                <Wrench className="w-4 h-4" /> Set Maintenance
              </button>
            )}

            {slot.status !== 'DISABLED' && slot.status !== 'OCCUPIED' && (
              <button
                disabled={loading}
                onClick={() => handleStatusChange('DISABLED')}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-slate-200 text-xs font-semibold transition"
              >
                <Ban className="w-4 h-4" /> Disable Bay
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default SlotDetailsModal;
