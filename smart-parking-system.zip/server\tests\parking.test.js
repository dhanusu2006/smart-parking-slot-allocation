import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { calculateParkingFee } from '../services/pricingEngine.js';
import { checkSlotCompatibility } from '../services/slotAllocationService.js';
import { BILLING_PLANS, VEHICLE_CATEGORIES, SLOT_STATUSES, DEFAULT_PRICING } from '../config/constants.js';

describe('Smart Parking System - Pricing & Billing Engine Tests', () => {
  const sampleCarSnapshot = {
    hourlyRate: 30,
    dailyRate: 180,
    monthlyRate: 3000,
    yearlyRate: 30000,
    gracePeriodMinutes: 15,
    overtimeRatePerHour: 45,
    taxPercent: 18,
    discountPercent: 0
  };

  it('1. should apply free grace period when session duration is <= 15 minutes', () => {
    const entry = new Date('2026-10-20T10:00:00Z');
    const exit = new Date('2026-10-20T10:12:00Z'); // 12 minutes

    const result = calculateParkingFee({
      entryTime: entry,
      exitTime: exit,
      billingPlan: BILLING_PLANS.HOURLY,
      priceSnapshot: sampleCarSnapshot
    });

    expect(result.durationMinutes).toBe(12);
    expect(result.baseAmount).toBe(0);
    expect(result.taxAmount).toBe(0);
    expect(result.totalAmount).toBe(0);
  });

  it('2. should round up to the next full hour when exceeding grace period', () => {
    const entry = new Date('2026-10-20T10:00:00Z');
    const exit = new Date('2026-10-20T11:20:00Z'); // 1 hour 20 minutes -> 2 hours billed

    const result = calculateParkingFee({
      entryTime: entry,
      exitTime: exit,
      billingPlan: BILLING_PLANS.HOURLY,
      priceSnapshot: sampleCarSnapshot
    });

    expect(result.durationMinutes).toBe(80);
    expect(result.baseAmount).toBe(60); // 2 hours * 30 = 60
    expect(result.taxAmount).toBe(10.8); // 18% of 60 = 10.8
    expect(result.totalAmount).toBe(70.8);
  });

  it('3. should accurately calculate multi-day 24-hour blocks and daily rates', () => {
    const entry = new Date('2026-10-20T10:00:00Z');
    const exit = new Date('2026-10-22T08:00:00Z'); // 46 hours -> 2 days billed

    const result = calculateParkingFee({
      entryTime: entry,
      exitTime: exit,
      billingPlan: BILLING_PLANS.DAILY,
      priceSnapshot: sampleCarSnapshot
    });

    expect(result.baseAmount).toBe(360); // 2 days * 180 = 360
    expect(result.taxAmount).toBe(64.8); // 18% of 360 = 64.8
    expect(result.totalAmount).toBe(424.8);
  });

  it('4. should apply overtime penalty when exceeding paid daily boundary past grace period', () => {
    const entry = new Date('2026-10-20T10:00:00Z');
    const exit = new Date('2026-10-21T12:30:00Z'); // 26.5 hours -> 1 day + 3 overtime hours

    const result = calculateParkingFee({
      entryTime: entry,
      exitTime: exit,
      billingPlan: BILLING_PLANS.DAILY,
      priceSnapshot: sampleCarSnapshot
    });

    expect(result.baseAmount).toBe(360); // Math.ceil(26.5/24) = 2 days
    expect(result.totalAmount).toBeGreaterThan(0);
  });

  it('5. should correctly apply promotional discounts before computing GST', () => {
    const entry = new Date('2026-10-20T10:00:00Z');
    const exit = new Date('2026-10-20T12:00:00Z'); // 2 hours = ₹60

    const result = calculateParkingFee({
      entryTime: entry,
      exitTime: exit,
      billingPlan: BILLING_PLANS.HOURLY,
      priceSnapshot: sampleCarSnapshot,
      customDiscountPercent: 10 // 10% discount
    });

    expect(result.baseAmount).toBe(60);
    expect(result.discountAmount).toBe(6); // 10% of 60
    expect(result.taxAmount).toBe(9.72); // 18% of (60 - 6) = 9.72
    expect(result.totalAmount).toBe(63.72);
  });

  it('6. should guarantee snapshot immutability when global tariffs change', () => {
    const oldSnapshot = { ...sampleCarSnapshot, hourlyRate: 30 };
    const newGlobalRule = { ...sampleCarSnapshot, hourlyRate: 50 }; // Admin increased price to ₹50

    const entry = new Date('2026-10-20T10:00:00Z');
    const exit = new Date('2026-10-20T12:00:00Z');

    // Active session using snapshot must use ₹30, NOT ₹50!
    const sessionResult = calculateParkingFee({
      entryTime: entry,
      exitTime: exit,
      billingPlan: BILLING_PLANS.HOURLY,
      priceSnapshot: oldSnapshot
    });

    expect(sessionResult.baseAmount).toBe(60); // 2 * 30, not 2 * 50
    expect(sessionResult.baseAmount).not.toBe(100);
  });
});

describe('Smart Parking System - Slot Compatibility & Allocation Tests', () => {
  const bikeSlot = {
    slotNumber: 'B01',
    category: VEHICLE_CATEGORIES.TWO_WHEELER,
    status: SLOT_STATUSES.AVAILABLE,
    dimensions: { length: 2.5, width: 1.2 }
  };

  const carSlot = {
    slotNumber: 'C01',
    category: VEHICLE_CATEGORIES.FOUR_WHEELER,
    status: SLOT_STATUSES.AVAILABLE,
    dimensions: { length: 5.0, width: 2.4 }
  };

  it('7. should allow compatible vehicle category in appropriate slot', () => {
    const check = checkSlotCompatibility(carSlot, VEHICLE_CATEGORIES.FOUR_WHEELER);
    expect(check.compatible).toBe(true);
  });

  it('8. should reject incompatible vehicle category (Heavy Vehicle in Bike slot)', () => {
    const check = checkSlotCompatibility(bikeSlot, VEHICLE_CATEGORIES.HEAVY);
    expect(check.compatible).toBe(false);
    expect(check.reason).toContain('is designated for TWO_WHEELER');
  });

  it('9. should reject vehicles that exceed slot physical dimensions', () => {
    const oversizedCar = { length: 5.8, width: 2.6 };
    const check = checkSlotCompatibility(carSlot, VEHICLE_CATEGORIES.FOUR_WHEELER, oversizedCar);
    expect(check.compatible).toBe(false);
    expect(check.reason).toContain('exceeds slot capacity');
  });

  it('10. should reject allocation to an OCCUPIED or MAINTENANCE slot', () => {
    const occupiedSlot = { ...carSlot, status: SLOT_STATUSES.OCCUPIED };
    const check = checkSlotCompatibility(occupiedSlot, VEHICLE_CATEGORIES.FOUR_WHEELER);
    expect(check.compatible).toBe(false);
    expect(check.reason).toContain('currently OCCUPIED');
  });
});

describe('Smart Parking System - Accounting & Profit Calculations', () => {
  it('11. should accurately compute Gross Parking Revenue and Net Operating Profit', () => {
    const recognizedIncome = 150000;
    const operatingExpenses = [
      { category: 'SALARY', amount: 35000 },
      { category: 'ELECTRICITY', amount: 14000 },
      { category: 'MAINTENANCE', amount: 8000 },
      { category: 'REFUND', amount: 1200 }
    ];

    const totalExpenses = operatingExpenses.reduce((sum, e) => sum + e.amount, 0);
    const netProfit = recognizedIncome - totalExpenses;

    expect(totalExpenses).toBe(58200);
    expect(netProfit).toBe(91800);
  });
});
