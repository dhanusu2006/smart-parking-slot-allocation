import React from 'react';
import { motion } from 'framer-motion';
import { Bike, Car, Truck, Bus, Zap } from 'lucide-react';

export const RoadLaneAnimation = () => {
  return (
    <div className="w-full bg-slate-950/80 border border-slate-800 rounded-2xl p-4 overflow-hidden relative shadow-2xl backdrop-blur-md">
      {/* Header Info */}
      <div className="flex items-center justify-between mb-3 px-2">
        <div className="flex items-center gap-2">
          <span className="relative flex h-2.5 w-2.5">
            <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
            <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
          </span>
          <span className="text-xs font-semibold tracking-wider uppercase text-emerald-400">
            Smart Entry Expressway • Active Traffic Monitoring
          </span>
        </div>
        <div className="flex items-center gap-3 text-xs text-slate-400">
          <span className="flex items-center gap-1"><Zap className="w-3.5 h-3.5 text-cyan-400" /> RFID / ANPR Sensor Active</span>
          <span className="bg-slate-800 px-2 py-0.5 rounded text-[11px] text-slate-300">Gate Speed: 20 km/h</span>
        </div>
      </div>

      {/* Road Lane Surface */}
      <div className="relative h-16 bg-slate-900 rounded-xl border-y-2 border-slate-700/60 overflow-hidden flex items-center shadow-inner">
        {/* Road divider dashed line */}
        <div className="absolute inset-x-0 h-0.5 border-t-2 border-dashed border-amber-400/40 z-0"></div>

        {/* Animated Moving Vehicles */}
        {/* 1. Bike */}
        <motion.div
          className="absolute z-10 flex items-center gap-1.5 bg-emerald-950/90 border border-emerald-500/50 px-2.5 py-1 rounded-full text-emerald-300 shadow-lg glow-green"
          initial={{ x: -100 }}
          animate={{ x: '110vw' }}
          transition={{ duration: 16, repeat: Infinity, ease: 'linear' }}
        >
          <Bike className="w-4 h-4 text-emerald-400" />
          <span className="text-[10px] font-mono font-bold">B-04</span>
        </motion.div>

        {/* 2. Sedan / Car */}
        <motion.div
          className="absolute z-10 flex items-center gap-1.5 bg-cyan-950/90 border border-cyan-500/50 px-3 py-1 rounded-full text-cyan-300 shadow-lg glow-cyan"
          initial={{ x: -280 }}
          animate={{ x: '110vw' }}
          transition={{ duration: 19, repeat: Infinity, ease: 'linear', delay: 2 }}
        >
          <Car className="w-4 h-4 text-cyan-400" />
          <span className="text-[10px] font-mono font-bold">C-12 (EV)</span>
        </motion.div>

        {/* 3. Commercial Van */}
        <motion.div
          className="absolute z-10 flex items-center gap-1.5 bg-indigo-950/90 border border-indigo-500/50 px-3 py-1 rounded-full text-indigo-300 shadow-lg"
          initial={{ x: -500 }}
          animate={{ x: '110vw' }}
          transition={{ duration: 23, repeat: Infinity, ease: 'linear', delay: 5 }}
        >
          <Truck className="w-4 h-4 text-indigo-400" />
          <span className="text-[10px] font-mono font-bold">CM-03</span>
        </motion.div>

        {/* 4. Heavy Bus / Lorry */}
        <motion.div
          className="absolute z-10 flex items-center gap-1.5 bg-purple-950/90 border border-purple-500/50 px-3.5 py-1 rounded-full text-purple-300 shadow-lg"
          initial={{ x: -800 }}
          animate={{ x: '110vw' }}
          transition={{ duration: 27, repeat: Infinity, ease: 'linear', delay: 8 }}
        >
          <Bus className="w-4 h-4 text-purple-400" />
          <span className="text-[10px] font-mono font-bold">HV-01</span>
        </motion.div>
      </div>

      {/* Legend */}
      <div className="flex flex-wrap items-center justify-between gap-2 mt-3 pt-2 border-t border-slate-800/80 text-[11px] text-slate-400 px-2">
        <div className="flex items-center gap-4">
          <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> Available</span>
          <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span> Occupied</span>
          <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span> Reserved</span>
          <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-blue-500"></span> Maintenance</span>
          <span className="flex items-center gap-1.5"><span className="w-2.5 h-2.5 rounded-full bg-slate-500"></span> Disabled</span>
        </div>
        <div className="text-slate-500 text-[10px]">
          Live Sensor Synchronization • 4 Vehicle Categories
        </div>
      </div>
    </div>
  );
};

export default RoadLaneAnimation;
