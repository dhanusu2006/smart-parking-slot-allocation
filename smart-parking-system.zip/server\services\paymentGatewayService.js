import crypto from 'crypto';

/**
 * Simulates sandbox online payment gateway order creation & verification
 */
export const createGatewayOrder = ({ amount, currency = 'INR', receipt }) => {
  const orderId = `order_${Date.now()}_${Math.floor(Math.random() * 10000)}`;
  return {
    orderId,
    amount,
    currency,
    receipt,
    key: 'rzp_test_SANDBOX_KEY_MOCK',
    status: 'created'
  };
};

/**
 * Validates gateway payment signature (simulation for sandbox)
 */
export const verifyGatewaySignature = ({ orderId, paymentId, signature }) => {
  // In sandbox simulation, verify structure
  if (!orderId || !paymentId) {
    return { valid: false, reason: 'Missing orderId or paymentId' };
  }

  // Create expected signature using sha256
  const secret = process.env.GATEWAY_SECRET || 'sandbox_secret_smart_parking_2026';
  const expectedSignature = crypto
    .createHmac('sha256', secret)
    .update(`${orderId}|${paymentId}`)
    .digest('hex');

  // If signature matches expected, or is valid test token
  const isValid = signature === expectedSignature || signature?.startsWith('sim_sig_') || signature === 'sandbox_valid';

  return {
    valid: isValid,
    reason: isValid ? 'Signature verified' : 'Invalid gateway signature callback'
  };
};

/**
 * Generates sandbox mock gateway payment ID
 */
export const generateGatewayPaymentId = () => {
  return `pay_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
};
