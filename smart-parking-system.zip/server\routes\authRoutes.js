import express from 'express';
import { register, login, getMe, getAllUsers, updateUserRole } from '../controllers/authController.js';
import { protect, restrictTo } from '../middleware/auth.js';
import { USER_ROLES } from '../config/constants.js';

const router = express.Router();

router.post('/register', register);
router.post('/login', login);
router.get('/me', protect, getMe);

// Admin-only user management
router.get('/users', protect, restrictTo(USER_ROLES.SUPER_ADMIN), getAllUsers);
router.patch('/users/:id/role', protect, restrictTo(USER_ROLES.SUPER_ADMIN), updateUserRole);

export default router;
