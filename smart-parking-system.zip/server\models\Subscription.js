import mongoose from 'mongoose';
import { VEHICLE_CATEGORIES } from '../config/constants.js';

const subscriptionSchema = new mongoose.Schema(
  {
    passNumber: {
      type: String,
      required: true,
      unique: true,
      index: true,
      uppercase: true
    },
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null
    },
    customerName: {
      type: String,
      required: true,
      trim: true
    },
    customerPhone: {
      type: String,
      required: true,
      trim: true
    },
    vehicleNumber: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
      index: true
    },
    category: {
      type: String,
      enum: Object.values(VEHICLE_CATEGORIES),
      required: true
    },
    planType: {
      type: String,
      enum: ['MONTHLY', 'YEARLY'],
      required: true
    },
    startDate: {
      type: Date,
      required: true
    },
    endDate: {
      type: Date,
      required: true,
      index: true
    },
    amount: {
      type: Number,
      required: true
    },
    paymentStatus: {
      type: String,
      enum: ['PAID', 'PENDING', 'REFUNDED'],
      default: 'PAID'
    },
    payment: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Payment',
      default: null
    },
    status: {
      type: String,
      enum: ['ACTIVE', 'EXPIRED', 'CANCELLED'],
      default: 'ACTIVE',
      index: true
    },
    dedicatedSlot: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'ParkingSlot',
      default: null
    },
    priceSnapshot: {
      monthlyRate: { type: Number },
      yearlyRate: { type: Number },
      taxPercent: { type: Number },
      discountPercent: { type: Number },
      capturedAt: { type: Date, default: Date.now }
    },
    usageCount: {
      type: Number,
      default: 0
    },
    lastUsedAt: {
      type: Date
    }
  },
  {
    timestamps: true
  }
);

subscriptionSchema.methods.isCurrentlyActive = function () {
  const now = new Date();
  return this.status === 'ACTIVE' && this.endDate >= now && this.startDate <= now;
};

export default mongoose.model('Subscription', subscriptionSchema);
