import mongoose from 'mongoose';
import { VEHICLE_CATEGORIES } from '../config/constants.js';

const waitingListSchema = new mongoose.Schema(
  {
    vehicleNumber: {
      type: String,
      required: true,
      trim: true,
      uppercase: true,
      index: true
    },
    category: {
      type: String,
      enum: Object.values(VEHICLE_CATEGORIES),
      required: true,
      index: true
    },
    customerName: {
      type: String,
      required: true,
      trim: true
    },
    customerPhone: {
      type: String,
      required: true,
      trim: true
    },
    requestedTime: {
      type: Date,
      default: Date.now,
      index: true
    },
    status: {
      type: String,
      enum: ['WAITING', 'NOTIFIED', 'ALLOCATED', 'EXPIRED', 'CANCELLED'],
      default: 'WAITING',
      index: true
    },
    notifiedAt: {
      type: Date,
      default: null
    },
    allocatedSlot: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'ParkingSlot',
      default: null
    },
    notes: {
      type: String,
      default: ''
    }
  },
  {
    timestamps: true
  }
);

export default mongoose.model('WaitingList', waitingListSchema);
