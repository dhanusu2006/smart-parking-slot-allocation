/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  darkMode: 'class',
  theme: {
    extend: {
      colors: {
        parking: {
          navy: '#0b1120',
          dark: '#0f172a',
          surface: '#1e293b',
          card: '#162032',
          border: '#334155',
          accent: '#06b6d4',
          neon: '#10b981',
          danger: '#ef4444',
          warning: '#f59e0b',
          info: '#3b82f6'
        }
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'drive-lane': 'driveLane 12s linear infinite',
        'fade-in': 'fadeIn 0.3s ease-in-out',
      },
      keyframes: {
        driveLane: {
          '0%': { transform: 'translateX(-100%)' },
          '100%': { transform: 'translateX(1000%)' }
        },
        fadeIn: {
          '0%': { opacity: '0', transform: 'translateY(6px)' },
          '100%': { opacity: '1', transform: 'translateY(0)' }
        }
      }
    },
  },
  plugins: [],
}
