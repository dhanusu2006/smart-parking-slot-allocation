import React, { useState, useEffect } from 'react';
import { useLocation } from 'react-router-dom';
import {
  LogOut,
  Search,
  Receipt,
  CreditCard,
  QrCode,
  Banknote,
  Globe,
  Clock,
  ShieldCheck,
  CheckCircle,
  AlertTriangle
} from 'lucide-react';
import api from '../services/api';
import ReceiptPrintModal from '../components/ReceiptPrintModal';

export const VehicleExitCheckoutPage = () => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);
  const initialTicket = searchParams.get('ticket') || '';

  const [lookupQuery, setLookupQuery] = useState(initialTicket);
  const [activeSession, setActiveSession] = useState(null);
  const [feeBreakdown, setFeeBreakdown] = useState(null);
  const [loading, setLoading] = useState(false);
  const [checkoutLoading, setCheckoutLoading] = useState(false);
  const [error, setError] = useState('');

  // Payment selections
  const [paymentMethod, setPaymentMethod] = useState('CASH');
  const [customDiscount, setCustomDiscount] = useState(0);
  const [receiptData, setReceiptData] = useState(null);

  const fetchSession = async (queryToSearch) => {
    const q = queryToSearch || lookupQuery;
    if (!q || !q.trim()) return;

    setLoading(true);
    setError('');
    setActiveSession(null);
    setFeeBreakdown(null);

    try {
      const res = await api.get(`/parking/session/${encodeURIComponent(q.trim())}`);
      if (res.success) {
        setActiveSession(res.session);
        setFeeBreakdown(res.feeBreakdown);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialTicket) {
      fetchSession(initialTicket);
    }
  }, [initialTicket]);

  const handleCheckout = async () => {
    if (!activeSession) return;
    setCheckoutLoading(true);
    setError('');

    try {
      const payload = {
        ticketNumber: activeSession.ticketNumber,
        paymentMethod,
        customDiscountPercent: Number(customDiscount) || 0,
        gatewayDetails: {
          gatewayName: paymentMethod === 'ONLINE_GATEWAY' ? 'Sandbox Gateway' : paymentMethod,
          gatewayPaymentId: `SIM_PAY_${Date.now()}`,
          gatewayOrderId: `SIM_ORD_${Date.now()}`,
          gatewaySignature: 'sandbox_valid',
          isSandbox: true
        }
      };

      const res = await api.post('/parking/exit', payload);
      if (res.success) {
        setReceiptData(res.receipt);
        setActiveSession(null);
        setFeeBreakdown(null);
        setLookupQuery('');
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setCheckoutLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
          Vehicle Exit & Fee Checkout
          <span className="text-xs bg-rose-500/20 text-rose-400 border border-rose-500/30 px-2.5 py-0.5 rounded-full font-bold">
            Exit Barrier Lane
          </span>
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Scan QR ticket or enter plate number to calculate parking charges and release parking bay.
        </p>
      </div>

      {/* Lookup Card */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl backdrop-blur-md">
        <form
          onSubmit={(e) => {
            e.preventDefault();
            fetchSession();
          }}
          className="flex flex-col sm:flex-row gap-3"
        >
          <div className="relative flex-1">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search Ticket (e.g. TKT-...), License Plate (e.g. DL01...), or Slot (C01)"
              value={lookupQuery}
              onChange={(e) => setLookupQuery(e.target.value)}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl pl-9 pr-4 py-2.5 text-xs text-white placeholder-slate-400 uppercase font-mono tracking-wider focus:outline-none focus:border-cyan-500"
            />
          </div>
          <button
            type="submit"
            disabled={loading}
            className="flex items-center justify-center gap-2 px-6 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-lg glow-cyan transition disabled:opacity-50"
          >
            <Search className="w-4 h-4" />
            {loading ? 'Retrieving...' : 'Find Session'}
          </button>
        </form>

        {error && (
          <div className="mt-4 p-3 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 flex-shrink-0" />
            <span>{error}</span>
          </div>
        )}
      </div>

      {/* Active Session Breakdown and Checkout Card */}
      {activeSession && feeBreakdown && (
        <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl space-y-6 animate-fade-in">
          {/* Top Session Summary */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-slate-800 gap-3">
            <div>
              <span className="text-[10px] uppercase font-bold tracking-wider text-cyan-400">
                Active Parking Session
              </span>
              <div className="flex items-center gap-3 mt-1">
                <span className="font-mono text-2xl font-extrabold text-white">
                  {activeSession.vehicleNumber}
                </span>
                <span className="font-mono text-sm px-2.5 py-0.5 rounded-lg bg-emerald-950 text-emerald-300 border border-emerald-500/40 font-bold">
                  Bay {activeSession.slotNumber}
                </span>
              </div>
              <p className="text-xs text-slate-400 mt-1">
                {activeSession.customerName} ({activeSession.customerPhone}) • {activeSession.category?.replace('_', ' ')}
              </p>
            </div>

            <div className="text-right">
              <span className="text-xs text-slate-400">Ticket Ref:</span>
              <div className="font-mono font-bold text-cyan-300 text-sm">{activeSession.ticketNumber}</div>
              <div className="text-[10px] text-slate-400">Entry: {new Date(activeSession.entryTime).toLocaleTimeString()}</div>
            </div>
          </div>

          {/* Pricing Math Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/50">
              <span className="text-slate-400 text-xs block mb-1">Elapsed Duration</span>
              <span className="font-mono font-bold text-white text-base flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-cyan-400" />
                {feeBreakdown.durationFormatted}
              </span>
            </div>

            <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/50">
              <span className="text-slate-400 text-xs block mb-1">Base Tariff</span>
              <span className="font-mono font-bold text-white text-base">
                ₹{feeBreakdown.baseAmount?.toFixed(2)}
              </span>
            </div>

            <div className="bg-slate-800/60 p-3.5 rounded-xl border border-slate-700/50">
              <span className="text-slate-400 text-xs block mb-1">GST (18%)</span>
              <span className="font-mono font-bold text-white text-base">
                ₹{feeBreakdown.taxAmount?.toFixed(2)}
              </span>
            </div>

            <div className="bg-emerald-950/30 p-3.5 rounded-xl border border-emerald-500/40">
              <span className="text-emerald-400 text-xs font-semibold block mb-1">Net Payable</span>
              <span className="font-mono font-extrabold text-emerald-400 text-xl">
                ₹{feeBreakdown.totalAmount?.toFixed(2)}
              </span>
            </div>
          </div>

          {/* Payment Method Selector */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-2">
              Select Payment Method
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { id: 'CASH', label: 'Cash at Booth', desc: 'Counter settlement', icon: Banknote },
                { id: 'UPI', label: 'UPI QR Scan', desc: 'GPay / PhonePe / Paytm', icon: QrCode },
                { id: 'CARD', label: 'Debit / Credit Card', desc: 'POS Terminal swipe', icon: CreditCard },
                { id: 'ONLINE_GATEWAY', label: 'Online Sandbox', desc: 'Verified Gateway', icon: Globe }
              ].map((m) => {
                const Icon = m.icon;
                const isSelected = paymentMethod === m.id;
                return (
                  <button
                    key={m.id}
                    type="button"
                    onClick={() => setPaymentMethod(m.id)}
                    className={`p-3.5 rounded-xl border text-left transition flex flex-col justify-between ${
                      isSelected
                        ? 'bg-emerald-950/40 border-emerald-500 text-white shadow-lg glow-green ring-1 ring-emerald-500'
                        : 'bg-slate-800/60 border-slate-700 text-slate-400 hover:text-slate-200 hover:bg-slate-800'
                    }`}
                  >
                    <Icon className={`w-5 h-5 mb-2 ${isSelected ? 'text-emerald-400' : 'text-slate-400'}`} />
                    <div>
                      <span className="font-bold text-xs block">{m.label}</span>
                      <span className="text-[10px] text-slate-400">{m.desc}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Action Row */}
          <div className="pt-4 border-t border-slate-800 flex items-center justify-between">
            <div className="text-[11px] text-slate-400 flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              <span>Bay {activeSession.slotNumber} will be released atomically upon payment confirmation.</span>
            </div>

            <button
              onClick={handleCheckout}
              disabled={checkoutLoading}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs shadow-lg glow-green transition disabled:opacity-50"
            >
              <LogOut className="w-4 h-4" />
              {checkoutLoading ? 'Processing Checkout...' : `Confirm & Pay ₹${feeBreakdown.totalAmount?.toFixed(2)}`}
            </button>
          </div>
        </div>
      )}

      {/* Tax Invoice Receipt Modal */}
      <ReceiptPrintModal
        receipt={receiptData}
        isOpen={!!receiptData}
        onClose={() => setReceiptData(null)}
      />
    </div>
  );
};

export default VehicleExitCheckoutPage;
