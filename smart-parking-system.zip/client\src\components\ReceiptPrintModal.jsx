import React from 'react';
import { X, Printer, CheckCircle, Receipt } from 'lucide-react';

export const ReceiptPrintModal = ({ receipt, isOpen, onClose }) => {
  if (!isOpen || !receipt) return null;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
      <div className="bg-slate-900 border border-slate-700 w-full max-w-md rounded-2xl p-6 shadow-2xl relative text-slate-100">
        {/* Header */}
        <div className="flex items-center justify-between pb-3 border-b border-slate-800 no-print">
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5">
            <CheckCircle className="w-4 h-4" /> Payment Completed & Slot Released
          </span>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-400 hover:text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Printable Tax Invoice */}
        <div className="bg-white text-slate-900 rounded-xl p-5 my-4 border border-slate-300 shadow-lg font-sans">
          <div className="text-center pb-3 border-b border-slate-200">
            <div className="flex items-center justify-center gap-1.5 text-cyan-800 mb-0.5">
              <Receipt className="w-5 h-5" />
              <h2 className="font-extrabold text-base uppercase tracking-wider">SMART PARKING FACILITY</h2>
            </div>
            <p className="text-[11px] text-slate-500">Official Tax Invoice & Clearance Slip</p>
            <p className="text-[10px] text-slate-400 font-mono">GSTIN: 29AAAAA0000A1Z5</p>
          </div>

          <div className="my-3 space-y-1 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-500">Receipt No:</span>
              <span className="font-mono font-bold text-slate-900">{receipt.receiptNumber}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Ticket Ref:</span>
              <span className="font-mono text-slate-700">{receipt.ticketNumber}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Vehicle No:</span>
              <span className="font-mono font-bold text-slate-900">{receipt.vehicleNumber}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Category / Bay:</span>
              <span className="font-semibold text-slate-800">{receipt.category?.replace('_', ' ')} • Bay {receipt.slotNumber}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Customer:</span>
              <span className="text-slate-800">{receipt.customerName}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Entry Time:</span>
              <span className="text-slate-700">{new Date(receipt.entryTime).toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Exit Time:</span>
              <span className="text-slate-700">{new Date(receipt.exitTime).toLocaleString()}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-slate-500">Billed Duration:</span>
              <span className="font-bold text-cyan-800">{receipt.durationFormatted}</span>
            </div>
          </div>

          {/* Pricing Math Breakdown */}
          <div className="border-t border-b border-dashed border-slate-300 py-2.5 my-3 space-y-1 text-xs">
            <div className="flex justify-between">
              <span className="text-slate-600">Base Parking Tariff:</span>
              <span>₹{receipt.baseAmount?.toFixed(2)}</span>
            </div>
            {receipt.penaltyAmount > 0 && (
              <div className="flex justify-between text-rose-600">
                <span>Overtime Surcharge:</span>
                <span>+₹{receipt.penaltyAmount?.toFixed(2)}</span>
              </div>
            )}
            {receipt.discountAmount > 0 && (
              <div className="flex justify-between text-emerald-600">
                <span>Applied Discount:</span>
                <span>-₹{receipt.discountAmount?.toFixed(2)}</span>
              </div>
            )}
            <div className="flex justify-between text-slate-600">
              <span>GST (18%):</span>
              <span>₹{receipt.taxAmount?.toFixed(2)}</span>
            </div>
            <div className="flex justify-between font-extrabold text-sm pt-1.5 border-t border-slate-200 text-slate-900">
              <span>Total Paid:</span>
              <span className="text-emerald-700 font-mono">₹{receipt.totalAmount?.toFixed(2)}</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-[11px] text-slate-500">
            <span>Payment Method: <strong className="text-slate-800">{receipt.paymentMethod}</strong></span>
            <span className="text-emerald-700 font-bold bg-emerald-50 px-2 py-0.5 rounded border border-emerald-200">
              PAID & CLEARED
            </span>
          </div>

          <div className="text-center text-[10px] text-slate-400 mt-3 pt-2 border-t border-slate-100">
            Thank you for parking with us. Drive safely!
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center justify-end gap-3 pt-2 no-print">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold transition"
          >
            Close
          </button>
          <button
            onClick={handlePrint}
            className="flex items-center gap-2 px-5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg glow-green transition"
          >
            <Printer className="w-4 h-4" /> Print Tax Receipt
          </button>
        </div>
      </div>
    </div>
  );
};

export default ReceiptPrintModal;
