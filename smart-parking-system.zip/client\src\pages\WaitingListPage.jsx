import React, { useState, useEffect } from 'react';
import {
  Clock,
  UserPlus,
  AlertCircle,
  CheckCircle,
  Bell,
  XCircle,
  ArrowRight,
  Car
} from 'lucide-react';
import api from '../services/api';

export const WaitingListPage = () => {
  const [waitingList, setWaitingList] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const [formData, setFormData] = useState({
    customerName: '',
    customerPhone: '',
    vehicleNumber: '',
    category: 'FOUR_WHEELER',
    notes: ''
  });

  const fetchWaitingList = async () => {
    setLoading(true);
    try {
      const res = await api.get('/waiting-list');
      if (res.success) {
        setWaitingList(res.list || []);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchWaitingList();
  }, []);

  const handleJoin = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    try {
      const res = await api.post('/waiting-list/join', formData);
      if (res.success) {
        setSuccessMsg(res.message);
        setFormData({
          customerName: '',
          customerPhone: '',
          vehicleNumber: '',
          category: 'FOUR_WHEELER',
          notes: ''
        });
        fetchWaitingList();
      }
    } catch (err) {
      setError(err.message);
    }
  };

  const handleCancel = async (id) => {
    try {
      const res = await api.patch(`/waiting-list/${id}/cancel`);
      if (res.success) {
        setSuccessMsg('Removed from queue.');
        fetchWaitingList();
      }
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
          Waiting List & Capacity Overflow Queue
          <span className="text-xs bg-amber-500/20 text-amber-400 border border-amber-500/30 px-2.5 py-0.5 rounded-full font-bold">
            {waitingList.length} Vehicles Waiting
          </span>
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Automated queue triggered when category parking bays are 100% full. Auto-notifies next vehicle upon bay release.
        </p>
      </div>

      {successMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-500/50 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{successMsg}</span>
        </div>
      )}

      {error && (
        <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* Join Waiting List Form */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
        <h2 className="text-sm font-bold text-white uppercase tracking-wider mb-3 flex items-center gap-2">
          <UserPlus className="w-4 h-4 text-cyan-400" />
          Add Vehicle to Waiting List
        </h2>

        <form onSubmit={handleJoin} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3 text-xs">
          <div>
            <label className="text-slate-400 block mb-1">Plate Number *</label>
            <input
              type="text"
              required
              placeholder="e.g. KA01AB1234"
              value={formData.vehicleNumber}
              onChange={(e) => setFormData({ ...formData, vehicleNumber: e.target.value.toUpperCase() })}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono uppercase"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Vehicle Category</label>
            <select
              value={formData.category}
              onChange={(e) => setFormData({ ...formData, category: e.target.value })}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
            >
              <option value="TWO_WHEELER">Two-Wheeler</option>
              <option value="FOUR_WHEELER">Four-Wheeler</option>
              <option value="COMMERCIAL">Commercial</option>
              <option value="HEAVY">Heavy Vehicle</option>
            </select>
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Customer Name *</label>
            <input
              type="text"
              required
              placeholder="Driver name"
              value={formData.customerName}
              onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
            />
          </div>

          <div>
            <label className="text-slate-400 block mb-1">Mobile Phone *</label>
            <input
              type="tel"
              required
              placeholder="+91..."
              value={formData.customerPhone}
              onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })}
              className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3 py-2 text-white"
            />
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-lg glow-cyan transition"
            >
              Enqueue Vehicle
            </button>
          </div>
        </form>
      </div>

      {/* Queue Table */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl overflow-hidden">
        <h2 className="text-sm font-bold text-white uppercase tracking-wider mb-3 flex items-center gap-2">
          <Clock className="w-4 h-4 text-amber-400" />
          Live Waiting Queue
        </h2>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-800/60 text-slate-400 uppercase text-[10px] font-bold">
              <tr>
                <th className="py-3 px-4 rounded-l-lg">Position</th>
                <th className="py-3 px-4">Vehicle Number</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Customer Details</th>
                <th className="py-3 px-4">Requested Time</th>
                <th className="py-3 px-4">Queue Status</th>
                <th className="py-3 px-4 rounded-r-lg text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {waitingList.length === 0 ? (
                <tr>
                  <td colSpan="7" className="text-center py-8 text-slate-400">
                    The waiting queue is currently empty. Parking capacity is available.
                  </td>
                </tr>
              ) : (
                waitingList.map((w, index) => (
                  <tr key={w._id} className="hover:bg-slate-800/40 transition">
                    <td className="py-3 px-4 font-mono font-bold text-amber-400">
                      #{index + 1}
                    </td>
                    <td className="py-3 px-4 font-mono font-bold text-white">
                      {w.vehicleNumber}
                    </td>
                    <td className="py-3 px-4 font-semibold text-slate-300">
                      {w.category.replace('_', ' ')}
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-200">{w.customerName}</div>
                      <div className="text-[10px] text-slate-400">{w.customerPhone}</div>
                    </td>
                    <td className="py-3 px-4 font-mono text-[11px] text-slate-400">
                      {new Date(w.requestedTime).toLocaleTimeString()}
                    </td>
                    <td className="py-3 px-4">
                      <span
                        className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase ${
                          w.status === 'NOTIFIED'
                            ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 animate-pulse'
                            : 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        }`}
                      >
                        {w.status}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        onClick={() => handleCancel(w._id)}
                        className="p-1 rounded-lg text-rose-400 hover:bg-rose-950/60"
                        title="Remove from queue"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default WaitingListPage;
