import mongoose from 'mongoose';

const auditLogSchema = new mongoose.Schema(
  {
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null
    },
    userName: {
      type: String,
      default: 'System'
    },
    userRole: {
      type: String,
      default: 'SYSTEM'
    },
    action: {
      type: String,
      required: true,
      index: true
    },
    resourceType: {
      type: String,
      required: true,
      index: true // e.g. 'PRICING_RULE', 'PARKING_SLOT', 'PARKING_SESSION', 'PAYMENT', 'USER'
    },
    resourceId: {
      type: String,
      required: true
    },
    oldValues: {
      type: Object,
      default: null
    },
    newValues: {
      type: Object,
      default: null
    },
    reason: {
      type: String,
      default: 'Not specified'
    },
    ipAddress: {
      type: String,
      default: ''
    }
  },
  {
    timestamps: { createdAt: true, updatedAt: false }
  }
);

auditLogSchema.index({ createdAt: -1 });

export default mongoose.model('AuditLog', auditLogSchema);
