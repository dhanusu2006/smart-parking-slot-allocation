export const VEHICLE_CATEGORIES = {
  TWO_WHEELER: 'TWO_WHEELER',
  FOUR_WHEELER: 'FOUR_WHEELER',
  COMMERCIAL: 'COMMERCIAL',
  HEAVY: 'HEAVY'
};

export const VEHICLE_CATEGORY_LABELS = {
  TWO_WHEELER: 'Two-Wheeler (Bike / Scooter)',
  FOUR_WHEELER: 'Four-Wheeler (Car / Sedan / SUV)',
  COMMERCIAL: 'Commercial (Van / Mini Truck)',
  HEAVY: 'Heavy Vehicle (Bus / Lorry / Truck)'
};

export const SLOT_STATUSES = {
  AVAILABLE: 'AVAILABLE',   // Green
  OCCUPIED: 'OCCUPIED',     // Red
  RESERVED: 'RESERVED',     // Yellow
  MAINTENANCE: 'MAINTENANCE', // Blue
  DISABLED: 'DISABLED'      // Grey
};

export const BILLING_PLANS = {
  HOURLY: 'HOURLY',
  DAILY: 'DAILY',
  MONTHLY: 'MONTHLY',
  YEARLY: 'YEARLY'
};

export const USER_ROLES = {
  SUPER_ADMIN: 'SUPER_ADMIN',
  PARKING_MANAGER: 'PARKING_MANAGER',
  PARKING_STAFF: 'PARKING_STAFF',
  ACCOUNTANT: 'ACCOUNTANT',
  CUSTOMER: 'CUSTOMER'
};

export const PAYMENT_METHODS = {
  CASH: 'CASH',
  UPI: 'UPI',
  CARD: 'CARD',
  ONLINE_GATEWAY: 'ONLINE_GATEWAY'
};

export const PAYMENT_STATUSES = {
  PAID: 'PAID',
  PENDING: 'PENDING',
  FAILED: 'FAILED',
  REFUNDED: 'REFUNDED',
  PARTIALLY_PAID: 'PARTIALLY_PAID'
};

export const EXPENSE_CATEGORIES = {
  SALARY: 'Staff Salary',
  ELECTRICITY: 'Electricity & Utilities',
  MAINTENANCE: 'Slot & Facility Maintenance',
  CLEANING: 'Cleaning & Janitorial',
  EQUIPMENT: 'Hardware & Boom Barrier Equipment',
  REFUND: 'Customer Refunds',
  OTHER: 'Other Operating Expenses'
};

export const INCOME_CATEGORIES = {
  HOURLY: 'Hourly Parking',
  DAILY: 'Daily Parking',
  MONTHLY: 'Monthly Passes',
  YEARLY: 'Yearly Passes',
  OVERTIME: 'Overtime Charges',
  OTHER: 'Other Authorized Income'
};

export const DEFAULT_PRICING = {
  TWO_WHEELER: {
    hourlyRate: 10,
    dailyRate: 60,
    monthlyRate: 900,
    yearlyRate: 9000,
    gracePeriodMinutes: 15,
    overtimeRatePerHour: 15,
    taxPercent: 18,
    discountPercent: 0,
    dimensions: { length: 2.5, width: 1.2, height: 1.5 }
  },
  FOUR_WHEELER: {
    hourlyRate: 30,
    dailyRate: 180,
    monthlyRate: 3000,
    yearlyRate: 30000,
    gracePeriodMinutes: 15,
    overtimeRatePerHour: 45,
    taxPercent: 18,
    discountPercent: 0,
    dimensions: { length: 5.0, width: 2.4, height: 2.0 }
  },
  COMMERCIAL: {
    hourlyRate: 50,
    dailyRate: 300,
    monthlyRate: 5000,
    yearlyRate: 50000,
    gracePeriodMinutes: 15,
    overtimeRatePerHour: 75,
    taxPercent: 18,
    discountPercent: 0,
    dimensions: { length: 6.5, width: 2.8, height: 3.0 }
  },
  HEAVY: {
    hourlyRate: 80,
    dailyRate: 500,
    monthlyRate: 8000,
    yearlyRate: 80000,
    gracePeriodMinutes: 15,
    overtimeRatePerHour: 120,
    taxPercent: 18,
    discountPercent: 0,
    dimensions: { length: 12.0, width: 3.2, height: 4.2 }
  }
};
