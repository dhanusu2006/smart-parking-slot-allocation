import express from 'express';
import { joinWaitingList, getWaitingList, cancelWaitingEntry } from '../controllers/waitingListController.js';
import { protect } from '../middleware/auth.js';

const router = express.Router();

router.post('/join', joinWaitingList);
router.get('/', protect, getWaitingList);
router.patch('/:id/cancel', protect, cancelWaitingEntry);

export default router;
