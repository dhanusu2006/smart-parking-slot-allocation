import React, { useState, useEffect } from 'react';
import {
  FileSpreadsheet,
  Download,
  Search,
  Shield,
  Filter,
  CheckCircle,
  Clock,
  Car,
  Receipt
} from 'lucide-react';
import api from '../services/api';

export const AuditLogsReportsPage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState(null);
  const [auditLogs, setAuditLogs] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleGlobalSearch = async (e) => {
    e.preventDefault();
    if (!searchQuery.trim()) return;

    setLoading(true);
    setError('');
    try {
      const res = await api.get(`/reports/search?q=${encodeURIComponent(searchQuery.trim())}`);
      if (res.success) {
        setSearchResults(res.results);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleExportSessions = () => {
    window.open(`${api.defaults.baseURL}/reports/export/sessions`, '_blank');
  };

  const handleExportPayments = () => {
    window.open(`${api.defaults.baseURL}/reports/export/payments`, '_blank');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
          Global Search, Compliance & Audit Reports
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Execute global queries across sessions, transactions, and slots. Export regulatory CSV reports.
        </p>
      </div>

      {/* CSV Export Quick Buttons */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl flex items-center justify-between">
          <div>
            <h3 className="font-bold text-sm text-white">Parking Sessions Report</h3>
            <p className="text-xs text-slate-400 mt-0.5">Comprehensive entry, exit, duration, and ticket records</p>
          </div>
          <button
            onClick={handleExportSessions}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-lg glow-cyan transition"
          >
            <Download className="w-4 h-4" /> Export CSV
          </button>
        </div>

        <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl flex items-center justify-between">
          <div>
            <h3 className="font-bold text-sm text-white">Payments & Ledger Report</h3>
            <p className="text-xs text-slate-400 mt-0.5">Complete financial collections, taxes, and authorized refunds</p>
          </div>
          <button
            onClick={handleExportPayments}
            className="flex items-center gap-2 px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold shadow-lg glow-green transition"
          >
            <Download className="w-4 h-4" /> Export CSV
          </button>
        </div>
      </div>

      {/* Global Search Bar */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
        <h2 className="text-sm font-bold text-white uppercase tracking-wider mb-3 flex items-center gap-2">
          <Search className="w-4 h-4 text-cyan-400" />
          Universal Database Search
        </h2>

        <form onSubmit={handleGlobalSearch} className="flex gap-3">
          <input
            type="text"
            placeholder="Search license plate, customer name, ticket ID, transaction ref, or slot ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="flex-1 bg-slate-800 border border-slate-700 rounded-xl px-4 py-2.5 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500"
          />
          <button
            type="submit"
            disabled={loading}
            className="px-6 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-lg glow-cyan transition disabled:opacity-50"
          >
            {loading ? 'Searching...' : 'Search'}
          </button>
        </form>
      </div>

      {/* Search Results Display */}
      {searchResults && (
        <div className="space-y-4 animate-fade-in">
          <h3 className="text-xs font-bold uppercase tracking-wider text-cyan-400">
            Search Matches for "{searchQuery}"
          </h3>

          {/* Sessions Matches */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Car className="w-4 h-4 text-cyan-400" /> Parking Sessions ({searchResults.sessions?.length || 0})
            </h4>
            {searchResults.sessions?.length === 0 ? (
              <p className="text-xs text-slate-500">No matching sessions found.</p>
            ) : (
              <div className="divide-y divide-slate-800">
                {searchResults.sessions.map((s) => (
                  <div key={s._id} className="py-2.5 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-mono font-bold text-white">{s.vehicleNumber}</span>
                      <span className="text-slate-400 ml-2">Ticket: {s.ticketNumber} • Bay: {s.slotNumber}</span>
                    </div>
                    <div className="text-right">
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        s.status === 'ACTIVE' ? 'bg-rose-500/20 text-rose-400' : 'bg-emerald-500/20 text-emerald-400'
                      }`}>
                        {s.status}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Payments Matches */}
          <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
            <h4 className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
              <Receipt className="w-4 h-4 text-emerald-400" /> Payment Records ({searchResults.payments?.length || 0})
            </h4>
            {searchResults.payments?.length === 0 ? (
              <p className="text-xs text-slate-500">No matching payment transactions found.</p>
            ) : (
              <div className="divide-y divide-slate-800">
                {searchResults.payments.map((p) => (
                  <div key={p._id} className="py-2.5 flex items-center justify-between text-xs">
                    <div>
                      <span className="font-mono font-bold text-cyan-300">{p.transactionId}</span>
                      <span className="text-slate-400 ml-2">{p.vehicleNumber} • {p.customerName}</span>
                    </div>
                    <div className="text-right">
                      <span className="font-mono font-bold text-emerald-400">₹{p.totalAmount?.toFixed(2)}</span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default AuditLogsReportsPage;
