import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  LogIn,
  Car,
  Bike,
  Truck,
  Bus,
  Zap,
  CheckCircle,
  AlertTriangle,
  QrCode,
  ShieldCheck,
  Clock
} from 'lucide-react';
import api from '../services/api';
import TicketPrintModal from '../components/TicketPrintModal';

export const VehicleEntryPage = () => {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    vehicleNumber: '',
    category: 'FOUR_WHEELER',
    customerName: '',
    customerPhone: '',
    billingPlan: 'HOURLY',
    preferEv: false,
    slotId: '',
    length: '',
    width: ''
  });

  const [availableSlots, setAvailableSlots] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [successTicket, setSuccessTicket] = useState(null);
  const [isFullError, setIsFullError] = useState(false);

  // Fetch available slots for manual picker
  useEffect(() => {
    const fetchSlots = async () => {
      try {
        const res = await api.get(`/parking/layout?category=${formData.category}&status=AVAILABLE`);
        if (res.success) {
          setAvailableSlots(res.slots || []);
        }
      } catch (err) {
        console.error('Failed to load slots:', err.message);
      }
    };
    fetchSlots();
  }, [formData.category]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError('');
    setIsFullError(false);

    try {
      const payload = {
        vehicleNumber: formData.vehicleNumber.trim().toUpperCase(),
        category: formData.category,
        customerName: formData.customerName.trim(),
        customerPhone: formData.customerPhone.trim(),
        billingPlan: formData.billingPlan,
        preferEv: formData.preferEv,
        slotId: formData.slotId || undefined,
        dimensions: (formData.length && formData.width) ? {
          length: Number(formData.length),
          width: Number(formData.width)
        } : undefined
      };

      const res = await api.post('/parking/entry', payload);
      if (res.success) {
        setSuccessTicket(res.ticket);
        // Reset form
        setFormData({
          vehicleNumber: '',
          category: 'FOUR_WHEELER',
          customerName: '',
          customerPhone: '',
          billingPlan: 'HOURLY',
          preferEv: false,
          slotId: '',
          length: '',
          width: ''
        });
      }
    } catch (err) {
      setError(err.message);
      if (err.message.includes('No compatible') || err.message.includes('full')) {
        setIsFullError(true);
      }
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
          Vehicle Entry Registration
          <span className="text-xs bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 px-2.5 py-0.5 rounded-full font-bold">
            Boom Barrier Active
          </span>
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Record entry, check active passes, allocate nearest optimal bay, and issue QR ticket.
        </p>
      </div>

      {/* Main Form Card */}
      <div className="p-6 rounded-2xl bg-slate-900 border border-slate-800 shadow-2xl backdrop-blur-md">
        {error && (
          <div className="mb-6 p-4 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs flex items-start justify-between gap-3">
            <div className="flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 flex-shrink-0 text-rose-400" />
              <div>
                <span className="font-bold block">Entry Allocation Failed</span>
                <span>{error}</span>
              </div>
            </div>
            {isFullError && (
              <button
                onClick={() => navigate('/waiting-list')}
                className="px-3 py-1 rounded-lg bg-rose-700 hover:bg-rose-600 text-white font-bold transition whitespace-nowrap"
              >
                Join Waiting List
              </button>
            )}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Step 1: Vehicle Category Selector */}
          <div>
            <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-2">
              1. Select Vehicle Category
            </label>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              {[
                { id: 'TWO_WHEELER', label: 'Two-Wheeler', desc: 'Bike / Scooter', icon: Bike, color: 'emerald' },
                { id: 'FOUR_WHEELER', label: 'Four-Wheeler', desc: 'Car / SUV', icon: Car, color: 'cyan' },
                { id: 'COMMERCIAL', label: 'Commercial', desc: 'Van / Mini Truck', icon: Truck, color: 'indigo' },
                { id: 'HEAVY', label: 'Heavy Vehicle', desc: 'Bus / Lorry / Truck', icon: Bus, color: 'purple' }
              ].map((cat) => {
                const Icon = cat.icon;
                const isSelected = formData.category === cat.id;
                return (
                  <button
                    key={cat.id}
                    type="button"
                    onClick={() => setFormData({ ...formData, category: cat.id, slotId: '' })}
                    className={`p-3.5 rounded-xl border text-left transition flex flex-col justify-between ${
                      isSelected
                        ? 'bg-cyan-950/60 border-cyan-500 text-white shadow-lg glow-cyan ring-1 ring-cyan-500'
                        : 'bg-slate-800/60 border-slate-700/60 text-slate-400 hover:bg-slate-800 hover:text-slate-200'
                    }`}
                  >
                    <Icon className={`w-5 h-5 mb-2 ${isSelected ? 'text-cyan-400' : 'text-slate-400'}`} />
                    <div>
                      <span className="font-bold text-xs block">{cat.label}</span>
                      <span className="text-[10px] text-slate-400">{cat.desc}</span>
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Step 2: Vehicle & Customer Information */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-1">
                License Plate Number *
              </label>
              <input
                type="text"
                required
                placeholder="e.g. MH12AB1234"
                value={formData.vehicleNumber}
                onChange={(e) => setFormData({ ...formData, vehicleNumber: e.target.value.toUpperCase() })}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 font-mono text-sm text-white uppercase tracking-wider focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-1">
                Customer Name *
              </label>
              <input
                type="text"
                required
                placeholder="Driver / Owner name"
                value={formData.customerName}
                onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
              />
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-1">
                Mobile Number *
              </label>
              <input
                type="tel"
                required
                placeholder="e.g. +91 9876543210"
                value={formData.customerPhone}
                onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500"
              />
            </div>
          </div>

          {/* Step 3: Billing Plan & Slot Preferences */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-1">
                Billing Plan
              </label>
              <select
                value={formData.billingPlan}
                onChange={(e) => setFormData({ ...formData, billingPlan: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="HOURLY">Hourly Tariff Plan</option>
                <option value="DAILY">Daily (24-Hour Block) Plan</option>
              </select>
            </div>

            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-slate-300 block mb-1">
                Slot Assignment Mode
              </label>
              <select
                value={formData.slotId}
                onChange={(e) => setFormData({ ...formData, slotId: e.target.value })}
                className="w-full bg-slate-800 border border-slate-700 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-cyan-500"
              >
                <option value="">⚡ Automatic (Nearest Optimal Bay)</option>
                {availableSlots.map((s) => (
                  <option key={s._id} value={s._id}>
                    Manual Bay: {s.slotNumber} ({s.dimensions?.length}m × {s.dimensions?.width}m)
                  </option>
                ))}
              </select>
            </div>

            <div className="flex items-center gap-3 pt-6">
              <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                <input
                  type="checkbox"
                  checked={formData.preferEv}
                  onChange={(e) => setFormData({ ...formData, preferEv: e.target.checked })}
                  className="rounded bg-slate-800 border-slate-700 text-cyan-500 focus:ring-cyan-500 w-4 h-4"
                />
                <span className="flex items-center gap-1 font-semibold text-cyan-300">
                  <Zap className="w-3.5 h-3.5 text-cyan-400" /> Prefer EV Charger Bay
                </span>
              </label>
            </div>
          </div>

          {/* Submit Action */}
          <div className="border-t border-slate-800 pt-5 flex items-center justify-between">
            <div className="text-[11px] text-slate-400">
              * Active subscriptions will be automatically detected and mapped.
            </div>

            <button
              type="submit"
              disabled={loading}
              className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-lg glow-cyan transition disabled:opacity-50"
            >
              <LogIn className="w-4 h-4" />
              {loading ? 'Allocating Bay...' : 'Confirm Entry & Issue Ticket'}
            </button>
          </div>
        </form>
      </div>

      {/* Generated Ticket Modal */}
      <TicketPrintModal
        ticket={successTicket}
        isOpen={!!successTicket}
        onClose={() => setSuccessTicket(null)}
      />
    </div>
  );
};

export default VehicleEntryPage;
