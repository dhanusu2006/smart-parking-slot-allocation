import WaitingList from '../models/WaitingList.js';
import { VEHICLE_CATEGORIES } from '../config/constants.js';

export const joinWaitingList = async (req, res, next) => {
  try {
    const { vehicleNumber, category, customerName, customerPhone, notes } = req.body;

    const cleanPlate = vehicleNumber.trim().toUpperCase();

    const existing = await WaitingList.findOne({
      vehicleNumber: cleanPlate,
      category,
      status: 'WAITING'
    });

    if (existing) {
      return res.status(400).json({
        success: false,
        message: `Vehicle ${cleanPlate} is already on the waiting list for ${category}`
      });
    }

    const waitEntry = await WaitingList.create({
      vehicleNumber: cleanPlate,
      category,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      notes: notes || '',
      requestedTime: new Date()
    });

    const position = await WaitingList.countDocuments({
      category,
      status: 'WAITING',
      requestedTime: { $lte: waitEntry.requestedTime }
    });

    res.status(201).json({
      success: true,
      message: `Added to waiting list. You are position #${position} in line for a ${category} slot.`,
      waitEntry,
      queuePosition: position
    });
  } catch (err) {
    next(err);
  }
};

export const getWaitingList = async (req, res, next) => {
  try {
    const { category, status = 'WAITING' } = req.query;
    const filter = { status };
    if (category) filter.category = category;

    const list = await WaitingList.find(filter)
      .populate('allocatedSlot', 'slotNumber zone dimensions')
      .sort({ requestedTime: 1 });

    res.json({ success: true, count: list.length, list });
  } catch (err) {
    next(err);
  }
};

export const cancelWaitingEntry = async (req, res, next) => {
  try {
    const entry = await WaitingList.findByIdAndUpdate(
      req.params.id,
      { $set: { status: 'CANCELLED' } },
      { new: true }
    );
    if (!entry) {
      return res.status(404).json({ success: false, message: 'Waiting list entry not found' });
    }
    res.json({ success: true, message: 'Removed from waiting list', entry });
  } catch (err) {
    next(err);
  }
};
