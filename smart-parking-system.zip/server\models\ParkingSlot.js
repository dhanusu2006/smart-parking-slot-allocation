import mongoose from 'mongoose';
import { VEHICLE_CATEGORIES, SLOT_STATUSES } from '../config/constants.js';

const parkingSlotSchema = new mongoose.Schema(
  {
    slotNumber: {
      type: String,
      required: true,
      unique: true,
      uppercase: true,
      trim: true,
      index: true
    },
    zone: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'ParkingZone',
      required: true
    },
    category: {
      type: String,
      enum: Object.values(VEHICLE_CATEGORIES),
      required: true,
      index: true
    },
    status: {
      type: String,
      enum: Object.values(SLOT_STATUSES),
      default: SLOT_STATUSES.AVAILABLE,
      index: true
    },
    dimensions: {
      length: { type: Number, default: 5.0 }, // in meters
      width: { type: Number, default: 2.4 },  // in meters
      height: { type: Number, default: 2.2 }  // in meters
    },
    assignedVehiclePlate: {
      type: String,
      default: null,
      trim: true,
      uppercase: true
    },
    currentSession: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'ParkingSession',
      default: null
    },
    currentBooking: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Booking',
      default: null
    },
    dedicatedToSubscription: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subscription',
      default: null
    },
    isEvCharging: {
      type: Boolean,
      default: false
    },
    walkDistanceUnits: {
      type: Number,
      default: 10 // Proximity score to entrance for smart nearest-slot allocation
    },
    version: {
      type: Number,
      default: 0 // Concurrency control token
    },
    notes: {
      type: String,
      default: ''
    }
  },
  {
    timestamps: true
  }
);

export default mongoose.model('ParkingSlot', parkingSlotSchema);
