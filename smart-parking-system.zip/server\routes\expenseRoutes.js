import express from 'express';
import { getAllExpenses, createExpense, deleteExpense } from '../controllers/expenseController.js';
import { protect, restrictTo } from '../middleware/auth.js';
import { USER_ROLES } from '../config/constants.js';

const router = express.Router();

router.get('/', protect, getAllExpenses);
router.post(
  '/',
  protect,
  restrictTo(USER_ROLES.SUPER_ADMIN, USER_ROLES.ACCOUNTANT),
  createExpense
);
router.delete(
  '/:id',
  protect,
  restrictTo(USER_ROLES.SUPER_ADMIN),
  deleteExpense
);

export default router;
