import Subscription from '../models/Subscription.js';
import PricingRule from '../models/PricingRule.js';
import ParkingSlot from '../models/ParkingSlot.js';
import Payment from '../models/Payment.js';
import { SLOT_STATUSES, PAYMENT_METHODS, PAYMENT_STATUSES } from '../config/constants.js';
import { logAuditEvent } from '../services/auditService.js';
import { sendNotification } from '../services/notificationService.js';

export const purchasePass = async (req, res, next) => {
  try {
    const {
      customerName,
      customerPhone,
      vehicleNumber,
      category,
      planType, // MONTHLY or YEARLY
      dedicatedSlotId,
      paymentMethod = PAYMENT_METHODS.ONLINE_GATEWAY
    } = req.body;

    const cleanPlate = vehicleNumber.trim().toUpperCase();

    // Check if vehicle already has an active pass for this category
    const activeExisting = await Subscription.findOne({
      vehicleNumber: cleanPlate,
      category,
      status: 'ACTIVE',
      endDate: { $gte: new Date() }
    });

    if (activeExisting) {
      return res.status(400).json({
        success: false,
        message: `Vehicle ${cleanPlate} already holds an active ${activeExisting.planType} pass until ${new Date(activeExisting.endDate).toLocaleDateString()}`
      });
    }

    // Get pricing rule
    const rule = await PricingRule.findOne({ category, isActive: true });
    if (!rule) {
      return res.status(404).json({ success: false, message: `Pricing rule not found for category ${category}` });
    }

    const baseAmount = planType === 'YEARLY' ? rule.yearlyRate : rule.monthlyRate;
    const taxAmount = Math.round(((baseAmount * (rule.taxPercent || 18)) / 100) * 100) / 100;
    const totalAmount = Math.round((baseAmount + taxAmount) * 100) / 100;

    const startDate = new Date();
    const endDate = new Date(startDate);
    if (planType === 'YEARLY') {
      endDate.setFullYear(endDate.getFullYear() + 1);
    } else {
      endDate.setMonth(endDate.getMonth() + 1);
    }

    // If dedicated slot requested, verify and reserve it
    let slotRef = null;
    if (dedicatedSlotId) {
      const slot = await ParkingSlot.findById(dedicatedSlotId);
      if (!slot) {
        return res.status(404).json({ success: false, message: 'Dedicated slot not found' });
      }
      if (slot.status !== SLOT_STATUSES.AVAILABLE) {
        return res.status(400).json({
          success: false,
          message: `Slot ${slot.slotNumber} cannot be reserved as dedicated (currently ${slot.status})`
        });
      }
      slotRef = slot._id;
    }

    // Generate unique pass number
    const passCode = planType === 'YEARLY' ? 'PASS-Y' : 'PASS-M';
    const randCode = Math.floor(10000 + Math.random() * 90000);
    const passNumber = `${passCode}-${Date.now().toString().slice(-4)}${randCode}`;

    // Create payment record
    const txnId = `TXN-SUB-${Date.now().toString().slice(-6)}-${randCode}`;
    const payment = await Payment.create({
      transactionId: txnId,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      vehicleNumber: cleanPlate,
      baseAmount,
      taxAmount,
      totalAmount,
      paymentMethod,
      status: PAYMENT_STATUSES.PAID,
      notes: `${planType} Subscription pass purchase`
    });

    const subscription = await Subscription.create({
      passNumber,
      user: req.user?._id || null,
      customerName: customerName.trim(),
      customerPhone: customerPhone.trim(),
      vehicleNumber: cleanPlate,
      category,
      planType,
      startDate,
      endDate,
      amount: totalAmount,
      paymentStatus: 'PAID',
      payment: payment._id,
      status: 'ACTIVE',
      dedicatedSlot: slotRef,
      priceSnapshot: {
        monthlyRate: rule.monthlyRate,
        yearlyRate: rule.yearlyRate,
        taxPercent: rule.taxPercent,
        capturedAt: new Date()
      }
    });

    // If dedicated slot, link and update slot status to RESERVED
    if (slotRef) {
      await ParkingSlot.findByIdAndUpdate(slotRef, {
        status: SLOT_STATUSES.RESERVED,
        dedicatedToSubscription: subscription._id,
        assignedVehiclePlate: cleanPlate,
        $inc: { version: 1 }
      });
    }

    payment.subscription = subscription._id;
    await payment.save();

    await logAuditEvent({
      req,
      action: 'PASS_PURCHASED',
      resourceType: 'SUBSCRIPTION',
      resourceId: subscription.passNumber,
      newValues: {
        passNumber: subscription.passNumber,
        vehicleNumber: subscription.vehicleNumber,
        planType: subscription.planType,
        endDate: subscription.endDate,
        amount: subscription.amount
      },
      reason: 'Pass issued to customer'
    });

    await sendNotification({
      userId: req.user?._id,
      title: 'Subscription Pass Activated',
      message: `Your ${planType} parking pass (${passNumber}) for vehicle ${cleanPlate} is now active until ${endDate.toLocaleDateString()}.`,
      type: 'SUCCESS',
      referenceId: subscription._id
    });

    res.status(201).json({
      success: true,
      message: `${planType} pass generated successfully`,
      subscription,
      payment
    });
  } catch (err) {
    next(err);
  }
};

export const getPasses = async (req, res, next) => {
  try {
    const { status, category, planType } = req.query;
    const filter = {};

    if (status) filter.status = status;
    if (category) filter.category = category;
    if (planType) filter.planType = planType;

    // Customers only see their own passes
    if (req.user && req.user.role === 'CUSTOMER') {
      filter.user = req.user._id;
    }

    // Auto-update expired passes
    await Subscription.updateMany(
      { status: 'ACTIVE', endDate: { $lt: new Date() } },
      { $set: { status: 'EXPIRED' } }
    );

    const passes = await Subscription.find(filter)
      .populate('dedicatedSlot', 'slotNumber zone dimensions')
      .populate('payment', 'transactionId paymentMethod totalAmount')
      .sort({ createdAt: -1 });

    res.json({ success: true, count: passes.length, passes });
  } catch (err) {
    next(err);
  }
};

export const cancelPass = async (req, res, next) => {
  try {
    const { id } = req.params;
    const { reason } = req.body;

    const pass = await Subscription.findById(id);
    if (!pass) {
      return res.status(404).json({ success: false, message: 'Pass not found' });
    }

    if (pass.status !== 'ACTIVE') {
      return res.status(400).json({ success: false, message: `Pass is already ${pass.status}` });
    }

    pass.status = 'CANCELLED';
    await pass.save();

    // Release dedicated slot if any
    if (pass.dedicatedSlot) {
      await ParkingSlot.findByIdAndUpdate(pass.dedicatedSlot, {
        status: SLOT_STATUSES.AVAILABLE,
        dedicatedToSubscription: null,
        assignedVehiclePlate: null,
        $inc: { version: 1 }
      });
    }

    await logAuditEvent({
      req,
      action: 'PASS_CANCELLED',
      resourceType: 'SUBSCRIPTION',
      resourceId: pass.passNumber,
      reason: reason || 'Customer/Admin requested pass cancellation'
    });

    res.json({ success: true, message: `Pass ${pass.passNumber} cancelled successfully`, pass });
  } catch (err) {
    next(err);
  }
};
