import mongoose from 'mongoose';
import { PAYMENT_METHODS, PAYMENT_STATUSES } from '../config/constants.js';

const paymentSchema = new mongoose.Schema(
  {
    transactionId: {
      type: String,
      required: true,
      unique: true,
      index: true,
      uppercase: true
    },
    session: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'ParkingSession',
      default: null
    },
    subscription: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Subscription',
      default: null
    },
    booking: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'Booking',
      default: null
    },
    customerName: {
      type: String,
      required: true
    },
    customerPhone: {
      type: String,
      required: true
    },
    vehicleNumber: {
      type: String,
      required: true,
      uppercase: true
    },
    baseAmount: {
      type: Number,
      required: true,
      default: 0
    },
    discountAmount: {
      type: Number,
      default: 0
    },
    taxAmount: {
      type: Number,
      default: 0
    },
    penaltyAmount: {
      type: Number,
      default: 0
    },
    totalAmount: {
      type: Number,
      required: true
    },
    paymentMethod: {
      type: String,
      enum: Object.values(PAYMENT_METHODS),
      required: true
    },
    status: {
      type: String,
      enum: Object.values(PAYMENT_STATUSES),
      default: PAYMENT_STATUSES.PAID,
      index: true
    },
    gatewayDetails: {
      gatewayName: { type: String, default: 'Sandbox Gateway' },
      gatewayPaymentId: { type: String },
      gatewayOrderId: { type: String },
      gatewaySignature: { type: String },
      isSandbox: { type: Boolean, default: true }
    },
    refundReason: {
      type: String,
      default: null
    },
    refundAuthorizedBy: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'User',
      default: null
    },
    refundDate: {
      type: Date,
      default: null
    },
    notes: {
      type: String,
      default: ''
    }
  },
  {
    timestamps: true
  }
);

export default mongoose.model('Payment', paymentSchema);
