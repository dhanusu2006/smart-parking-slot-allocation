import React, { useState, useEffect } from 'react';
import {
  CreditCard,
  Plus,
  Calendar,
  Car,
  CheckCircle,
  AlertTriangle,
  XCircle,
  RefreshCw,
  Search,
  X
} from 'lucide-react';
import api from '../services/api';

export const PassesSubscriptionsPage = () => {
  const [passes, setPasses] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Purchase Modal State
  const [purchaseModalOpen, setPurchaseModalOpen] = useState(false);
  const [formData, setFormData] = useState({
    customerName: '',
    customerPhone: '',
    vehicleNumber: '',
    category: 'FOUR_WHEELER',
    planType: 'MONTHLY',
    dedicatedSlotId: ''
  });

  const [availableSlots, setAvailableSlots] = useState([]);

  const fetchPasses = async () => {
    setLoading(true);
    try {
      const res = await api.get('/passes');
      if (res.success) {
        setPasses(res.passes || []);
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPasses();
  }, []);

  const openPurchaseModal = async () => {
    setPurchaseModalOpen(true);
    try {
      const res = await api.get(`/parking/layout?category=${formData.category}&status=AVAILABLE`);
      if (res.success) {
        setAvailableSlots(res.slots || []);
      }
    } catch (err) {
      console.error('Failed to load slots for pass modal:', err.message);
    }
  };

  const handlePurchase = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    try {
      const res = await api.post('/passes/purchase', {
        ...formData,
        vehicleNumber: formData.vehicleNumber.trim().toUpperCase(),
        dedicatedSlotId: formData.dedicatedSlotId || undefined
      });

      if (res.success) {
        setSuccessMsg(`Pass ${res.subscription?.passNumber} issued successfully!`);
        setPurchaseModalOpen(false);
        fetchPasses();
        setFormData({
          customerName: '',
          customerPhone: '',
          vehicleNumber: '',
          category: 'FOUR_WHEELER',
          planType: 'MONTHLY',
          dedicatedSlotId: ''
        });
      }
    } catch (err) {
      setError(err.message);
    }
  };

  const handleCancelPass = async (id, passNumber) => {
    if (!window.confirm(`Are you sure you want to cancel subscription pass ${passNumber}?`)) return;
    try {
      const res = await api.patch(`/passes/${id}/cancel`, { reason: 'Customer requested cancellation' });
      if (res.success) {
        setSuccessMsg(`Pass ${passNumber} has been cancelled.`);
        fetchPasses();
      }
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
            Monthly & Yearly Subscriptions
            <span className="text-xs bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-2.5 py-0.5 rounded-full font-bold">
              {passes.length} Passes Active
            </span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Manage long-term recurring parking passes, optional dedicated bay allocations, and renewal cycles.
          </p>
        </div>

        <button
          onClick={openPurchaseModal}
          className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shadow-lg glow-cyan transition self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" /> Issue Subscription Pass
        </button>
      </div>

      {successMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-500/50 text-emerald-300 text-xs flex items-center gap-2">
          <CheckCircle className="w-4 h-4 text-emerald-400" />
          <span>{successMsg}</span>
        </div>
      )}

      {error && (
        <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2">
          <AlertTriangle className="w-4 h-4 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* Passes Table Card */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-800/60 text-slate-400 uppercase text-[10px] font-bold">
              <tr>
                <th className="py-3 px-4 rounded-l-lg">Pass Number</th>
                <th className="py-3 px-4">Vehicle Number</th>
                <th className="py-3 px-4">Customer Details</th>
                <th className="py-3 px-4">Category</th>
                <th className="py-3 px-4">Plan & Fee</th>
                <th className="py-3 px-4">Validity Range</th>
                <th className="py-3 px-4">Dedicated Bay</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4 rounded-r-lg text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {passes.length === 0 ? (
                <tr>
                  <td colSpan="9" className="text-center py-8 text-slate-400">
                    No active or historical passes found. Click "Issue Subscription Pass" to create one.
                  </td>
                </tr>
              ) : (
                passes.map((p) => {
                  const isExpiringSoon =
                    p.status === 'ACTIVE' &&
                    new Date(p.endDate) - Date.now() < 3 * 24 * 60 * 60 * 1000;

                  return (
                    <tr key={p._id} className="hover:bg-slate-800/40 transition">
                      <td className="py-3 px-4 font-mono font-bold text-cyan-300">
                        {p.passNumber}
                      </td>
                      <td className="py-3 px-4 font-mono font-bold text-white">
                        {p.vehicleNumber}
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-200">{p.customerName}</div>
                        <div className="text-[10px] text-slate-400">{p.customerPhone}</div>
                      </td>
                      <td className="py-3 px-4">
                        {p.category.replace('_', ' ')}
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-bold text-white block">{p.planType}</span>
                        <span className="font-mono text-emerald-400 text-[11px]">₹{p.amount}</span>
                      </td>
                      <td className="py-3 px-4">
                        <div className="text-[11px] text-slate-300">
                          {new Date(p.startDate).toLocaleDateString()} →{' '}
                          <span className={isExpiringSoon ? 'text-amber-400 font-bold' : ''}>
                            {new Date(p.endDate).toLocaleDateString()}
                          </span>
                        </div>
                        {isExpiringSoon && (
                          <span className="text-[10px] text-amber-400 font-bold flex items-center gap-1 mt-0.5">
                            <AlertTriangle className="w-3 h-3" /> Expires in &lt;3 days
                          </span>
                        )}
                      </td>
                      <td className="py-3 px-4 font-mono font-semibold text-emerald-300">
                        {p.dedicatedSlot ? p.dedicatedSlot.slotNumber : 'Any Available Bay'}
                      </td>
                      <td className="py-3 px-4">
                        <span
                          className={`px-2 py-0.5 rounded-full text-[10px] font-bold uppercase tracking-wider ${
                            p.status === 'ACTIVE'
                              ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30'
                              : p.status === 'EXPIRED'
                              ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                              : 'bg-rose-500/20 text-rose-400 border border-rose-500/30'
                          }`}
                        >
                          {p.status}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right">
                        {p.status === 'ACTIVE' && (
                          <button
                            onClick={() => handleCancelPass(p._id, p.passNumber)}
                            className="p-1 rounded-lg bg-rose-950/40 text-rose-400 hover:bg-rose-900/60 hover:text-white transition"
                            title="Cancel Pass"
                          >
                            <XCircle className="w-4 h-4" />
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Issue Pass Modal */}
      {purchaseModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl p-6 shadow-2xl relative text-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="font-extrabold text-base text-white">Issue New Subscription Pass</h2>
              <button
                onClick={() => setPurchaseModalOpen(false)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handlePurchase} className="space-y-4 my-4 text-xs">
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Customer Name *</label>
                  <input
                    type="text"
                    required
                    value={formData.customerName}
                    onChange={(e) => setFormData({ ...formData, customerName: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Mobile Phone *</label>
                  <input
                    type="tel"
                    required
                    value={formData.customerPhone}
                    onChange={(e) => setFormData({ ...formData, customerPhone: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Vehicle Plate *</label>
                  <input
                    type="text"
                    required
                    placeholder="e.g. MH12XY9999"
                    value={formData.vehicleNumber}
                    onChange={(e) => setFormData({ ...formData, vehicleNumber: e.target.value.toUpperCase() })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono uppercase"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Plan Period *</label>
                  <select
                    value={formData.planType}
                    onChange={(e) => setFormData({ ...formData, planType: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="MONTHLY">Monthly Pass (30 Days)</option>
                    <option value="YEARLY">Yearly Pass (365 Days)</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-slate-400 block mb-1">Vehicle Category</label>
                  <select
                    value={formData.category}
                    onChange={(e) => setFormData({ ...formData, category: e.target.value, dedicatedSlotId: '' })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white"
                  >
                    <option value="TWO_WHEELER">Two-Wheeler</option>
                    <option value="FOUR_WHEELER">Four-Wheeler</option>
                    <option value="COMMERCIAL">Commercial</option>
                    <option value="HEAVY">Heavy Vehicle</option>
                  </select>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Optional Dedicated Bay</label>
                  <select
                    value={formData.dedicatedSlotId}
                    onChange={(e) => setFormData({ ...formData, dedicatedSlotId: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                  >
                    <option value="">None (Floating Bay)</option>
                    {availableSlots.map((s) => (
                      <option key={s._id} value={s._id}>
                        {s.slotNumber} (Available)
                      </option>
                    ))}
                  </select>
                </div>
              </div>

              <div className="pt-4 border-t border-slate-800 flex items-center justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setPurchaseModalOpen(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 font-semibold hover:bg-slate-700"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold shadow-lg glow-cyan"
                >
                  Confirm & Activate Pass
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PassesSubscriptionsPage;
