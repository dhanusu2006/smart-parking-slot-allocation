import React, { useState, useEffect } from 'react';
import {
  IndianRupee,
  Edit,
  History,
  ShieldCheck,
  AlertCircle,
  Save,
  X,
  Bike,
  Car,
  Truck,
  Bus,
  Clock,
  Sparkles
} from 'lucide-react';
import api from '../services/api';

const getCategoryIcon = (category) => {
  switch (category) {
    case 'TWO_WHEELER': return Bike;
    case 'FOUR_WHEELER': return Car;
    case 'COMMERCIAL': return Truck;
    case 'HEAVY': return Bus;
    default: return Car;
  }
};

export const PricingManagementPage = () => {
  const [rules, setRules] = useState([]);
  const [auditHistory, setAuditHistory] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Editing state
  const [editingCategory, setEditingCategory] = useState(null);
  const [editForm, setEditForm] = useState({
    hourlyRate: 0,
    dailyRate: 0,
    monthlyRate: 0,
    yearlyRate: 0,
    gracePeriodMinutes: 15,
    overtimeRatePerHour: 0,
    taxPercent: 18,
    discountPercent: 0,
    reason: ''
  });

  const fetchData = async () => {
    setLoading(true);
    try {
      const [rulesRes, auditRes] = await Promise.all([
        api.get('/pricing'),
        api.get('/pricing/audit')
      ]);
      if (rulesRes.success) setRules(rulesRes.rules || []);
      if (auditRes.success) setAuditHistory(auditRes.history || []);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const openEditModal = (rule) => {
    setEditingCategory(rule.category);
    setEditForm({
      hourlyRate: rule.hourlyRate,
      dailyRate: rule.dailyRate,
      monthlyRate: rule.monthlyRate,
      yearlyRate: rule.yearlyRate,
      gracePeriodMinutes: rule.gracePeriodMinutes || 15,
      overtimeRatePerHour: rule.overtimeRatePerHour || rule.hourlyRate * 1.5,
      taxPercent: rule.taxPercent || 18,
      discountPercent: rule.discountPercent || 0,
      reason: ''
    });
  };

  const handleUpdate = async (e) => {
    e.preventDefault();
    setError('');
    setSuccessMsg('');

    if (!editForm.reason.trim()) {
      setError('Please provide a valid justification reason for the pricing audit log.');
      return;
    }

    try {
      const res = await api.put(`/pricing/${editingCategory}`, editForm);
      if (res.success) {
        setSuccessMsg(`Pricing for ${editingCategory} updated successfully.`);
        setEditingCategory(null);
        fetchData();
      }
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-extrabold text-white tracking-tight flex items-center gap-2">
          Dynamic Pricing Engine & Tariffs
          <span className="text-xs bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 px-2.5 py-0.5 rounded-full font-bold">
            Audit Immutable Snapshots
          </span>
        </h1>
        <p className="text-xs text-slate-400 mt-0.5">
          Configure category-specific hourly, daily, monthly, and yearly tariffs. Active parking sessions retain snapshot rates.
        </p>
      </div>

      {successMsg && (
        <div className="p-3.5 rounded-xl bg-emerald-950/60 border border-emerald-500/50 text-emerald-300 text-xs flex items-center gap-2">
          <ShieldCheck className="w-4 h-4 text-emerald-400" />
          <span>{successMsg}</span>
        </div>
      )}

      {error && (
        <div className="p-3.5 rounded-xl bg-rose-950/60 border border-rose-500/50 text-rose-300 text-xs flex items-center gap-2">
          <AlertCircle className="w-4 h-4 text-rose-400" />
          <span>{error}</span>
        </div>
      )}

      {/* Tariff Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {rules.map((rule) => {
          const Icon = getCategoryIcon(rule.category);
          return (
            <div
              key={rule.category}
              className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl backdrop-blur-md flex flex-col justify-between hover:border-slate-700 transition"
            >
              <div>
                <div className="flex items-center justify-between pb-3 border-b border-slate-800 mb-3">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-xl bg-cyan-950 border border-cyan-500/30 text-cyan-400">
                      <Icon className="w-4 h-4" />
                    </div>
                    <span className="font-bold text-xs text-white">
                      {rule.category.replace('_', ' ')}
                    </span>
                  </div>
                  <button
                    onClick={() => openEditModal(rule)}
                    className="p-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-400 transition"
                    title="Edit Tariffs"
                  >
                    <Edit className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Rates List */}
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between py-1 border-b border-slate-800/60">
                    <span className="text-slate-400">Hourly Rate:</span>
                    <span className="font-mono font-bold text-white">₹{rule.hourlyRate}/hr</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-800/60">
                    <span className="text-slate-400">Daily (24h) Rate:</span>
                    <span className="font-mono font-bold text-white">₹{rule.dailyRate}/day</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-800/60">
                    <span className="text-slate-400">Monthly Pass:</span>
                    <span className="font-mono font-bold text-emerald-400">₹{rule.monthlyRate}/mo</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-800/60">
                    <span className="text-slate-400">Yearly Pass:</span>
                    <span className="font-mono font-bold text-cyan-400">₹{rule.yearlyRate}/yr</span>
                  </div>
                  <div className="flex justify-between py-1 border-b border-slate-800/60 text-[11px]">
                    <span className="text-slate-400">Grace Period:</span>
                    <span className="text-slate-300 font-medium">{rule.gracePeriodMinutes || 15} mins free</span>
                  </div>
                  <div className="flex justify-between py-1 text-[11px]">
                    <span className="text-slate-400">Overtime Surcharge:</span>
                    <span className="text-rose-400 font-medium">₹{rule.overtimeRatePerHour}/hr</span>
                  </div>
                </div>
              </div>

              <div className="pt-4 mt-3 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between">
                <span>Tax Rate: {rule.taxPercent}% GST</span>
                <span>Active Tariff</span>
              </div>
            </div>
          );
        })}
      </div>

      {/* Audit History Log */}
      <div className="p-5 rounded-2xl bg-slate-900 border border-slate-800 shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-1.5">
              <History className="w-4 h-4 text-cyan-400" />
              Tariff Modification Audit Trail
            </h2>
            <p className="text-xs text-slate-400">Historical records of all rate modifications and rationale</p>
          </div>
          <span className="text-xs text-slate-400 font-mono">{auditHistory.length} logs recorded</span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs text-slate-300">
            <thead className="bg-slate-800/60 text-slate-400 uppercase text-[10px] font-bold">
              <tr>
                <th className="py-2.5 px-4 rounded-l-lg">Date & Time</th>
                <th className="py-2.5 px-4">Category</th>
                <th className="py-2.5 px-4">Authorized User</th>
                <th className="py-2.5 px-4">Old Rates</th>
                <th className="py-2.5 px-4">New Rates</th>
                <th className="py-2.5 px-4 rounded-r-lg">Modification Reason</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {auditHistory.map((item) => (
                <tr key={item._id} className="hover:bg-slate-800/40 transition">
                  <td className="py-2.5 px-4 font-mono text-[11px] text-slate-400">
                    {new Date(item.createdAt).toLocaleString()}
                  </td>
                  <td className="py-2.5 px-4 font-bold text-white">
                    {item.resourceId}
                  </td>
                  <td className="py-2.5 px-4 text-slate-300">
                    {item.userName} ({item.userRole})
                  </td>
                  <td className="py-2.5 px-4 font-mono text-[11px] text-slate-400">
                    {item.oldValues?.hourlyRate ? `₹${item.oldValues.hourlyRate}/h • ₹${item.oldValues.dailyRate}/d` : 'Initial'}
                  </td>
                  <td className="py-2.5 px-4 font-mono text-[11px] text-emerald-400 font-bold">
                    {item.newValues?.hourlyRate ? `₹${item.newValues.hourlyRate}/h • ₹${item.newValues.dailyRate}/d` : 'Updated'}
                  </td>
                  <td className="py-2.5 px-4 text-slate-300">
                    {item.reason}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Edit Tariff Modal */}
      {editingCategory && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="bg-slate-900 border border-slate-700 w-full max-w-lg rounded-2xl p-6 shadow-2xl relative text-slate-100">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <h2 className="font-extrabold text-base text-white">
                Modify Tariffs: {editingCategory.replace('_', ' ')}
              </h2>
              <button
                onClick={() => setEditingCategory(null)}
                className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleUpdate} className="space-y-4 my-4">
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div>
                  <label className="text-slate-400 block mb-1">Hourly Rate (₹)</label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={editForm.hourlyRate}
                    onChange={(e) => setEditForm({ ...editForm, hourlyRate: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Daily (24h) Rate (₹)</label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={editForm.dailyRate}
                    onChange={(e) => setEditForm({ ...editForm, dailyRate: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Monthly Pass (₹)</label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={editForm.monthlyRate}
                    onChange={(e) => setEditForm({ ...editForm, monthlyRate: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Yearly Pass (₹)</label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={editForm.yearlyRate}
                    onChange={(e) => setEditForm({ ...editForm, yearlyRate: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Grace Period (Minutes)</label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={editForm.gracePeriodMinutes}
                    onChange={(e) => setEditForm({ ...editForm, gracePeriodMinutes: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                  />
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Overtime Surcharge (₹/hr)</label>
                  <input
                    type="number"
                    required
                    min="0"
                    value={editForm.overtimeRatePerHour}
                    onChange={(e) => setEditForm({ ...editForm, overtimeRatePerHour: e.target.value })}
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-white font-mono"
                  />
                </div>
              </div>

              <div>
                <label className="text-slate-400 text-xs font-bold block mb-1">
                  Reason for Adjustment * (Recorded in Audit Log)
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Festival peak demand revision or council approval"
                  value={editForm.reason}
                  onChange={(e) => setEditForm({ ...editForm, reason: e.target.value })}
                  className="w-full bg-slate-800 border border-slate-700 rounded-lg px-3 py-2 text-xs text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-800">
                <button
                  type="button"
                  onClick={() => setEditingCategory(null)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300 text-xs font-semibold hover:bg-slate-700 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white text-xs font-bold shadow-lg glow-cyan transition"
                >
                  <Save className="w-4 h-4" /> Save Tariff & Log Audit
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PricingManagementPage;
