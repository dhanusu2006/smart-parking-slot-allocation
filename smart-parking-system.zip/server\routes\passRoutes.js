import express from 'express';
import { purchasePass, getPasses, cancelPass } from '../controllers/passController.js';
import { protect, restrictTo } from '../middleware/auth.js';
import { USER_ROLES } from '../config/constants.js';

const router = express.Router();

router.post('/purchase', protect, purchasePass);
router.get('/', protect, getPasses);
router.patch(
  '/:id/cancel',
  protect,
  restrictTo(USER_ROLES.SUPER_ADMIN, USER_ROLES.PARKING_MANAGER, USER_ROLES.CUSTOMER),
  cancelPass
);

export default router;
