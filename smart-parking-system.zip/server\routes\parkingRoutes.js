import express from 'express';
import {
  getVisualParkingLayout,
  getSlotById,
  updateSlotStatus,
  updateSlotDimensions,
  reallocateVehicleSlot
} from '../controllers/parkingController.js';
import { protect, restrictTo } from '../middleware/auth.js';
import { USER_ROLES } from '../config/constants.js';

const router = express.Router();

// Public / Authenticated visual layout
router.get('/layout', getVisualParkingLayout);
router.get('/slots/:id', getSlotById);

// Staff & Managers can update slot status (e.g. Maintenance) and reallocate
router.patch(
  '/slots/:id/status',
  protect,
  restrictTo(USER_ROLES.SUPER_ADMIN, USER_ROLES.PARKING_MANAGER, USER_ROLES.PARKING_STAFF),
  updateSlotStatus
);

router.post(
  '/reallocate',
  protect,
  restrictTo(USER_ROLES.SUPER_ADMIN, USER_ROLES.PARKING_MANAGER),
  reallocateVehicleSlot
);

// Admin can configure slot dimensions and EV capabilities
router.patch(
  '/slots/:id/dimensions',
  protect,
  restrictTo(USER_ROLES.SUPER_ADMIN, USER_ROLES.PARKING_MANAGER),
  updateSlotDimensions
);

export default router;
