import { useState, useEffect } from 'react';
import api from '../services/api';

export const useParking = (pollIntervalMs = 15000) => {
  const [layout, setLayout] = useState({ slots: [], stats: {}, zones: [] });
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const refresh = async () => {
    try {
      const res = await api.get('/parking/layout');
      if (res.success) {
        setLayout({
          slots: res.slots || [],
          stats: res.stats || {},
          zones: res.zones || []
        });
      }
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    refresh();
    if (pollIntervalMs > 0) {
      const timer = setInterval(refresh, pollIntervalMs);
      return () => clearInterval(timer);
    }
  }, [pollIntervalMs]);

  return { ...layout, loading, error, refresh };
};
