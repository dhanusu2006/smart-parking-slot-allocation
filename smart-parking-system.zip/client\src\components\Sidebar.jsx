import React from 'react';
import { NavLink } from 'react-router-dom';
import {
  LayoutDashboard,
  Grid,
  LogIn,
  LogOut,
  IndianRupee,
  CreditCard,
  Receipt,
  DollarSign,
  FileSpreadsheet,
  Clock,
  Car,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';

export const Sidebar = ({ isOpen, onClose }) => {
  const { role } = useAuth();

  const navItems = [
    {
      to: '/',
      label: 'Dashboard',
      icon: LayoutDashboard,
      roles: ['SUPER_ADMIN', 'PARKING_MANAGER', 'ACCOUNTANT']
    },
    {
      to: '/layout',
      label: 'Live Parking Layout',
      icon: Grid,
      roles: ['SUPER_ADMIN', 'PARKING_MANAGER', 'PARKING_STAFF', 'CUSTOMER']
    },
    {
      to: '/entry',
      label: 'Vehicle Entry',
      icon: LogIn,
      roles: ['SUPER_ADMIN', 'PARKING_MANAGER', 'PARKING_STAFF']
    },
    {
      to: '/exit',
      label: 'Exit & Checkout',
      icon: LogOut,
      roles: ['SUPER_ADMIN', 'PARKING_MANAGER', 'PARKING_STAFF']
    },
    {
      to: '/pricing',
      label: 'Pricing & Tariffs',
      icon: IndianRupee,
      roles: ['SUPER_ADMIN']
    },
    {
      to: '/passes',
      label: 'Passes & Subscriptions',
      icon: CreditCard,
      roles: ['SUPER_ADMIN', 'PARKING_MANAGER', 'PARKING_STAFF', 'CUSTOMER']
    },
    {
      to: '/payments',
      label: 'Payments & Refunds',
      icon: Receipt,
      roles: ['SUPER_ADMIN', 'ACCOUNTANT']
    },
    {
      to: '/expenses',
      label: 'Operating Expenses',
      icon: DollarSign,
      roles: ['SUPER_ADMIN', 'ACCOUNTANT']
    },
    {
      to: '/waiting-list',
      label: 'Waiting List Queue',
      icon: Clock,
      roles: ['SUPER_ADMIN', 'PARKING_MANAGER', 'PARKING_STAFF', 'CUSTOMER']
    },
    {
      to: '/reports',
      label: 'Audit & Reports (CSV)',
      icon: FileSpreadsheet,
      roles: ['SUPER_ADMIN', 'PARKING_MANAGER', 'ACCOUNTANT']
    }
  ];

  const visibleItems = navItems.filter((item) => !item.roles || item.roles.includes(role || 'SUPER_ADMIN'));

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-black/60 backdrop-blur-sm lg:hidden"
        />
      )}

      {/* Sidebar Container */}
      <aside
        className={`fixed lg:static top-0 bottom-0 left-0 z-50 w-64 bg-slate-900 border-r border-slate-800 flex flex-col transition-transform duration-300 ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Brand Header */}
        <div className="h-16 flex items-center justify-between px-6 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-600/20 border border-cyan-500/40 text-cyan-400 glow-cyan">
              <Car className="w-5 h-5" />
            </div>
            <div>
              <span className="font-extrabold text-sm tracking-wide text-white uppercase block leading-none">
                Smart Park
              </span>
              <span className="text-[10px] text-cyan-400 font-mono tracking-widest uppercase">
                Enterprise
              </span>
            </div>
          </div>
          <button
            onClick={onClose}
            className="lg:hidden p-1.5 rounded-lg text-slate-400 hover:text-white"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Navigation Links */}
        <nav className="flex-1 overflow-y-auto p-4 space-y-1.5">
          <div className="text-[10px] font-bold uppercase tracking-wider text-slate-400 px-3 py-1">
            Core Modules
          </div>
          {visibleItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.to}
                to={item.to}
                onClick={() => onClose()}
                className={({ isActive }) =>
                  `flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-semibold transition-all duration-150 ${
                    isActive
                      ? 'bg-cyan-500/15 text-cyan-300 border border-cyan-500/30 shadow-md glow-cyan'
                      : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/60'
                  }`
                }
              >
                <Icon className="w-4 h-4 flex-shrink-0" />
                <span>{item.label}</span>
              </NavLink>
            );
          })}
        </nav>

        {/* Status Footer */}
        <div className="p-4 border-t border-slate-800 text-[11px] text-slate-400">
          <div className="flex items-center justify-between mb-1">
            <span>System Status</span>
            <span className="flex items-center gap-1.5 text-emerald-400 font-bold">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span> Online
            </span>
          </div>
          <div className="text-[10px] text-slate-400">
            Node v24 • MongoDB Active • v1.0.0
          </div>
        </div>
      </aside>
    </>
  );
};

export default Sidebar;
